# إصلاحات نسخة SaaS/PMS Foundation

تم تنفيذ هذه الإصلاحات على الأرشيف الأصلي المرفوع:

## إصلاحات مانعة للتشغيل
- إزالة الاعتماد على المسارات القديمة `core.*` و `services.*` من الـ composition root.
- جعل `container.bootstrap(db, client=client)` يحقن Mongo client الصحيح للـ Unit of Work.
- إصلاح أوامر API التي كانت تستخدم `Result.entity` أو `Result.daily_rate` رغم أن العقد الصحيح هو `Result.data`.
- إضافة معالجات أخطاء لـ `ValidationError` و `RequestValidationError` و generic 500 في `server.py`.
- إضافة `shared.security.url_guard` و `shared.realtime.manager` داخل الهيكل الجديد.

## سلامة البيانات والعمليات الحساسة
- جعل EventBus افتراضياً fail-fast للثوابت التشغيلية، مع `fail_fast=False` للإشعارات فقط.
- إصلاح MongoUnitOfWork: لا يبتلع أخطاء commit، والمعاملات أصبحت opt-in عبر `MONGO_TRANSACTIONS=true`.
- جعل check-in يشغل الغرفة عبر Port محقون من الـ container داخل نفس UoW قدر الإمكان.
- جعل subscriber الخاص بالغرف idempotent حتى لا يفشل إذا وصل حدث check-in بعد أن تم إشغال الغرفة فعلاً.
- إصلاح bug `_balance` في `CheckoutApplicationService`.
- منع اكتمال checkout عندما يكون رصيد الفاتورة موجباً.
- إصلاح منطق Billing reversal بحيث يرجع الرصيد إلى صفر بعد عكس القيد.

## SaaS / Multi-property foundation
- إضافة `tenant_id` و `property_id` في كيانات ومستودعات rooms/checkins/checkouts/requests/billing/identity.
- تحديث `Actor` و `AccessScope` و `MongoQueryScoper` لدعم tenant/property scoping.
- إضافة فهارس مركبة tenant/property في `shared/config/indexes.py`.
- إضافة أداة ترحيل `tools/migrate_tenant_property.py` لقواعد البيانات القديمة.

## اختبارات
- إضافة اختبارات regression تغطي EventBus fail-fast/lenient، Billing reversal، وثبوت `_balance`.
- آخر نتيجة محلية: `118 passed, 6 skipped` لاختبارات architecture.
- `tools/check_architecture.py app` نجح بدون مخالفات.
