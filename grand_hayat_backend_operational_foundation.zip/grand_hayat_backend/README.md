# Grand Hayat Hotel System — PMS Foundation Backend

Strict Modular Monolith foundation for a professional hotel PMS, designed as a single-property PMS now and a future multi-property/SaaS backend later.

## Current package status

- **Package date:** 2026-05-30
- **Architecture:** Strict Modular Monolith
- **Foundation level:** PMS Foundation complete
- **Registered API modules:** 15 modules under `/api/v1`
- **Operational batch added:** Identity/Auth sessions, API contracts, permissions catalog, settings/sounds/notifications flow, floors/room types/rooms API
- **Future SaaS readiness:** tenant/property scoping is present in domain, repositories, auth actor, query scoping, indexes, and foundation modules
- **Integrity:** `MANIFEST.md` + `verify.sh` included

## Root structure

```txt
grand_hayat_backend/
├── README.md
├── CHANGELOG_FIXED.md
├── CHANGELOG_PMS_FOUNDATION.md
├── MANIFEST.md
├── verify.sh
├── requirements.txt
├── pytest.ini
├── .importlinter
├── .github/workflows/architecture.yml
├── app/
│   ├── kernel/          # pure contracts, bus, errors, UoW, security scopes
│   ├── shared/          # container, auth, scoping, outbox, realtime, url guard, PMS constants
│   ├── modules/         # 15 bounded modules
│   └── server.py        # FastAPI composition root
├── tests/architecture/  # architecture + domain regression tests
├── tools/               # architecture checker + tenant/property migration
└── docs/
    ├── PMS_FOUNDATION.md
    └── architecture/decisions/
```

## Modules

```txt
Operational PMS core:
  rooms
  checkins
  checkouts
  requests
  inspections
  billing
  notifications
  identity

PMS Foundation layer:
  properties
  guests
  reservations
  settings
  messaging
  audit
  storage
```

## Architecture rules

```txt
API Router → Application Service → Domain Entity → Repository → MongoDB
Domain Event → EventBus/Outbox → Subscribers/Adapters
```

Core rules:

- Domain does not import FastAPI, Mongo, HTTP clients, or side-effect adapters.
- Routers do not call repositories or DB directly.
- Cross-module wiring is only allowed in `shared/config/container.py`.
- Critical invariants must be handled synchronously and fail fast.
- Notifications, messages, gateways, and external integrations are side effects.
- Financial ledger entries are append-only; reversal is explicit and tested.
- Every operational record is scoped by `tenant_id` and `property_id`.

## PMS Foundation contract

Read:

```txt
docs/PMS_FOUNDATION.md
docs/MIGRATION_MAP.md
docs/GAP_REGISTER.md
docs/API_CONTRACTS.md
```

This document freezes the rules for:

- tenant/property scope
- statuses
- roles and permissions
- settings
- messaging channels
- guest/reservation foundation
- folios/billing
- audit
- storage
- migration rules

## Run

```bash
pip install -r requirements.txt
export MONGO_URL="mongodb://localhost:27017"
export DB_NAME="grand_hayat"
export JWT_SECRET="change-this-to-a-long-secret"
export ALLOW_DEV_AUTH=false
python -m uvicorn app.server:app --reload --port 8000
```

For standalone MongoDB, keep transactions disabled, which is the default:

```bash
export MONGO_TRANSACTIONS=false
```

After converting MongoDB to a replica set, enable transaction sessions:

```bash
export MONGO_TRANSACTIONS=true
```

## Verify package integrity

```bash
bash verify.sh
```

## Tests

```bash
PYTHONPATH=app python -m compileall -q app tests tools
PYTHONPATH=app python tools/check_architecture.py app
PYTHONPATH=app pytest tests/architecture -q
```

Last local result during packaging:

```txt
python -m compileall -q app       ✅ passed
python tools/check_architecture.py app
✅ لا انتهاكات معمارية. الدستور مُحترَم بالكامل.
pytest -q tests/architecture
215 passed
```

## One-time migration for old single-hotel databases

For an existing database created before tenant/property support:

```bash
MONGO_URL="mongodb://localhost:27017" \
DB_NAME="grand_hayat" \
DEFAULT_TENANT_ID="default" \
DEFAULT_PROPERTY_ID="main" \
python tools/migrate_tenant_property.py
```

This adds default tenant/property fields and replaces known old global indexes that block multi-property use.

## Practical migration order from the old system

Do not copy old routers directly. Move rules into domain/application services in this order:

```txt
1. identity/users/permissions
2. properties/settings/sounds
3. rooms/floors/room types
4. guests
5. checkins
6. folios/billing
7. checkouts
8. requests
9. inspections
10. unified messaging: SMS + WhatsApp
11. integrations: MikroTik / YemenSoft / gateways
12. frontend migration
```

## Remaining product work

This package is now a PMS Foundation base. Remaining major work before replacing the current production hotel system:

- run against a real MongoDB instance and Uvicorn environment
- migrate the real production database and review old indexes
- adapt the frontend to the new `/api/v1` contracts
- complete live provider adapters and credentials for WhatsApp/SMS/MikroTik/YemenSoft
- add functional and integration tests around real workflows
- expand reservations into availability calendar, rate plans, occupancy rules, and reporting
- complete guest-linked check-in and automatic folio opening
