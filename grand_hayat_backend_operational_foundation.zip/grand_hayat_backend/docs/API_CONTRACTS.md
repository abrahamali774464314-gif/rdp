# Grand Hayat PMS — API Contracts

All PMS Foundation endpoints should use the following envelope.

## Success

```json
{
  "data": {},
  "meta": {},
  "error": null
}
```

Lists use the same envelope and include at least `meta.count`:

```json
{
  "data": [],
  "meta": {"count": 0},
  "error": null
}
```

## Error

```json
{
  "data": null,
  "meta": {},
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "بيانات الطلب غير صحيحة",
    "details": []
  }
}
```

## Current standardized routers in this batch

- `/api/v1/identity/*`
- `/api/v1/settings/*`
- `/api/v1/notifications/*`
- `/api/v1/properties/*`
- `/api/v1/rooms/*`
- `/health`

Other already-existing routers still compile and pass architecture tests, but should be progressively converted to the same envelope while implementing their operational workflows.
