# ADR-005: Query Security Layer (Scoping & Authorization)

**الحالة:** مقبول ✅
**التاريخ:** 2026-05
**المرحلة:** 5 من خطة Architectural Enforcement
**يخصّ:** تقييد البيانات المرئية حسب الدور + الطابق + القسم + الملكية

---

## السياق

النظام القديم احتوى منطق scoping حسّاساً (`core/scope.py`): تقييد ما يراه
كل مستخدم حسب طابقه وقسمه ودوره. هذا المنطق كان **مبعثراً** في الـ routers
والاستعلامات، ويمثّل ~60-70% من منطق الأمان الذي لم يُهاجَر بعد.

الخطر: بدون طبقة موحّدة، يتسرّب منطق "من يرى ماذا" إلى المستودعات والخدمات،
فيصعب اختباره ويسهل خرقه (فجوة أمنية صامتة).

---

## القرار

### الفصل الجوهري: "ماذا أرى" ≠ "كيف أستعلم"

```
┌──────────────────────────────────────────────────────────────┐
│  kernel/security   →  السياسة (ماذا أرى؟) — محايدة عن DB        │
│  shared/security   →  الترجمة (كيف أستعلم؟) — Mongo            │
└──────────────────────────────────────────────────────────────┘
```

| الطبقة | الملف | المسؤولية |
|--------|-------|-----------|
| kernel | `query_scoper.py` | `AccessScope` (value object) + `Actor` + Protocols |
| kernel | `scoping_rules.py` | `ScopingRules` — القواعد الذهبية الثلاث |
| shared | `mongo_query_scoper.py` | ترجمة `AccessScope` → فلتر Mongo |
| shared | `base_scoped_repository.py` | `ScopedRepositoryMixin` (`list_scoped` موحّد) |
| shared | `scoped_listing.py` | `scoped_list()` helper (الحلقة موحّدة) |

### القواعد الذهبية الثلاث (منقولة من core/scope.py القديم)

| الدور | ما يراه |
|-------|---------|
| **admin** | كل شيء (`full_access`) |
| **supervisor** | سجلّات طوابقه المسموحة؛ وإن كان قسمه ≠ general، فقط قسمه |
| **staff** | عمل طوابقه/قسمه، مع `own_only` على أفعاله (created/accepted/...) |

**fail-closed:** فاعل بلا طوابق → لا يرى شيئاً (`AccessScope.deny()` →
استعلام مستحيل `{"_id": "__no_match__"}`). لا fail-open أبداً.

### تدفّق الاستخدام

```
Actor
  → ScopingRules.for_X(actor)        # السياسة (kernel)
  → AccessScope                       # وصف محايد
  → MongoQueryScoper.apply(base, scope)  # الترجمة (shared)
  → scoped_filter (dict)
  → repository.list_scoped(filter)    # تنفيذ غبيّ
```

في الـ Application Service، كل هذا مُغلَّف في `list_for(actor)`:

```python
rooms = await container.rooms.list_rooms_for(actor)
reqs  = await container.requests.list_for(actor, base_query={"status":"pending"})
```

### الحقن (Dependency Injection)

`ScopingRules` و `MongoQueryScoper` **عديما الحالة** → singletons في الـ
container، يُحقنان في الـ services عبر attribute injection (دون تغيير
تواقيع الـ services):

```python
container.scoping_rules   # ScopingRules singleton
container.query_scoper    # MongoQueryScoper singleton
```

---

## البدائل المرفوضة

| البديل | سبب الرفض |
|--------|-----------|
| scoping داخل الـ repositories | يخلط السياسة بالتخزين، يصعب اختباره |
| scoping في الـ routers | يبعثر المنطق، يكرّره، يسهل نسيانه (فجوة أمنية) |
| `AccessScope` يحوي Mongo syntax | يكسر نقاء kernel + يربط السياسة بمحرّك التخزين |
| بناء scoper كسول في كل service | تكرار + لا يستفيد من singleton |

---

## النتائج

**إيجابية:**
- السياسة في مكان **واحد** (kernel) — قابلة للاختبار بمعزل تام عن DB.
- الـ repository غبيّ (يستقبل فلتراً جاهزاً) — لا تسريب أمان.
- تقليل تكرار عبر mixin + helper (الحلقة في مكانين لا 8).
- fail-closed مضمون في كل مسار.

**ديون مؤجّلة:**
- بعض المستودعات لم تُربَط بعد بـ `list_for` في طبقة الـ API (لم تُبنَ بعد).
- `is_request_type_allowed` (فحص نقطي للكتابة) موجود لكن لم يُدمَج في كل
  مسارات الإنشاء بعد — يُكمَّل عند بناء الـ API layer.

---

## الإثبات

اختبارات end-to-end عبر الأدوار الثلاثة (admin/supervisor/staff) + fail-closed
أثبتت التقييد الصحيح. فاحص المعمارية: ✅ صفر انتهاكات. نقاء kernel محفوظ
(فحص AST: لا motor في kernel/security).
