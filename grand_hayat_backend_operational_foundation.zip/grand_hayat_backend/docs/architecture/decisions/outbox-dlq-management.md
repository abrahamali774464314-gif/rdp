# ADR-006: Outbox DLQ Management — Replay Policy & Audit Trail

**الحالة:** مقبول ✅
**التاريخ:** 2026-05
**المرحلة:** 6 من خطة Architectural Enforcement (Retry + DLQ)
**يخصّ:** إدارة الـ Dead Letter Queue وإعادة المعالجة اليدوية
**يبني على:** ADR-004 (Outbox Pattern)

---

## السياق

ADR-004 أنشأ Outbox + Worker + DLQ. الرسائل التي تستنفد المحاولات تنتقل إلى
`status=dead` (نهائية في الـ FSM). لكن في الإنتاج تحدث حالات مشروعة لإعادة
المعالجة:

- إصلاح bug في subscriber كان يفشل دائماً.
- إصلاح config (مثلاً SMS gateway URL خاطئ).
- استرداد بعد انقطاع طويل لخدمة خارجية.

دون مسار إداري واضح، تتراكم رسائل DLQ بلا حلّ، وقد يلجأ المشغّل لتعديل
يدوي في DB يكسر الـ invariants.

---

## القرار

### Replay Policy — الخيار (أ): Full Reset

`OutboxMessage.force_replay(at, by, reason)`:

```
dead → pending  (تجاوز إداري موثّق لنهائية dead)
attempts = 0    (دورة محاولات جديدة كاملة — 5 محاولات أخرى)
last_error = "" (مُمسَح)
next_attempt_at = now  (متاحة فوراً للـ Worker)
─── محفوظ: id ثابت + payload + idempotency_key + topic
─── audit: replay_count++ , من، متى، لماذا
```

**لماذا full reset؟**
- replay يدوي يعني: "أصلحتُ السبب الجذري، جرّب الرسالة بدورة كاملة جديدة".
- الاحتفاظ بـ `attempts` القديم يجعل محاولة واحدة فقط ثم تعود لـ DLQ — يلغي
  فائدة الإصلاح.
- `id` ثابت → نفس الرسالة منطقياً → الـ subscribers idempotent لا يكرّرون.

**الضوابط:**
- `force_replay` يُسمح من `dead` فقط (FSM-safe override، ليس عشوائياً).
- التجاوز موثّق صراحةً: لا يمرّ عبر `OUTBOX_FSM.transition()`، بل reset مباشر
  لأن `dead → pending` تدخّل إداري بطبيعته (لا يصلح كـ transition تلقائي).

### Audit Trail الإلزامي

كل replay يُسجَّل في الـ Entity نفسه (دائم، يُحفظ في DB):

| الحقل | الغرض |
|------|------|
| `replay_count` | كم مرّة أُعيدت (تتزايد) |
| `last_replayed_at` | وقت آخر replay |
| `last_replayed_by` | معرّف المشغّل (**إلزامي** — الـ Service يرفض بدونه) |
| `last_replay_reason` | السبب النصّي (للتدقيق التشغيلي) |
| `dead_at` | متى دخلت DLQ أصلاً |

بالإضافة لـ `logger.info` في كل replay (الـ logs الزائلة + الـ DB الدائم).

### OutboxManagementService — واجهة رقيقة

```python
mgmt = container.outbox_management

await mgmt.stats()                                  # لوحة مراقبة
await mgmt.list_dead(topic=..., limit=50, skip=0)   # تصفّح
await mgmt.replay(msg_id, replayed_by=..., reason=..)  # إعادة معالجة
await mgmt.purge_dead_before(before=..., purged_by=..) # تنظيف
```

**صفات التصميم:**
- **رقيقة**: تستدعي `repo` أو `entity.force_replay`، لا منطق أعمال.
- **مسار تسليم واحد**: `replay` يُعيد لـ `pending`، الـ Worker يلتقطها
  طبيعياً. لا تسليم مباشر من الـ management service → لا تكرار في مسارات.
- **DTOs آمنة**: `_msg_to_dict` يُخفي الـ Entity عن طبقات أعلى.

---

## المسار التشغيلي الكامل

```
1. رسالة تفشل 5 مرّات → move_to_dlq → status=dead, dead_at=T
2. المشغّل يستدعي mgmt.stats() ← يرى DLQ متضخّماً
3. mgmt.list_dead(topic=...) ← يحدّد السبب
4. يُصلح المشكلة (config / bug)
5. mgmt.replay(msg_id, replayed_by="ops-1", reason="fixed SMS config")
6. الـ Entity: dead → pending, reset, audit
7. الـ Worker (دورته التالية) ← list_due → dispatch → نجاح/فشل
8. عند النجاح: status=dispatched (نهائي)
   عند الفشل المتكرّر: عودة لـ DLQ (5 محاولات جديدة استُنفدت)
```

---

## البدائل المرفوضة

| البديل | سبب الرفض |
|--------|-----------|
| (ب) replay يُبقي `attempts` كما هو | محاولة واحدة فقط ثم DLQ — يُلغي فائدة الإصلاح |
| (ج) replay يأخذ `max_attempts` كمعامل | تعقيد زائد بلا حاجة عملية |
| الـ management يُسلّم مباشرة (يتجاوز Worker) | مسار تسليم ثانٍ = تكرار + تعقيد |
| FSM يسمح بـ `dead → pending` كانتقال عادي | يُضعف معنى "نهائي" + لا يفرض audit |
| audit في logs فقط (لا في DB) | logs قابلة للضياع، تدقيق DLQ يحتاج دواماً |

---

## النتائج

**إيجابية:**
- المشغّل لديه مسار قانوني واحد لإعادة المعالجة — لا تعديل يدوي في DB.
- audit دائم في DB (`replay_count`, `by`, `reason`) — تدقيق كامل.
- مسار تسليم وحيد (الـ Worker) — لا تكرار، لا فروع.
- `force_replay` يحرس FSM — يرفض من أي حالة غير `dead`.

**ديون مؤجّلة:**
- لا API endpoints بعد (Feature Freeze + API layer لم تُبنَ). الـ
  `outbox_management` متاح في الـ container، يُعرَّض عبر admin routes لاحقاً.
- لا تنبيهات تلقائية (alerts) عند تضخّم DLQ — يُضاف في مرحلة Observability.

---

## الإثبات

اختبارات end-to-end (10 سيناريوهات): stats، list_dead مع filter+pagination،
replay سعيد، replay لرسالة غير موجودة (مرفوض)، replay لرسالة غير dead
(مرفوض)، replay بلا `replayed_by` (مرفوض)، purge، round-trip للـ audit
في DB. كل الاختبارات نجحت. فاحص المعمارية: ✅ صفر انتهاكات. نقاء kernel
محفوظ.
