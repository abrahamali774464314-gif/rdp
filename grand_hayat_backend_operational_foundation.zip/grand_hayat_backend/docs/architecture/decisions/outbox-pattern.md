# ADR-004: Transactional Outbox Pattern (Reliability Layer)

**الحالة:** مقبول ✅
**التاريخ:** 2026-05
**المرحلة:** 4 من خطة Architectural Enforcement
**يخصّ:** موثوقية تسليم الأحداث بين المجالات

---

## السياق

النظام يعتمد على **Event Bus** للتواصل بين المجالات (البند 1 من الدستور:
"Domain → Event Bus → Subscribers"). قبل هذه المرحلة، كان النشر **فورياً
وفي الذاكرة**:

```python
await self._bus.publish_all(entity.pull_events())
```

هذا يخلق مشكلة **dual-write**:

1. الـ Application Service يحفظ الـ aggregate في DB (معاملة 1).
2. ثم ينشر الأحداث عبر الـ bus (عملية منفصلة).

إن سقط التطبيق **بين** الخطوتين، أو فشل أحد الـ subscribers، **تضيع الأحداث**
نهائياً — الغرفة تُشغَل لكن لا إشعار ترحيب، أو المغادرة تكتمل دون طلب نظافة.
في نظام فندقي يعمل 24/7، هذا غير مقبول.

---

## القرار

نُطبّق **Transactional Outbox Pattern** بثلاثة مبادئ:

### 1. فصل العقد النقي عن التنفيذ (احترام نقاء kernel)

| الطبقة | المحتوى | يُسمح بـ |
|--------|---------|---------|
| `kernel/outbox/__init__.py` | `OutboxMessage` (Entity) + `OUTBOX_FSM` + `OutboxRepository` (Protocol) + `compute_backoff_seconds` | stdlib + kernel فقط |
| `shared/outbox/repository.py` | `MongoOutboxRepository` | motor |
| `shared/outbox/service.py` | `OutboxService` (enqueue + dispatch) | — |
| `shared/outbox/worker.py` | `OutboxWorker` (asyncio) | asyncio |
| `shared/outbox/aware_bus.py` | `OutboxAwareBus` (Decorator) | — |

> **ملاحظة بنيوية:** كل عقود الـ kernel في `__init__.py` واحد، تماشياً مع
> نمط بقية وحدات kernel (`bus`, `contracts`, `errors`, `state_machine`...).
> لا تُقسَّم إلى `models.py` + `repository.py` للحفاظ على الاتساق.

### 2. OutboxAwareBus — Decorator Pattern (القرار المحوري)

بدل تعديل **12+ موقع** `bus.publish_all` في المجالات السبعة (ما يكسر
Feature Freeze)، نلفّ الـ `EventBus` بـ decorator شفّاف:

```
Application Service → OutboxAwareBus → enqueue → Outbox
                                                    ↓
                          OutboxWorker → Real EventBus → Subscribers
```

- `subscribe` يمرّ مباشرةً للـ bus الحقيقي (الـ subscribers تبقى عليه).
- `publish` / `publish_all` يُحوّلان إلى `OutboxService.enqueue`.
- الـ Worker يقرأ الـ outbox ويُسلّم عبر **الـ bus الحقيقي**.

**كسر الحلقة:** `OutboxService.dispatch` يُسلّم عبر الـ **Real EventBus**،
لا عبر الـ decorator — وإلا لتشكّلت حلقة لا نهائية
(`dispatch → publish → enqueue → dispatch`).

### 3. Opt-in (الحفاظ على Feature Freeze)

الـ decorator **متاح لكن غير مُفعّل افتراضياً**:

```python
container.outbox_bus            # متاح دائماً بعد bootstrap
container.enable_outbox_delivery()   # تفعيل صريح فقط
```

- افتراضياً: الـ services تنشر فوراً عبر `self.bus` (السلوك الراهن محفوظ).
- عند الاستدعاء الصريح: تُستبدَل `svc._bus` بالـ `OutboxAwareBus` لكل
  الـ services دفعةً واحدة — **دون تعديل سطر واحد في أي service**.

---

## آليات الموثوقية

| الآلية | التفصيل |
|--------|---------|
| **at-least-once** | الحدث يُحفظ قبل التسليم؛ يُعاد حتى ينجح أو يموت |
| **Retry + backoff** | exponential: 2, 4, 8, 16, 32 ثانية (سقف 300) |
| **Dead Letter Queue** | بعد `max_attempts=5` → `status=dead`، يُرصَد عبر `list_dead_messages()` |
| **Idempotency** | `idempotency_key = "{topic}|{event_id}"` — المستهلِكون يحيّدون التكرار |
| **Event cascade** | السلسلة الكاملة (حدث يولّد أحداثاً) تمرّ عبر الـ outbox وتستقرّ |
| **Graceful shutdown** | الـ Worker ينهي دورته الحالية ثم يتوقّف (timeout 10s) |

### State Machine

```
pending ──→ dispatched   (نجاح — نهائي)
   │
   └──→ failed ──→ pending   (إعادة محاولة)
          │
          └──→ dead          (DLQ — نهائي، بعد استنفاد المحاولات)
```

---

## البدائل المرفوضة

| البديل | سبب الرفض |
|--------|-----------|
| تعديل كل `publish_all` يدوياً | يكسر Feature Freeze (12+ موقع، 7 مجالات) |
| توريث `EventBus` بدل Decorator | أقلّ مرونة؛ الـ Decorator يسمح بالتفعيل/الإلغاء |
| Outbox داخل مجال معيّن | Outbox بنية تحتية مشتركة، ليست aggregate مجالياً |
| `kernel/outbox/` يحوي motor | يكسر نقاء kernel (قاعدة دستورية مفروضة آلياً) |

---

## النتائج

**إيجابية:**
- موثوقية at-least-once دون لمس أي مجال.
- نقاء kernel محفوظ (فاحص المعمارية: صفر انتهاكات).
- تفعيل تدريجي آمن (opt-in).

**سلبية / ديون مؤجّلة:**
- `enqueue` الحالي خارج معاملة الـ aggregate (الـ services لم تُمرّر `uow`
  بعد). الترقية الكاملة لـ transactional outbox (enqueue داخل نفس uow)
  مؤجّلة لمرحلة لاحقة عبر `enqueue_in_uow`.
- الـ Worker in-process (asyncio). الانتقال لـ Redis/RabbitMQ ممكن لاحقاً
  دون تغيير المجالات (نفس العقد).

---

## الإثبات

اختبار end-to-end (6 سيناريوهات) أثبت: التهيئة، النشر للـ outbox، تسليم
الـ Worker، backoff، DLQ، واستقرار الـ event cascade الكامل (5 أحداث) — كلها
`dispatched` دون حلقة. فاحص المعمارية: ✅ صفر انتهاكات.
