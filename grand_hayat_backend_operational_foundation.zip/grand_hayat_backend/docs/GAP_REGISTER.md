# Grand Hayat PMS — Gap Register

This register separates completed foundation items from operational gaps. It should be updated after every migration batch.

| ID | Area | Gap | Risk | Status | Next action |
|---|---|---|---|---|---|
| GAP-001 | Identity/Auth | Login previously returned only user data, not access/refresh tokens. | High | Closed in this batch | JWT sessions, refresh, logout, session revoke added. |
| GAP-002 | Identity/Auth | Development `X-User-Id` path could bypass session checks. | Medium | Mitigated | Controlled by `ALLOW_DEV_AUTH`; production should set it to `false`. |
| GAP-003 | API Contracts | Endpoints returned inconsistent response shapes. | High | Partially closed | Contract helpers and standard error payload added; target foundation routers use envelope responses. |
| GAP-004 | Permissions | Permissions were split between legacy and foundation lists. | High | Closed in this batch | Central permission catalog with role presets added. |
| GAP-005 | Settings | Sound/settings were not operationally grouped. | Medium | Closed in this batch | Settings presets and sound-rule endpoints added. |
| GAP-006 | Notifications | Sound events were broadcast without server-side sound policy. | Medium | Closed in this batch | Realtime manager now filters sound payload per actor/rule. |
| GAP-007 | Rooms | Room types were missing from operational API. | High | Closed in this batch | Room types added inside rooms module. |
| GAP-008 | Rooms | Floors had no modular API equivalent. | High | Closed in this batch | Floors added inside rooms module. |
| GAP-009 | Guests/Checkins | Check-in does not yet create/link Guest automatically. | High | Open | Next batch: Guest integration into check-in. |
| GAP-010 | Billing/Folio | Folio is not fully opened/managed by check-in yet. | High | Open | Next batch: open master folio on check-in. |
| GAP-011 | Checkout | Checkout workflow is not fully gated by folio + inspection + housekeeping. | High | Open | Do after billing and requests. |
| GAP-012 | Messaging | SMS/WhatsApp are not migrated to unified messaging flow. | Medium | Open | Do after rooms/guests/checkins/billing. |
| GAP-013 | Integrations | MikroTik/YemenSoft adapters are not operational production flows. | Medium | Open | Do after messaging. |
| GAP-014 | Frontend | Frontend is not mapped to new contracts. | High | Open | Build frontend API adapter after core workflows. |
| GAP-015 | Data Migration | No dry-run data migration has been validated against real DB copy. | High | Open | Run only after core workflow tests. |

## Do-not-start-yet list

- SMS/WhatsApp automation migration.
- MikroTik/YemenSoft production integration.
- Production cutover.
- Frontend screen migration.

These depend on operational Identity, Rooms, Guests, Checkins, and Billing.
