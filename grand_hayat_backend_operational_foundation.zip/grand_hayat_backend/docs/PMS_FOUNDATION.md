# PMS Foundation Contract — Grand Hayat Backend

This document freezes the foundation rules that must stay stable while moving legacy hotel features into the new modular backend. The goal is a strong single-property PMS now, with a clean path to multi-property SaaS later.

## 1. Scope model

Every operational record must carry these fields:

```txt
tenant_id
property_id
created_at
updated_at when mutable
created_by / updated_by when actor-driven
```

For the current single-hotel phase the default scope is:

```txt
tenant_id = default
property_id = main
```

The UI does not need to expose tenancy yet. Internally, every repository and query must keep the scope so the system does not need a rewrite when moving to SaaS.

## 2. Domains included in this foundation

```txt
rooms
checkins
checkouts
requests
inspections
billing
notifications
identity
properties
guests
reservations
settings
messaging
audit
storage
```

The first eight domains are the operational PMS core. The last seven are the foundation layer needed before migrating the legacy app features.

## 3. Status dictionaries

Use only the central status language from `app/shared/foundation/constants.py`.

### Room

```txt
available
reserved
occupied
dirty
cleaning
inspected
maintenance
out_of_order
```

### Check-in

```txt
active
checked_out
cancelled
deleted
```

### Checkout

```txt
pending
in_progress
completed
cancelled
```

### Request

```txt
pending
accepted
in_progress
completed
cancelled
rejected
```

### Reservation

```txt
draft
confirmed
checked_in
cancelled
no_show
```

### Folio

```txt
open
closed
void
```

## 4. Identity and permissions

Roles are not enough. Every protected action must use permission checks.

Current role model:

```txt
super_admin      SaaS/platform-level owner; can cross tenant/property boundaries.
admin            Property-level admin; scoped to tenant/property.
supervisor       Floor/department scoped.
staff            Floor/department/action scoped.
```

Rules:

- Do not put ad-hoc `if role == "admin"` checks inside business logic.
- Use `require_permission(...)` in API and application policies/scoping rules in services.
- Super admin is the only role that may list across tenants/properties.
- Admin is powerful but still property-scoped.

## 5. Settings model

Settings are never global only by key. They are scoped:

```txt
tenant_id + property_id + module + key
```

Examples:

```txt
messaging / auto_reply
sounds / rules
integrations / sms_gateway
checkouts / checklist
```

## 6. Messaging model

SMS and WhatsApp are not separate business domains. They are channels inside the `messaging` domain:

```txt
conversation
message
channel = sms | whatsapp | email | internal
direction = in | out
```

External delivery is a notification/integration concern. Guest conversations remain unified.

## 7. Billing model

Checkout must not become only a room-status operation. The financial foundation is:

```txt
Folio
FolioTransaction
balance()
charge/payment/discount/reversal
```

Financial entries are append-only. Reversals are explicit transactions and do not mutate the original transaction.

## 8. Guest and reservation model

A guest is an independent entity. Check-in may keep snapshots of guest data, but guest identity must be reusable across reservations, stays, folios, and messages.

Reservations are included at foundation level even if the first production flow is walk-in check-in. Check-in should be able to reference `reservation_id` later without model surgery.

## 9. Audit and storage

Audit records must include:

```txt
actor_id
action
tenant_id
property_id
resource_type
resource_id
before/after/metadata
ip/user_agent when available
```

Files are represented through `storage` records rather than hard-coded local paths. The current storage module registers metadata and can later be backed by local disk, S3, MinIO, or Cloudinary.

## 10. Architecture rule

Routers remain thin:

```txt
API Router → Application Service → Domain Model → Repository → Infrastructure Adapter
```

The only allowed cross-domain wiring point is:

```txt
app/shared/config/container.py
```

No legacy router should be copied directly into the new app. Move the business rule into the correct application/domain layer and keep the API as a thin adapter.

## 11. Migration rule

Legacy data must be migrated into the default scope first:

```txt
tenant_id = default
property_id = main
```

Then modules can be migrated feature-by-feature. Do not migrate WhatsApp/SMS, checkout, or billing before rooms, identity, guests, folios, settings, notifications, and audit are stable.
