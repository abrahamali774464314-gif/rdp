# Grand Hayat PMS — Migration Map Lite

This file is intentionally lightweight. It maps the legacy single-hotel backend features to the modular PMS Foundation without forcing a full migration plan before the core workflows are operational.

## Rules

1. Do not copy legacy routers directly into the new backend.
2. Move behaviour into application services; keep routers thin.
3. Preserve current hotel operations first, then improve the domain model.
4. Every migrated record must carry `tenant_id` and `property_id`.
5. External channels such as SMS, WhatsApp, MikroTik, and YemenSoft stay behind adapters/outbox and must not be called from routers.

## Feature Map

| Legacy feature | Legacy files / area | New owner | Priority | Decision | Notes |
|---|---|---|---:|---|---|
| Auth / login | `routers/auth.py`, `core/security.py`, `core/deps.py` | `modules/identity` + `shared/auth` | P0 | Complete now | JWT, refresh sessions, logout, `/me`, session revocation. |
| Users / roles | `routers/users.py`, `core/permissions.py` | `modules/identity` | P0 | Complete now | Permission based, not role-only. |
| Permissions catalog | `core/permissions.py` | `shared/foundation/permissions.py` | P0 | Complete now | Central catalog, Arabic labels, role presets. |
| Floors | `routers/rooms.py` | `modules/rooms` | P1 | Complete now | Scoped by tenant/property. |
| Rooms | `routers/rooms.py`, `services/room_service.py` | `modules/rooms` | P1 | Complete now | Status FSM, room type, soft delete later. |
| Room types | not explicit in legacy | `modules/rooms` | P1 | Add now | Required for PMS-grade rates/capacity. |
| Settings | `db.settings`, SMS/checkout/sound settings | `modules/settings` | P1 | Complete now | Scoped by module/key/property. |
| Sound rules | `routers/sound_settings.py`, `core/permissions.py` | `modules/settings` + `modules/notifications` + `shared/realtime` | P1 | Complete now | Server decides which user receives sound. |
| Notifications / WebSocket | `services/notify.py`, `server.py` | `modules/notifications` + `shared/realtime` | P1 | Complete now | Domain event → notification → realtime payload. |
| Guests | implicit in checkins/rooms | `modules/guests` | P2 | Next | Link guest to check-in before messaging migration. |
| Check-ins | `routers/checkins.py`, `services/checkin_service.py` | `modules/checkins` | P2 | Next | Must create/link guest and open folio. |
| Folios / Billing | partial / external accounting | `modules/billing` | P2 | Next | Complete before final checkout workflow. |
| Requests | `routers/requests.py`, `services/request_service.py` | `modules/requests` | P3 | Later | Depends on rooms, permissions, notifications. |
| Checkout | `routers/checkouts.py`, `services/checkout_service.py` | `modules/checkouts` | P3 | Later | Depends on folio and inspections. |
| Inspections / photos | `routers/room_inspections.py` | `modules/inspections` + `modules/storage` | P3 | Later | Use StoragePort, not raw local paths. |
| SMS | `routers/sms.py`, `services/sms_sender.py` | `modules/messaging` + `modules/notifications` | P4 | Later | Unify with WhatsApp as a channel. |
| WhatsApp | `routers/whatsapp.py` | `modules/messaging` + integrations | P4 | Later | Do not start before guests/checkins. |
| MikroTik vouchers | SMS/WhatsApp helpers | `modules/integrations` | P5 | Later | Adapter + settings + delivery logs. |
| YemenSoft | `routers/integrations.py` | `modules/integrations` | P5 | Later | Adapter + sync logs. |
| Consistency checks | `routers/consistency.py`, `services/consistency.py` | future `consistency` service/tool | P5 | Later | Add after core workflows. |
| Frontend | existing panel | API client / adapter layer | P6 | Later | Do not migrate screens before contracts stabilize. |
| Data migration | direct DB copy/scripts | `tools/migrate_tenant_property.py` + new scripts | P6 | Later | Dry run before production. |

## Immediate Scope

The current implementation batch covers:

1. Identity/Auth operational completion.
2. API contracts.
3. Permissions catalog finalization.
4. Settings/Sounds/Notifications operational flow.
5. Rooms/Floors/Room Types completion.

SMS, WhatsApp, billing completion, guest-linked check-in, and production migration are intentionally outside this batch.
