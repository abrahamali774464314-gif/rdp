"""
app.server — Composition Root للـ FastAPI app
═══════════════════════════════════════════════════════════════════

نقطة الإقلاع الوحيدة للتطبيق. تجمع:
  - تهيئة قاعدة البيانات (motor) — الإنتاج.
  - container.bootstrap(db) — يبني كل الـ services + outbox + scoping.
  - بدء Outbox Worker في startup، إيقاف graceful في shutdown.
  - تسجيل routers من المجالات (modules/<domain>/api/router.py).
  - معالجات أخطاء موحّدة (تحوّل أخطاء kernel إلى HTTP responses).

ملاحظة:
  - لا منطق أعمال هنا — composition only.
  - لا استيراد infrastructure مباشر من المجالات (كل شيء عبر container).
  - الـ routers تُستورد لُحُمَتها (lazy في lifespan ليكون container جاهزاً).
"""
from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from contextlib import asynccontextmanager

APP_ROOT = Path(__file__).resolve().parent
if str(APP_ROOT) not in sys.path:
    sys.path.insert(0, str(APP_ROOT))

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException
from motor.motor_asyncio import AsyncIOMotorClient

from kernel.errors import (
    ConflictError,
    FinancialImmutabilityError,
    InvariantViolationError,
    NotFoundError,
    PermissionDeniedError,
    ValidationError,
)
from kernel.state_machine import IllegalTransitionError
from shared.config.container import container
from shared.config.indexes import ensure_indexes
from shared.api.responses import error_payload

logger = logging.getLogger("grandhayat.server")


# ══════════════════════════════════════════════════════════════
# Lifespan: bootstrap → Worker → shutdown
# ══════════════════════════════════════════════════════════════
@asynccontextmanager
async def lifespan(app: FastAPI):
    mongo_url = os.environ.get("MONGO_URL")
    db_name = os.environ.get("DB_NAME", "grand_hayat")
    if not mongo_url:
        raise RuntimeError("MONGO_URL env var مطلوب")

    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    logger.info("اتصال DB: %s", db_name)

    await ensure_indexes(db)
    await container.bootstrap(db, client=client)
    logger.info("container جاهز — 15 مجالاً مربوطة")

    # Outbox Worker (Reliability Layer) — يبدأ بالخلفية
    if container.outbox_worker:
        container.outbox_worker.start()
        logger.info("Outbox Worker بدأ")

    try:
        yield
    finally:
        if container.outbox_worker:
            await container.outbox_worker.stop()
            logger.info("Outbox Worker توقّف بأمان")
        client.close()
        logger.info("DB closed")


# ══════════════════════════════════════════════════════════════
# تطبيق FastAPI
# ══════════════════════════════════════════════════════════════
app = FastAPI(
    title="Grand Hayat Hotel System",
    version="2.0.0",
    lifespan=lifespan,
)



class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        return response

# CORS — للوحة الإدارية React/Next
cors_origins = os.environ.get("CORS_ORIGINS", "*")
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in cors_origins.split(",")] if cors_origins != "*" else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ══════════════════════════════════════════════════════════════
# معالجات أخطاء موحَّدة — تحويل kernel exceptions إلى HTTP
# ══════════════════════════════════════════════════════════════
# نقطة معمارية: الـ routers لا تلتقط هذه الأخطاء يدوياً (يكسر thinness).
# هنا في مكان واحد، تتحوّل لرسائل HTTP مناسبة.

@app.exception_handler(NotFoundError)
async def _not_found(req: Request, exc: NotFoundError):
    return JSONResponse(status_code=404, content=error_payload("NOT_FOUND", str(exc)))

@app.exception_handler(PermissionDeniedError)
async def _forbidden(req: Request, exc: PermissionDeniedError):
    return JSONResponse(status_code=403, content=error_payload("PERMISSION_DENIED", str(exc)))

@app.exception_handler(ConflictError)
async def _conflict(req: Request, exc: ConflictError):
    return JSONResponse(status_code=409, content=error_payload("CONFLICT", str(exc)))

@app.exception_handler(IllegalTransitionError)
async def _illegal_transition(req: Request, exc: IllegalTransitionError):
    return JSONResponse(status_code=409, content=error_payload("ILLEGAL_TRANSITION", str(exc)))

@app.exception_handler(FinancialImmutabilityError)
async def _financial(req: Request, exc: FinancialImmutabilityError):
    return JSONResponse(status_code=422, content=error_payload("FINANCIAL_IMMUTABILITY", str(exc)))

@app.exception_handler(InvariantViolationError)
async def _invariant(req: Request, exc: InvariantViolationError):
    return JSONResponse(status_code=422, content=error_payload("INVARIANT_VIOLATION", str(exc)))

@app.exception_handler(ValidationError)
async def _validation(req: Request, exc: ValidationError):
    return JSONResponse(status_code=422, content=error_payload("VALIDATION_ERROR", str(exc)))

@app.exception_handler(RequestValidationError)
async def _request_validation(req: Request, exc: RequestValidationError):
    return JSONResponse(status_code=422, content=error_payload("REQUEST_VALIDATION_ERROR", "بيانات الطلب غير صحيحة", details=exc.errors()))

@app.exception_handler(StarletteHTTPException)
async def _http_exception(req: Request, exc: StarletteHTTPException):
    code = "HTTP_ERROR" if exc.status_code < 500 else "SERVER_ERROR"
    return JSONResponse(status_code=exc.status_code, content=error_payload(code, str(exc.detail)))

@app.exception_handler(Exception)
async def _unhandled(req: Request, exc: Exception):
    logger.exception("Unhandled error on %s: %s", req.url.path, exc)
    return JSONResponse(status_code=500, content=error_payload("INTERNAL_SERVER_ERROR", "خطأ غير متوقع في الخادم"))


# ══════════════════════════════════════════════════════════════
# Health check (لا يحتاج auth)
# ══════════════════════════════════════════════════════════════
@app.get("/health")
async def health():
    return {"data": {"status": "ok", "domains": 15, "foundation": "pms"}, "meta": {}, "error": None}


# ══════════════════════════════════════════════════════════════
# تسجيل Routers من المجالات
# ══════════════════════════════════════════════════════════════
# كل router يعيش في modules/<domain>/api/router.py — الـ CI يحرسها (thin).
from modules.rooms.api.router import router as rooms_router
from modules.checkins.api.router import router as checkins_router
from modules.requests.api.router import router as requests_router
from modules.checkouts.api.router import router as checkouts_router
from modules.inspections.api.router import router as inspections_router
from modules.billing.api.router import router as billing_router
from modules.identity.api.router import router as identity_router
from modules.notifications.api.router import router as notifications_router
from modules.properties.api.router import router as properties_router
from modules.guests.api.router import router as guests_router
from modules.reservations.api.router import router as reservations_router
from modules.settings.api.router import router as settings_router
from modules.messaging.api.router import router as messaging_router
from modules.audit.api.router import router as audit_router
from modules.storage.api.router import router as storage_router

API_PREFIX = "/api/v1"
for domain_router in (
    rooms_router,
    checkins_router,
    requests_router,
    checkouts_router,
    inspections_router,
    billing_router,
    identity_router,
    notifications_router,
    properties_router,
    guests_router,
    reservations_router,
    settings_router,
    messaging_router,
    audit_router,
    storage_router,
):
    app.include_router(domain_router, prefix=API_PREFIX)
