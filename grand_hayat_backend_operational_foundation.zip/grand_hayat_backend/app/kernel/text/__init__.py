"""
kernel.text — تعقيم النصوص النقي
═══════════════════════════════════════════════════════════════════
تنظيف/تقليم النصوص لتحييد XSS البسيط. أداة نقية (لا DB، لا side effects).
الأصل: core.security.sanitize في النظام القديم — نُقل للنواة ليستخدمه المجال.
"""
from __future__ import annotations

import html


def sanitize(value, max_len: int = 200):
    """يقلّم + يهرّب HTML. يُرجع None كما هي، وغير النصوص كما هي."""
    if value is None:
        return None
    if not isinstance(value, str):
        return value
    v = html.escape(value.strip())
    if max_len and len(v) > max_len:
        v = v[:max_len]
    return v
