"""
kernel.security.query_scoper — العقد النقي لنطاق الوصول (Scoping)
═══════════════════════════════════════════════════════════════════

هذا الملف يُجيب على سؤال **"ماذا يستطيع الفاعل أن يرى؟"** — لا "كيف
أستعلم عنه؟". الفصل بين السؤالين هو جوهر التصميم:

  ┌─────────────────────────────────────────────────────────────┐
  │  kernel/security  →  السياسة: ما النطاق المسموح؟ (محايد DB)   │
  │  shared/security  →  الترجمة: كيف أُحوّله لاستعلام Mongo؟      │
  └─────────────────────────────────────────────────────────────┘

لذلك هذا الملف **نقيّ تماماً**:
  - لا motor، لا MongoDB syntax، لا {"_id": "__no_match__"}.
  - مجرّد قيمة تصف النطاق (AccessScope) + عقد لمن يحسبها (ScopeResolver).

النتيجة (AccessScope) قيمة محايدة:
  - full_access      → الفاعل يرى كل شيء (admin)
  - denied          → الفاعل لا يرى شيئاً (لا أدوار/طوابق)
  - مقيّد بـ:
      floors        → مجموعة الطوابق المسموحة (None = كل الطوابق)
      departments   → مجموعة الأقسام (None = كل الأقسام)
      owner_id      → إن لزم own_only، معرّف الفاعل (None = لا قيد ملكية)
      owner_fields  → أسماء الحقول التي تُقارن بـ owner_id

الـ shared layer يأخذ هذه القيمة ويبني استعلام Mongo منها.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable


# ══════════════════════════════════════════════════════════════
# AccessScope — نتيجة حساب النطاق (Value Object نقي، محايد DB)
# ══════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class AccessScope:
    """يصف ما يُسمح للفاعل برؤيته — دون أي معرفة بقاعدة البيانات.

    ثلاث حالات جذرية:
      ① full_access=True   → بلا قيود (admin). كل الحقول الأخرى تُتجاهَل.
      ② denied=True        → لا شيء مرئيّ (لا طوابق/أدوار). أولوية مطلقة.
      ③ غير ذلك            → مقيّد بالحقول أدناه.

    الحقول المقيِّدة (تُطبَّق بـ AND منطقي عند الترجمة):
      floors        : مجموعة طوابق مسموحة. None = لا قيد طابق.
      departments   : مجموعة أقسام مسموحة. None = لا قيد قسم.
      owner_id      : إن لزم own_only، معرّف الفاعل. None = لا قيد ملكية.
      owner_fields  : الحقول التي يُطابَق أيّها owner_id (OR بينها).
                      مثال: ("created_by","accepted_by") → يرى ما أنشأ أو قبِل.
    """
    full_access: bool = False
    denied: bool = False
    tenant_id: str | None = None
    property_ids: frozenset[str] | None = None
    active_property_id: str | None = None
    floors: frozenset[int] | None = None
    departments: frozenset[str] | None = None
    owner_id: str | None = None
    owner_fields: tuple[str, ...] = ()

    # ── مُنشئات مريحة (factory methods) ───────────────────────
    @staticmethod
    def allow_all() -> "AccessScope":
        """admin — يرى كل شيء."""
        return AccessScope(full_access=True)

    @staticmethod
    def deny() -> "AccessScope":
        """لا شيء مرئيّ — فاعل بلا طوابق/أدوار."""
        return AccessScope(denied=True)

    @staticmethod
    def restricted(*, tenant_id: str | None = None,
                   property_ids: frozenset[str] | None = None,
                   active_property_id: str | None = None,
                   floors: frozenset[int] | None = None,
                   departments: frozenset[str] | None = None,
                   owner_id: str | None = None,
                   owner_fields: tuple[str, ...] = ()) -> "AccessScope":
        return AccessScope(
            tenant_id=tenant_id, property_ids=property_ids,
            active_property_id=active_property_id,
            floors=floors, departments=departments,
            owner_id=owner_id, owner_fields=owner_fields,
        )

    # ── استعلامات على القيمة نفسها (للاختبار/الوضوح) ──────────
    @property
    def is_unrestricted(self) -> bool:
        return self.full_access and not self.denied

    @property
    def is_empty(self) -> bool:
        return self.denied

    def has_tenant_constraint(self) -> bool:
        return not self.full_access and bool(self.tenant_id)

    def has_property_constraint(self) -> bool:
        return not self.full_access and (self.active_property_id is not None or self.property_ids is not None)

    def has_floor_constraint(self) -> bool:
        return not self.full_access and self.floors is not None

    def has_department_constraint(self) -> bool:
        return not self.full_access and self.departments is not None

    def has_owner_constraint(self) -> bool:
        return (not self.full_access and self.owner_id is not None
                and bool(self.owner_fields))


# ══════════════════════════════════════════════════════════════
# Actor — الحد الأدنى مما نحتاجه عن الفاعل (محايد عن مجال identity)
# ══════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class Actor:
    """صورة مبسّطة للفاعل لأغراض الـ scoping فقط.

    لا نعتمد على UserEntity من مجال identity (عزل المجالات). الـ application
    يبني Actor من المستخدم الحالي قبل تمريره للـ scoper.
    """
    id: str
    role: str
    floors: frozenset[int] = field(default_factory=frozenset)
    department: str = "general"
    request_types: frozenset[str] = field(default_factory=frozenset)
    permissions: frozenset[str] = field(default_factory=frozenset)
    tenant_id: str | None = None
    property_ids: frozenset[str] = field(default_factory=frozenset)
    active_property_id: str | None = None
    name: str = ""

    def has_permission(self, permission: str) -> bool:
        if self.role in {"super_admin", "admin"}:
            return True
        return permission in self.permissions

    def can_access_property(self, property_id: str | None) -> bool:
        if self.role in {"super_admin", "admin"}:
            return True
        if not property_id:
            return False
        return property_id in self.property_ids


# ══════════════════════════════════════════════════════════════
# ScopeResolver — العقد: من يحسب الـ AccessScope؟
# ══════════════════════════════════════════════════════════════
@runtime_checkable
class ScopeResolver(Protocol):
    """يحسب AccessScope لفاعل على نوع مورد معيّن.

    التنفيذ (في scoping_rules.py) يطبّق القواعد الذهبية الثلاث.
    الـ application يستدعيه، ثم يمرّر النتيجة للـ shared layer للترجمة.
    """

    def resolve(self, actor: Actor, *, own_only: bool = False) -> AccessScope:
        """يُرجع نطاق ما يستطيع الفاعل رؤيته من هذا المورد."""
        ...


# ══════════════════════════════════════════════════════════════
# QueryScoper — العقد: من يترجم AccessScope إلى استعلام؟
# ══════════════════════════════════════════════════════════════
@runtime_checkable
class QueryScoper(Protocol):
    """يترجم (base_query + AccessScope) إلى استعلام مُقيَّد.

    التنفيذ في shared/security (Mongo). يبقى هنا كعقد فقط ليتمكّن الـ
    application من الاعتماد على التجريد دون معرفة صياغة الاستعلام.
    """

    def apply(self, base_query: dict, scope: AccessScope, *,
              floor_field: str = "floor",
              department_field: str = "department") -> dict:
        """يدمج قيود الـ scope في base_query ويُعيد الاستعلام النهائي."""
        ...
