"""
kernel.security.scoping_rules — القواعد الأمنية المركزية (نقية)
═══════════════════════════════════════════════════════════════════

القواعد الذهبية الثلاث (منقولة من النظام القديم core/scope.py، لكن
كمنطق نقيّ يُنتج AccessScope بدل استعلامات Mongo):

  ① admin              → يرى كل شيء (full_access).
  ② supervisor         → يرى سجلّات طوابقه المسموحة؛ وإن كان قسمه ≠ general،
                          فقط ما يطابق قسمه/أنواع طلباته.
  ③ staff              → يرى عمل طوابقه/قسمه، لكن السجلّات/التاريخ قد تُقيَّد
                          بأفعاله هو فقط (own_only).

المبدأ: هذا الملف **لا يعرف Mongo**. ينتج وصفاً منطقياً للنطاق (AccessScope)
يترجمه shared/security لاحقاً. هذا يجعل القواعد قابلة للاختبار بمعزل تام عن DB.

نقطة مهمّة: "ماذا أرى" مركزيّ هنا في مكان واحد — لا يتسرّب إلى repositories
ولا services. أي تغيير في سياسة الرؤية يحدث هنا فقط.
"""
from __future__ import annotations

from kernel.security.query_scoper import AccessScope, Actor

# الأدوار (نسخة محايدة — لا نعتمد على مجال identity مباشرةً)
ROLE_SUPER_ADMIN = "super_admin"
ROLE_ADMIN = "admin"
ROLE_SUPERVISOR = "supervisor"
ROLE_STAFF = "staff"

DEPARTMENT_GENERAL = "general"

# حقول الملكية الافتراضية لكل نوع مورد (للـ own_only)
# تُمرَّر صراحةً عند الحاجة، وهذه افتراضات منطقية موثّقة.
OWNER_FIELDS_REQUESTS = ("created_by", "accepted_by", "completed_by")
OWNER_FIELDS_CHECKOUTS = ("created_by", "processed_by")
OWNER_FIELDS_CHECKINS = ("created_by", "updated_by", "deleted_by", "checked_out_by")
OWNER_FIELDS_INSPECTIONS = ("created_by",)


# ══════════════════════════════════════════════════════════════
# الدوال المساعدة النقية (تعكس core/scope.py القديم)
# ══════════════════════════════════════════════════════════════
def _is_super_admin(actor: Actor) -> bool:
    return actor.role == ROLE_SUPER_ADMIN

def _is_admin(actor: Actor) -> bool:
    return actor.role in {ROLE_SUPER_ADMIN, ROLE_ADMIN}


def _floor_scope(actor: Actor) -> frozenset[int] | None:
    """طوابق الفاعل المسموحة. admin → None (كل الطوابق)."""
    if _is_admin(actor):
        return None
    return actor.floors  # frozenset (قد تكون فارغة → deny لاحقاً)


def _department_scope(actor: Actor) -> frozenset[str] | None:
    """أقسام الفاعل المسموحة. admin أو general → None (كل الأقسام)."""
    if _is_admin(actor) or actor.department == DEPARTMENT_GENERAL:
        return None
    return frozenset({actor.department})


# ══════════════════════════════════════════════════════════════
# ScopingRules — يُنفّذ ScopeResolver للموارد المختلفة
# ══════════════════════════════════════════════════════════════
class ScopingRules:
    """يحسب AccessScope حسب الدور + الطابق + القسم + الملكية.

    صنف واحد بدوال متخصّصة لكل نوع مورد (لاختلاف حقول الملكية). كلها
    تتبع القواعد الذهبية الثلاث، وتختلف فقط في owner_fields وهل يُطبَّق
    قيد القسم.
    """

    # ── المنطق الجوهري المشترك ────────────────────────────────
    def _base_scope(self, actor: Actor, *, own_only: bool,
                    owner_fields: tuple[str, ...],
                    apply_department: bool) -> AccessScope:
        # ① super_admin → كل شيء عابر لكل tenants/properties
        if _is_super_admin(actor):
            return AccessScope.allow_all()

        # فاعل بلا طوابق = لا يرى شيئاً (القاعدة القديمة: floors فارغة → deny)
        floors = _floor_scope(actor)
        if floors is not None and len(floors) == 0:
            return AccessScope.deny()

        departments = _department_scope(actor) if apply_department else None

        # ③ own_only يُطبَّق فقط على staff (كما النظام القديم)
        owner_id = None
        of: tuple[str, ...] = ()
        if own_only and actor.role == ROLE_STAFF:
            owner_id = actor.id
            of = owner_fields

        property_ids = None if _is_admin(actor) else (actor.property_ids or None)
        active_property_id = None if _is_admin(actor) else actor.active_property_id
        return AccessScope.restricted(
            tenant_id=actor.tenant_id, property_ids=property_ids,
            active_property_id=active_property_id,
            floors=floors, departments=departments,
            owner_id=owner_id, owner_fields=of,
        )

    # ── موارد بطابق فقط (rooms) ───────────────────────────────
    def for_rooms(self, actor: Actor) -> AccessScope:
        """الغرف تُقيَّد بالطابق فقط (لا قسم، لا ملكية)."""
        return self._base_scope(
            actor, own_only=False, owner_fields=(), apply_department=False)

    # ── checkins (طابق + own_only) ────────────────────────────
    def for_checkins(self, actor: Actor, *, own_only: bool = True) -> AccessScope:
        return self._base_scope(
            actor, own_only=own_only,
            owner_fields=OWNER_FIELDS_CHECKINS, apply_department=False)

    # ── checkouts (طابق + own_only) ───────────────────────────
    def for_checkouts(self, actor: Actor, *, own_only: bool = False) -> AccessScope:
        return self._base_scope(
            actor, own_only=own_only,
            owner_fields=OWNER_FIELDS_CHECKOUTS, apply_department=False)

    # ── requests (طابق + قسم + own_only) — الأكثر تقييداً ─────
    def for_requests(self, actor: Actor, *, own_only: bool = False) -> AccessScope:
        return self._base_scope(
            actor, own_only=own_only,
            owner_fields=OWNER_FIELDS_REQUESTS, apply_department=True)

    # ── inspections (طابق + قسم + own_only للـ staff) ─────────
    def for_inspections(self, actor: Actor, *, own_only: bool = True) -> AccessScope:
        return self._base_scope(
            actor, own_only=own_only,
            owner_fields=OWNER_FIELDS_INSPECTIONS, apply_department=True)


# ══════════════════════════════════════════════════════════════
# دوال نقية مستقلّة (للفحوص النقطية — تعكس core/scope.py القديم)
# ══════════════════════════════════════════════════════════════
def is_floor_allowed(actor: Actor, floor: int | None) -> bool:
    """هل يُسمح للفاعل بهذا الطابق؟ (للتحقّق النقطي قبل الكتابة)."""
    if _is_admin(actor):
        return True
    if floor is None or not actor.floors:
        return False
    return int(floor) in actor.floors


def is_request_type_allowed(actor: Actor, request_type: str | None,
                            department: str | None = None) -> bool:
    """هل يُسمح للفاعل بهذا النوع من الطلبات؟ (تعكس القديم)."""
    if _is_admin(actor):
        return True
    if actor.department == DEPARTMENT_GENERAL:
        return True
    if department and department == actor.department:
        return True
    if actor.request_types:
        return request_type in actor.request_types
    return True
