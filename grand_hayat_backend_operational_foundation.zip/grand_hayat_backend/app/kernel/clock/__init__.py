"""
kernel.clock — أداة الوقت النقية
═══════════════════════════════════════════════════════════════════
أداة زمنية بلا حالة وبلا side effects — صالحة للاستخدام في كل الطبقات.
عزلها في النواة يسمح بحقن ساعة وهمية في الاختبارات (determinism).
"""
from __future__ import annotations

from datetime import datetime, timezone


def now_iso() -> str:
    """الوقت الحالي UTC بصيغة ISO-8601."""
    return datetime.now(timezone.utc).isoformat()
