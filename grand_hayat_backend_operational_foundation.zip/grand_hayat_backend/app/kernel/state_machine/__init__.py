"""
kernel.state_machine — محرّك انتقالات الحالة (State Machine Authority)
═══════════════════════════════════════════════════════════════════

ينفّذ بنود الدستور:
  - البند 3: "ممنوع تعديل الحالة بدون Transition Engine"
  - البند 4: "State Machine Authority — كل تغيير حالة يمر عبر Engine"

كل domain له state machine خاص به (مثلاً: الغرفة available→occupied→cleaning).
لا يُعدَّل حقل الحالة بإسناد مباشر أبداً؛ يجب المرور عبر `transition()`
الذي يتحقق من شرعية الانتقال ويرمي خطأ عند انتقال غير مسموح.

الاستخدام:
    ROOM_FSM = StateMachine(
        name="room",
        transitions={
            "available": {"occupied", "maintenance", "cleaning"},
            "occupied":  {"cleaning", "maintenance"},
            "cleaning":  {"available", "maintenance"},
            "maintenance": {"available", "cleaning"},
        },
    )
    new_state = ROOM_FSM.transition(room.status, "occupied")  # ✓
    ROOM_FSM.transition("cleaning", "occupied")               # ✗ يرمي IllegalTransition
"""
from __future__ import annotations

from dataclasses import dataclass


class IllegalTransitionError(Exception):
    """انتقال حالة غير مسموح به حسب الـ state machine."""

    def __init__(self, machine: str, src: str, dst: str) -> None:
        self.machine = machine
        self.src = src
        self.dst = dst
        super().__init__(
            f"انتقال غير مسموح في «{machine}»: {src} ⇒ {dst}"
        )


@dataclass(frozen=True)
class StateMachine:
    """محرّك انتقالات معرّف بخريطة الانتقالات المسموحة.

    name        : اسم الآلة (للأخطاء والـ logs)
    transitions : dict[state -> set[states المسموح الانتقال إليها]]
    terminal    : حالات نهائية لا انتقال منها (اختياري)
    """

    name: str
    transitions: dict[str, set[str]]
    terminal: frozenset[str] = frozenset()

    @property
    def states(self) -> set[str]:
        all_states = set(self.transitions.keys())
        for targets in self.transitions.values():
            all_states |= targets
        return all_states

    def can_transition(self, src: str, dst: str) -> bool:
        # حالة نهائية: لا انتقال منها أبداً — ولا حتى إلى نفسها (لا اكتمال مزدوج)
        if src in self.terminal:
            return False
        if src == dst:
            return True  # no-op على الحالات غير النهائية مسموح (idempotent)
        return dst in self.transitions.get(src, set())

    def transition(self, src: str, dst: str) -> str:
        """يتحقق من الانتقال ويُرجع الحالة الجديدة. يرمي IllegalTransitionError عند الرفض.

        هذه الدالة هي البوابة الوحيدة لتغيير الحالة. الـ Domain Entities
        تستدعيها داخل ميثوداتها (مثلاً Room.check_in())، ولا تُسند الحالة مباشرة.

        الحالات النهائية تُرفض كل انتقال منها — حتى إلى نفسها — لمنع
        الاكتمال المزدوج (مثلاً: تقرير فحص لا يُكمَل مرّتين).
        """
        if not self.can_transition(src, dst):
            raise IllegalTransitionError(self.name, src, dst)
        return dst

    def assert_valid_state(self, state: str) -> None:
        if state not in self.states:
            raise ValueError(f"حالة غير معروفة في «{self.name}»: {state}")
