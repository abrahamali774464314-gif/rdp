"""
kernel.errors — تسلسل الأخطاء المشترك
═══════════════════════════════════════════════════════════════════

أخطاء المجال لا تعرف شيئاً عن HTTP. الـ API Layer هو من يترجمها إلى
status codes (راجع platform/api error handlers). هذا يحافظ على نقاء
الـ Domain Layer (البند 2: المجال لا يلمس الـ side effects/البروتوكولات).
"""
from __future__ import annotations


class DomainError(Exception):
    """جذر كل أخطاء المجال. يحمل رسالة عربية + رمز دلالي."""

    code: str = "domain_error"
    http_status: int = 400

    def __init__(self, message: str, *, code: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        if code:
            self.code = code


class NotFoundError(DomainError):
    code = "not_found"
    http_status = 404


class ConflictError(DomainError):
    """تعارض في الحالة (مثلاً: الغرفة مشغولة بالفعل)."""
    code = "conflict"
    http_status = 409


class PermissionDeniedError(DomainError):
    code = "permission_denied"
    http_status = 403


class ValidationError(DomainError):
    code = "validation_error"
    http_status = 422


class InvariantViolationError(DomainError):
    """خرق لثابت من ثوابت المجال (Domain Invariant)."""
    code = "invariant_violation"
    http_status = 409


class FinancialImmutabilityError(DomainError):
    """محاولة تعديل بيانات مالية مثبّتة — يُسمح فقط بقيود عكسية.

    تنفيذاً للبند 3: "ممنوع تعديل البيانات المالية بعد التثبيت".
    """
    code = "financial_immutable"
    http_status = 409
