"""
kernel.guards — حُرّاس وقت التشغيل (Runtime Guards)
═══════════════════════════════════════════════════════════════════

ينفّذ البند 5 من الدستور: "Runtime Guards في Debug/Staging".

بينما يفرض الـ import-linter القواعد ساكناً (static)، تفرض هذه الحُرّاس
القواعد ديناميكياً عند التشغيل في بيئات غير الإنتاج، لالتقاط الانتهاكات
التي لا يراها التحليل الساكن (مثلاً: side effect يُنفَّذ من داخل سياق domain).

تُفعَّل فقط عندما APP_ENV ∈ {debug, staging} لتجنّب أي عبء في الإنتاج.
"""
from __future__ import annotations

import functools
import inspect
import logging
import os

logger = logging.getLogger("grandhayat.guards")

APP_ENV = os.environ.get("APP_ENV", "production").lower()
GUARDS_ENABLED = APP_ENV in ("debug", "staging", "test")


class ArchitectureViolation(RuntimeError):
    """انتهاك معماري التُقط في وقت التشغيل."""


# ──────────────────────────────────────────────────────────────
# حارس: ممنوع Side Effects داخل Domain Layer
# ──────────────────────────────────────────────────────────────
def no_side_effects(func):
    """ديكوريتر يوضع على ميثودات الـ Domain Service/Entity.

    يرفع ArchitectureViolation إذا حاول الكود الموسوم لمس side effect
    معروف (HTTP client, WebSocket, SMS gateway) — يُكتشف عبر فحص الـ stack
    أو الـ flag السياقي. حالياً يعمل كعلامة توثيقية + فحص سياقي خفيف.
    """
    if not GUARDS_ENABLED:
        return func

    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        _SideEffectContext.enter_domain(func.__qualname__)
        try:
            return await func(*args, **kwargs)
        finally:
            _SideEffectContext.exit_domain()

    return wrapper


class _SideEffectContext:
    """يتتبّع ما إذا كنّا حالياً داخل سياق domain (حيث الـ side effects ممنوعة)."""

    _depth = 0
    _stack: list[str] = []

    @classmethod
    def enter_domain(cls, name: str) -> None:
        cls._depth += 1
        cls._stack.append(name)

    @classmethod
    def exit_domain(cls) -> None:
        cls._depth = max(0, cls._depth - 1)
        if cls._stack:
            cls._stack.pop()

    @classmethod
    def in_domain(cls) -> bool:
        return cls._depth > 0

    @classmethod
    def current(cls) -> str:
        return cls._stack[-1] if cls._stack else "<none>"


def assert_not_in_domain(side_effect_name: str) -> None:
    """تُستدعى داخل أي side effect (broadcast, send_sms, http call).

    إذا نُفِّذ هذا الـ side effect بينما نحن داخل سياق domain، فهذا انتهاك
    للبند 2 ("Domain → Side Effects ممنوع"). نرفع خطأً في غير الإنتاج.
    """
    if not GUARDS_ENABLED:
        return
    if _SideEffectContext.in_domain():
        raise ArchitectureViolation(
            f"side effect «{side_effect_name}» نُفِّذ من داخل domain "
            f"«{_SideEffectContext.current()}» — هذا ممنوع بالدستور (البند 2). "
            f"انشر حدثاً واجعل subscriber في طبقة platform يتولّى الـ side effect."
        )


# ──────────────────────────────────────────────────────────────
# حارس: ممنوع وصول طبقة معيّنة لـ motor إلا في infrastructure
# ──────────────────────────────────────────────────────────────
def assert_repository_context(caller_module: str) -> None:
    """تُستدعى عند إنشاء أي اتصال motor. تتحقق أن المُستدعي داخل infrastructure."""
    if not GUARDS_ENABLED:
        return
    if "infrastructure" not in caller_module and "kernel.persistence" not in caller_module:
        raise ArchitectureViolation(
            f"وصول لقاعدة البيانات من «{caller_module}» خارج طبقة infrastructure "
            f"— انتهاك Repository Law (البند 3)."
        )


def install_guards() -> None:
    if GUARDS_ENABLED:
        logger.warning(
            "🛡  Runtime Architecture Guards مُفعّلة (APP_ENV=%s). "
            "ستُرفع استثناءات عند انتهاك الدستور.", APP_ENV,
        )
    else:
        logger.info("Runtime guards معطّلة (APP_ENV=%s — الإنتاج).", APP_ENV)
