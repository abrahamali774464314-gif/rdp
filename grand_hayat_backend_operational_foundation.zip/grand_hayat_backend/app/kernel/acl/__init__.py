"""
kernel.acl — طبقة مكافحة الفساد (Anti-Corruption Layer)
═══════════════════════════════════════════════════════════════════

ينفّذ بنود الدستور:
  - البند 2: "Domain → External System (مباشر) ممنوع"
  - البند 4: "Anti-Corruption Layer — كل تكامل خارجي يمر عبر ACL"

أي تكامل مع نظام خارجي (بوابة SMS، MikroTik، WhatsApp/الأوائل، YemenSoft)
يجب أن يُغلَّف خلف Port (واجهة مجرّدة يملكها المجال) و Adapter (تنفيذ في
الـ infrastructure يترجم بين لغة المجال ولغة النظام الخارجي).

المجال يتكلم بمفرداته فقط (مثل: «أرسل رسالة ترحيب»)، والـ ACL تترجمها
إلى تفاصيل البوابة (HTTP, payload, auth headers...). إذا تغيّرت البوابة،
يتغيّر الـ Adapter فقط، ويبقى المجال سليماً.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


# ──────────────────────────────────────────────────────────────
# نتيجة موحّدة لأي تكامل خارجي (تحمي المجال من تفاصيل البوابة)
# ──────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class ExternalResult:
    """نتيجة معيارية لأي عملية ACL — ينجح المجال أو يتعامل مع الفشل بلغته."""
    ok: bool
    reference: str | None = None      # معرّف خارجي (message id, voucher code...)
    raw: dict | None = None           # الرد الخام (للتدقيق فقط، لا يُسرّب للمجال)
    error: str | None = None


# ──────────────────────────────────────────────────────────────
# Port أساسي لأي Adapter خارجي
# ──────────────────────────────────────────────────────────────
class AntiCorruptionAdapter(ABC):
    """الأساس لكل Adapter. يضمن أن كل تكامل خارجي يعرّف اسمه ويُسجَّل.

    التنفيذات تعيش في modules/integrations/infrastructure أو
    modules/notifications/infrastructure حسب المسؤولية.
    """

    @property
    @abstractmethod
    def adapter_name(self) -> str: ...
