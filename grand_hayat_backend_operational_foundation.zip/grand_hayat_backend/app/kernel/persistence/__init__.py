"""
kernel.persistence — Repository Law + Unit of Work
════════════════════════════════════════════════════

MongoDB transactions are opt-in through MONGO_TRANSACTIONS=true. This avoids the
unsafe old behaviour where commit failures were silently swallowed on standalone
MongoDB. In a single-node VPS setup the UoW runs without a session; in a replica
set it can be enabled explicitly and commit failures become real failures.
"""
from __future__ import annotations

import logging
import os
from typing import Protocol, TypeVar, runtime_checkable

T = TypeVar("T")
logger = logging.getLogger("grandhayat.persistence")


@runtime_checkable
class Repository(Protocol[T]):
    async def get(self, id: str) -> T | None: ...
    async def add(self, entity: T) -> T: ...
    async def update(self, entity: T) -> T: ...


class UnitOfWork(Protocol):
    async def __aenter__(self) -> "UnitOfWork": ...
    async def __aexit__(self, *args) -> None: ...
    async def commit(self) -> None: ...
    async def rollback(self) -> None: ...

    @property
    def session(self): ...


_TRANSACTION_UNSUPPORTED_MARKERS = (
    "transaction numbers are only allowed",
    "transactions are not supported",
    "not a replica set",
    "replica set member or mongos",
    "sessions are not supported",
)


def _truthy(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on", "enabled"}
    return bool(value)


def _transaction_not_supported(exc: Exception) -> bool:
    msg = str(exc).lower()
    return any(marker in msg for marker in _TRANSACTION_UNSUPPORTED_MARKERS)


class MongoUnitOfWork:
    """Motor Unit of Work.

    Transactions are disabled by default because many VPS MongoDB deployments are
    standalone. Enable them only after converting MongoDB to a replica set:

        MONGO_TRANSACTIONS=true
    """

    def __init__(self, client, *, transactions_enabled: bool | None = None) -> None:
        self._client = client
        self._session = None
        self._txn_active = False
        self._transactions_enabled = (
            _truthy(os.environ.get("MONGO_TRANSACTIONS", "false"))
            if transactions_enabled is None else bool(transactions_enabled)
        )

    @property
    def session(self):
        return self._session

    async def __aenter__(self) -> "MongoUnitOfWork":
        if not self._transactions_enabled:
            self._session = None
            self._txn_active = False
            return self

        try:
            self._session = await self._client.start_session()
            self._session.start_transaction()
            self._txn_active = True
        except Exception as exc:  # noqa: BLE001
            if _transaction_not_supported(exc):
                logger.warning("Mongo transactions unavailable; continuing without session: %s", exc)
                self._session = None
                self._txn_active = False
                return self
            raise
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        if self._session is None:
            return
        try:
            if exc_type is not None:
                await self.rollback()
            elif self._txn_active:
                await self.commit()
        finally:
            await self._session.end_session()
            self._session = None

    async def commit(self) -> None:
        if self._session and self._txn_active:
            await self._session.commit_transaction()
            self._txn_active = False

    async def rollback(self) -> None:
        if self._session and self._txn_active:
            try:
                await self._session.abort_transaction()
            finally:
                self._txn_active = False


def session_kwargs(uow: UnitOfWork | None) -> dict:
    if uow is None or uow.session is None:
        return {}
    return {"session": uow.session}
