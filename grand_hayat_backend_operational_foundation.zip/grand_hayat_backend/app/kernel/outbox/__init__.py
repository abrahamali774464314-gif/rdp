"""
kernel.outbox — Transactional Outbox: العقد النقي
═══════════════════════════════════════════════════════════════════

طبقة الأحداث الموثوقة. تحلّ مشكلة الـ dual-write:
  قبل  : السجلّ يُحفظ في DB ثم يُنشر الحدث منفصلاً → إن سقط بينهما،
         تضيع الأحداث.
  بعد  : الحدث يُحفظ في outbox **ضمن نفس المعاملة** للسجلّ، ثم Worker
         منفصل يقرأ outbox ويُسلِّم للـ subscribers (at-least-once).

هذا الملف يحوي **العقد فقط** (لا motor، لا I/O):
  - OutboxMessage : Entity النقي + FSM
  - OutboxRepository : Protocol (التنفيذ في shared/outbox)
  - OutboxStatus : ثوابت الحالات

ملاحظة معمارية: لماذا هنا (kernel) لا في مجال؟
  Outbox أداة بنيوية تخدم **كل** المجالات (rooms, checkins, ...) — هي
  جزء من الـ messaging plumbing مثل EventBus. ليست aggregate مجالياً.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from kernel.errors import InvariantViolationError
from kernel.state_machine import StateMachine

# ══════════════════════════════════════════════════════════════
# Status constants
# ══════════════════════════════════════════════════════════════
STATUS_PENDING = "pending"
STATUS_DISPATCHED = "dispatched"
STATUS_FAILED = "failed"
STATUS_DEAD = "dead"        # في DLQ — تجاوز max_attempts

DEFAULT_MAX_ATTEMPTS = 5
DEFAULT_BASE_BACKOFF_SECONDS = 2  # exponential: 2,4,8,16,32

# ══════════════════════════════════════════════════════════════
# State Machine
# ══════════════════════════════════════════════════════════════
OUTBOX_FSM = StateMachine(
    name="outbox",
    transitions={
        STATUS_PENDING:    {STATUS_DISPATCHED, STATUS_FAILED},
        STATUS_FAILED:     {STATUS_PENDING, STATUS_DEAD},  # retry أو نقل لـ DLQ
        STATUS_DISPATCHED: set(),   # نهائي — سُلِّم بنجاح
        STATUS_DEAD:       set(),   # نهائي — في DLQ
    },
    terminal=frozenset({STATUS_DISPATCHED, STATUS_DEAD}),
)


# ══════════════════════════════════════════════════════════════
# OutboxMessage — Entity النقي
# ══════════════════════════════════════════════════════════════
@dataclass
class OutboxMessage:
    """رسالة في الـ outbox. تحوي الحدث المُسلسَل + ميتاداتا التسليم.

    Invariants:
      - topic غير فارغ
      - max_attempts ≥ 1
      - attempts ≥ 0
      - idempotency_key غير فارغ (يُمكّن المستهلِك من التحقّق)
    """
    id: str
    topic: str
    payload: dict             # الحدث مُسلسَلاً (JSON-safe)
    idempotency_key: str      # لتمكين المستهلِكين من تحييد التكرار
    status: str = STATUS_PENDING
    attempts: int = 0
    max_attempts: int = DEFAULT_MAX_ATTEMPTS
    last_error: str = ""
    created_at: str = ""
    last_attempt_at: str = ""
    next_attempt_at: str = ""  # وقت الاستحقاق التالي (للـ backoff)
    # ── حقول التدقيق (audit) لإعادة المعالجة اليدوية من DLQ ──
    replay_count: int = 0          # كم مرّة أُعيدت يدوياً من الـ DLQ
    last_replayed_at: str = ""     # وقت آخر replay يدوي
    last_replayed_by: str = ""     # من أعاد المعالجة (معرّف المشغّل)
    last_replay_reason: str = ""   # سبب إعادة المعالجة (للتدقيق)
    dead_at: str = ""              # متى دخلت الـ DLQ (للمراقبة/التنظيف)

    def __post_init__(self) -> None:
        if not (self.topic or "").strip():
            raise InvariantViolationError("topic مطلوب في OutboxMessage")
        if not (self.idempotency_key or "").strip():
            raise InvariantViolationError("idempotency_key مطلوب")
        if self.max_attempts < 1:
            raise InvariantViolationError("max_attempts يجب أن يكون ≥ 1")
        if self.attempts < 0:
            raise InvariantViolationError("attempts لا يجوز أن يكون سالباً")

    # ── دورة الحياة (تُديرها OutboxService، لا تُستدعى مباشرة) ──
    @property
    def can_retry(self) -> bool:
        return self.status == STATUS_FAILED and self.attempts < self.max_attempts

    @property
    def is_terminal(self) -> bool:
        return self.status in OUTBOX_FSM.terminal

    def mark_dispatched(self, *, at: str) -> None:
        self.status = OUTBOX_FSM.transition(self.status, STATUS_DISPATCHED)
        self.attempts += 1
        self.last_attempt_at = at

    def mark_failed(self, *, at: str, error: str, next_attempt_at: str) -> None:
        """فشلت محاولة — يُحدَّد موعد الإعادة. عند الاستنفاد، Service يستدعي move_to_dlq."""
        self.status = OUTBOX_FSM.transition(self.status, STATUS_FAILED)
        self.attempts += 1
        self.last_attempt_at = at
        self.last_error = error
        self.next_attempt_at = next_attempt_at

    def begin_retry(self) -> None:
        """يُعيد المحاولة إلى pending قبل المعالجة (يُستدعى من Worker)."""
        if not self.can_retry:
            raise InvariantViolationError("لا يمكن إعادة المحاولة في هذه الحالة")
        self.status = OUTBOX_FSM.transition(self.status, STATUS_PENDING)

    def move_to_dlq(self, *, at: str = "") -> None:
        """نقل إلى Dead Letter Queue (بعد استنفاد المحاولات)."""
        if self.status != STATUS_FAILED:
            raise InvariantViolationError("يُنقَل إلى DLQ من حالة failed فقط")
        self.status = OUTBOX_FSM.transition(self.status, STATUS_DEAD)
        self.dead_at = at or self.last_attempt_at

    # ── تدخّل إداري: إعادة معالجة يدوية من الـ DLQ ──────────────
    def force_replay(self, *, at: str, by: str = "", reason: str = "") -> None:
        """يُعيد رسالة من الـ DLQ إلى دورة حياة جديدة كاملة (reset).

        تدخّل إداري صريح — الوحيد المسموح له تجاوز نهائية حالة dead. يُستدعى
        فقط بعد إصلاح سبب الفشل. يُجري إعادة ضبط كاملة (الخيار أ):
          - attempts = 0 (دورة محاولات جديدة كاملة)
          - status   = pending (يلتقطها الـ Worker طبيعياً)
          - next_attempt_at = now (متاحة فوراً)
          - last_error يُمسح
        مع الحفاظ على:
          - id ثابت (نفس الرسالة منطقياً)
          - payload + idempotency_key + topic (المحتوى لم يتغيّر)
          - audit trail (replay_count يتزايد، من/متى/لماذا)

        يُسمح من dead فقط (الحالة الوحيدة التي تحتاج تدخّلاً يدوياً). محاولة
        replay لرسالة غير ميتة خطأ تشغيلي.
        """
        if self.status != STATUS_DEAD:
            raise InvariantViolationError(
                "force_replay مسموح من حالة dead فقط (تدخّل إداري للـ DLQ)")
        # إعادة ضبط كاملة لدورة الحياة (لا عبر FSM — تجاوز إداري موثّق)
        self.status = STATUS_PENDING
        self.attempts = 0
        self.last_error = ""
        self.next_attempt_at = at
        # audit
        self.replay_count += 1
        self.last_replayed_at = at
        self.last_replayed_by = by
        self.last_replay_reason = reason


# ══════════════════════════════════════════════════════════════
# OutboxRepository Protocol
# ══════════════════════════════════════════════════════════════
@runtime_checkable
class OutboxRepository(Protocol):
    """عقد تخزين رسائل الـ outbox. التنفيذ في shared/outbox."""

    async def add(self, message: OutboxMessage, uow=None) -> None:
        """يُدرج رسالة جديدة. **يجب أن يُستدعى داخل نفس uow** للسجلّ المجالي."""
        ...

    async def save(self, message: OutboxMessage, uow=None) -> None:
        """يحدّث رسالة قائمة (بعد محاولة تسليم)."""
        ...

    async def list_due(self, *, now: str, limit: int = 50) -> list[OutboxMessage]:
        """رسائل pending مستحقّة (next_attempt_at ≤ now). للـ Worker."""
        ...

    async def list_dead(self, *, limit: int = 100) -> list[OutboxMessage]:
        """رسائل في DLQ (للمراقبة/إعادة المعالجة اليدوية)."""
        ...

    async def find_by_idempotency_key(self, key: str) -> OutboxMessage | None:
        """للمستهلِكين الذين يريدون تحييد التكرار قبل التنفيذ."""
        ...


# ══════════════════════════════════════════════════════════════
# Helper: حساب backoff exponential (دالة نقية)
# ══════════════════════════════════════════════════════════════
def compute_backoff_seconds(attempt: int, *, base: int = DEFAULT_BASE_BACKOFF_SECONDS,
                            cap: int = 300) -> int:
    """exponential backoff: base * 2^(attempt-1)، مع سقف.

    attempt=1 → base       (2 ثانية)
    attempt=2 → base*2     (4)
    attempt=3 → base*4     (8) ... حتى cap.
    """
    if attempt < 1:
        return base
    delay = base * (2 ** (attempt - 1))
    return min(delay, cap)
