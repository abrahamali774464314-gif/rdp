"""
kernel.contracts — العقود الأساسية للمعمارية
═══════════════════════════════════════════════════════════════════

يعرّف الأنواع الأساسية التي تفصل بين طبقات النظام، تنفيذاً للدستور:

  - البند 3: "ممنوع استخدام نفس الكائن بين Domain / DTO / Persistence"
  - البند 4: "Commands & Events — التواصل فقط عبر Commands و Events"

ثلاثة أنواع منفصلة تماماً لكل كيان:
  - Entity     : كائن المجال (Domain Layer) — يحمل الـ invariants والسلوك
  - DTO        : كائن النقل (API Layer) — للإدخال/الإخراج فقط
  - Record     : كائن التخزين (Persistence Layer) — شكل المستند في MongoDB

لا يجوز أبداً تمرير Entity إلى الـ API، ولا DTO إلى الـ Repository.
"""
from __future__ import annotations

import uuid
from abc import ABC
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, ClassVar


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new_id() -> str:
    return str(uuid.uuid4())


# ──────────────────────────────────────────────────────────────
# Command — أمر يُرسل إلى Application Service
# ──────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class Command(ABC):
    """أمر غير قابل للتعديل (frozen). يصف نيّة تغيير الحالة.

    الأوامر تُنشأ في الـ API Layer وتُمرَّر إلى Application Service فقط.
    لا تحمل أي منطق — مجرد بيانات النيّة.
    """
    pass


# ──────────────────────────────────────────────────────────────
# Query — استعلام للقراءة فقط
# ──────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class Query(ABC):
    """استعلام قراءة فقط. يُمرَّر إلى Application Service الذي يستدعي Read Models."""
    pass


# ──────────────────────────────────────────────────────────────
# DomainEvent — حقيقة وقعت في الماضي
# ──────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class DomainEvent(ABC):
    """حدث وقع بالفعل (past tense). يُنشر عبر Event Bus.

    الـ Domains الأخرى تشترك في الأحداث — لا تستدعي بعضها مباشرة.
    تنفيذاً للبند 2: "Domain → Domain (مباشر) ممنوع".

    كل حدث يحمل:
      - event_id     : معرّف فريد (idempotency على مستوى المشترك)
      - occurred_at  : وقت الوقوع
      - aggregate_id : معرّف الكيان مصدر الحدث
    """
    # تُملأ تلقائياً عند الإنشاء عبر `emit`
    event_id: str = field(default_factory=_new_id, kw_only=True)
    occurred_at: str = field(default_factory=_utc_now_iso, kw_only=True)

    # اسم الـ topic الذي يُنشر عليه الحدث (يُعرّفه كل حدث)
    topic: ClassVar[str] = ""

    @property
    def name(self) -> str:
        return self.__class__.__name__


# ──────────────────────────────────────────────────────────────
# DTO — كائن نقل البيانات (API boundary)
# ──────────────────────────────────────────────────────────────
@dataclass
class DTO(ABC):
    """كائن نقل البيانات. يُستخدم في حدود الـ API فقط (request/response).

    لا يحمل سلوكاً ولا invariants. لا يُمرَّر أبداً إلى Repository.
    في FastAPI يُمثَّل غالباً بـ Pydantic models، لكن نفصله مفهومياً.
    """
    pass


# ──────────────────────────────────────────────────────────────
# Entity — كيان المجال
# ──────────────────────────────────────────────────────────────
class Entity(ABC):
    """الكيان الجذر في الـ Domain Layer.

    يحمل الـ invariants والسلوك. لا يعرف شيئاً عن:
      - قاعدة البيانات (لا motor، لا dict تخزين)
      - الـ API (لا Pydantic، لا HTTP)
      - الأنظمة الخارجية (لا SMS، لا WebSocket)

    تنفيذاً للبند 2 و 3 من الدستور.
    """

    id: str

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Entity) and self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)


# ──────────────────────────────────────────────────────────────
# Record — كائن التخزين (Persistence boundary)
# ──────────────────────────────────────────────────────────────
@dataclass
class Record(ABC):
    """شكل المستند كما يُخزَّن في MongoDB.

    يُنتَج/يُستهلَك داخل الـ Repository فقط. لا يخرج أبداً من الـ infrastructure layer.
    التحويل Entity ⇄ Record يتم عبر Mapper داخل الـ Repository.
    """
    pass


# ──────────────────────────────────────────────────────────────
# Result — نتيجة Application Service (بدل رمي الاستثناءات للتحكم بالتدفق)
# ──────────────────────────────────────────────────────────────
@dataclass
class Result:
    """نتيجة تنفيذ أمر. تحمل البيانات + الأحداث التي يجب نشرها بعد النجاح."""
    data: Any = None
    events: list[DomainEvent] = field(default_factory=list)

    def with_event(self, event: DomainEvent) -> "Result":
        self.events.append(event)
        return self
