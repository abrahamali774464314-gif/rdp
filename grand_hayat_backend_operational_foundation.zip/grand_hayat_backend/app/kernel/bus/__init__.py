"""
kernel.bus — ناقل الأحداث والأوامر (Event Bus + Command Bus)
═══════════════════════════════════════════════════════════════════

ناقل أحداث داخل العملية. القاعدة الجديدة المهمة:
- المشترك الافتراضي fail-fast، لأن بعض الأحداث تحرس ثوابت تشغيلية مثل
  ربط التسكين بحالة الغرفة.
- الآثار الجانبية غير الحرجة مثل SMS/WhatsApp/WebSocket يجب تسجيلها
  كـ lenient subscriber أو تمريرها عبر Outbox، حتى لا تكسر العملية الأساسية.
"""
from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass
from typing import Awaitable, Callable

from kernel.contracts import Command, DomainEvent, Query, Result

logger = logging.getLogger("grandhayat.bus")

EventHandler = Callable[[DomainEvent], Awaitable[None]]
CommandHandler = Callable[[Command], Awaitable[Result]]
QueryHandler = Callable[[Query], Awaitable[object]]


@dataclass(frozen=True)
class _Subscription:
    handler: EventHandler
    fail_fast: bool = True


class EventBus:
    """ناقل أحداث publish/subscribe داخل العملية.

    fail_fast=True هو الافتراضي الصحيح للـ domain invariants. استخدم
    fail_fast=False فقط للآثار الجانبية التي لها retry/outbox أو يمكن تأجيلها.
    """

    def __init__(self) -> None:
        self._subscribers: dict[str, list[_Subscription]] = defaultdict(list)

    def subscribe(self, topic: str, handler: EventHandler, *, fail_fast: bool = True) -> None:
        self._subscribers[topic].append(_Subscription(handler=handler, fail_fast=fail_fast))
        logger.info(
            "subscribed handler '%s' to topic '%s' (fail_fast=%s)",
            getattr(handler, "__qualname__", handler), topic, fail_fast,
        )

    def subscribe_lenient(self, topic: str, handler: EventHandler) -> None:
        """يسجّل مشتركاً لا يُفشل الناشر عند الخطأ؛ مناسب للإشعارات فقط."""
        self.subscribe(topic, handler, fail_fast=False)

    async def publish(self, event: DomainEvent) -> None:
        topic = event.topic or event.name
        subscriptions = self._subscribers.get(topic, [])
        if not subscriptions:
            logger.debug("no subscribers for topic '%s'", topic)
            return

        for sub in subscriptions:
            try:
                await sub.handler(event)
            except Exception as exc:  # noqa: BLE001
                logger.exception(
                    "subscriber '%s' failed for event '%s' (event_id=%s, fail_fast=%s): %s",
                    getattr(sub.handler, "__qualname__", sub.handler),
                    event.name,
                    event.event_id,
                    sub.fail_fast,
                    exc,
                )
                if sub.fail_fast:
                    raise

    async def publish_all(self, events: list[DomainEvent]) -> None:
        for event in events:
            await self.publish(event)


class CommandBus:
    """يوجّه كل Command إلى Application Service handler واحد فقط."""

    def __init__(self) -> None:
        self._handlers: dict[type[Command], CommandHandler] = {}

    def register(self, command_type: type[Command], handler: CommandHandler) -> None:
        if command_type in self._handlers:
            raise RuntimeError(f"معالج مكرّر للأمر {command_type.__name__}")
        self._handlers[command_type] = handler

    async def dispatch(self, command: Command) -> Result:
        handler = self._handlers.get(type(command))
        if not handler:
            raise RuntimeError(f"لا يوجد معالج للأمر {type(command).__name__}")
        return await handler(command)


event_bus = EventBus()
command_bus = CommandBus()
