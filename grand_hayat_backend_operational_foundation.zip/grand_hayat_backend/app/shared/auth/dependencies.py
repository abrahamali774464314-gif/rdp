"""shared.auth.dependencies — tenant-aware Actor extraction and permission checks."""
from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any

from fastapi import Depends, Header, HTTPException, Request, status

from kernel.security.query_scoper import Actor
from shared.auth.tokens import decode_token, iso_to_ts
from shared.config.container import container


def _extract_bearer(request: Request) -> str | None:
    auth = request.headers.get("Authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    return request.cookies.get("access_token")


def _dev_auth_enabled() -> bool:
    return os.environ.get("ALLOW_DEV_AUTH", "false").strip().lower() in {"1", "true", "yes", "on"}


def _normalise_property_ids(user) -> frozenset[str]:
    raw = getattr(user, "property_ids", None)
    if raw is None:
        raw = getattr(user, "properties", None)
    if raw is None:
        raw = (getattr(user, "property_id", None) or os.environ.get("DEFAULT_PROPERTY_ID", "main"),)
    return frozenset(str(x) for x in raw if str(x).strip())


async def _is_blacklisted(jti: str | None) -> bool:
    if not jti or container.db is None:
        return False
    return bool(await container.db.token_blacklist.find_one({"jti": jti}, {"_id": 1}))


async def _validate_session(payload: dict[str, Any]) -> None:
    if container.db is None:
        return
    sid = payload.get("sid")
    if not sid:
        raise HTTPException(status_code=401, detail="الجلسة غير معروفة")
    session = await container.db.sessions.find_one({"id": sid, "user_id": payload.get("sub")}, {"_id": 0})
    if not session or session.get("revoked_at"):
        raise HTTPException(status_code=401, detail="الجلسة منتهية")
    expires_at = session.get("expires_at")
    if isinstance(expires_at, datetime) and expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        raise HTTPException(status_code=401, detail="انتهت صلاحية الجلسة")
    await container.db.sessions.update_one({"id": sid}, {"$set": {"last_seen_at": datetime.now(timezone.utc)}})


async def get_current_actor(
    request: Request,
    x_user_id: str | None = Header(default=None, alias="X-User-Id"),
    x_property_id: str | None = Header(default=None, alias="X-Property-Id"),
) -> Actor:
    """Return the authenticated actor.

    Production path: Authorization Bearer/cookie access token.
    Development path: X-User-Id only when ALLOW_DEV_AUTH=true.
    """
    token_payload: dict[str, Any] = {}
    user_id = None

    if x_user_id and _dev_auth_enabled():
        user_id = x_user_id
    else:
        token = _extract_bearer(request)
        if not token:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="غير مسجل الدخول")
        token_payload = decode_token(token)
        if token_payload.get("type") != "access":
            raise HTTPException(status_code=401, detail="نوع التوكن غير صحيح")
        if await _is_blacklisted(token_payload.get("jti")):
            raise HTTPException(status_code=401, detail="الجلسة منتهية")
        await _validate_session(token_payload)
        user_id = token_payload.get("sub") or token_payload.get("user_id")

    if not user_id:
        raise HTTPException(status_code=401, detail="معرّف المستخدم مفقود")

    user = await container.identity.get_user(str(user_id))
    if user is None:
        raise HTTPException(status_code=401, detail="المستخدم غير موجود")
    if user.status != "active":
        raise HTTPException(status_code=403, detail="الحساب معطّل")

    if token_payload and iso_to_ts(getattr(user, "password_changed_at", "")) > int(token_payload.get("iat", 0)):
        raise HTTPException(status_code=401, detail="تم تغيير كلمة المرور، يرجى تسجيل الدخول من جديد")

    tenant_id = (
        getattr(user, "tenant_id", None)
        or token_payload.get("tenant_id")
        or os.environ.get("DEFAULT_TENANT_ID", "default")
    )
    property_ids = _normalise_property_ids(user)
    active_property_id = (
        x_property_id
        or token_payload.get("property_id")
        or getattr(user, "active_property_id", None)
        or (next(iter(property_ids)) if property_ids else os.environ.get("DEFAULT_PROPERTY_ID", "main"))
    )
    if user.role not in {"super_admin", "admin"} and active_property_id not in property_ids:
        raise HTTPException(status_code=403, detail="ليست لديك صلاحية لهذا الفندق/العقار")

    return Actor(
        id=user.id,
        role=user.role,
        floors=frozenset(int(f) for f in (user.floors or [])),
        department=user.department or "general",
        request_types=frozenset(user.request_types or ()),
        permissions=frozenset(user.permissions or ()),
        tenant_id=str(tenant_id) if tenant_id else None,
        property_ids=property_ids,
        active_property_id=str(active_property_id) if active_property_id else None,
        name=user.name,
    )


def require_permission(permission: str):
    async def _dep(actor: Actor = Depends(get_current_actor)) -> Actor:
        if actor.has_permission(permission):
            return actor
        raise HTTPException(status_code=403, detail="صلاحية غير كافية")
    return _dep
