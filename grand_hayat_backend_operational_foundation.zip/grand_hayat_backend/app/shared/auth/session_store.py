"""Mongo-backed session and token blacklist helpers."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from shared.auth.tokens import token_exp_datetime


class SessionStore:
    def __init__(self, db) -> None:
        self._db = db

    async def create_session(self, *, session_id: str, user, refresh_payload: dict[str, Any],
                             request_meta: dict[str, Any] | None = None) -> dict[str, Any]:
        doc = {
            "id": session_id,
            "user_id": user.id,
            "email": user.email.value,
            "tenant_id": user.tenant_id,
            "property_id": user.active_property_id,
            "role": user.role,
            "refresh_jti": refresh_payload.get("jti"),
            "created_at": datetime.now(timezone.utc),
            "last_seen_at": datetime.now(timezone.utc),
            "expires_at": token_exp_datetime(refresh_payload),
            "revoked_at": None,
            "meta": dict(request_meta or {}),
        }
        await self._db.sessions.insert_one(doc)
        doc.pop("_id", None)
        return doc

    async def get_active_session(self, *, session_id: str, user_id: str) -> dict[str, Any] | None:
        doc = await self._db.sessions.find_one({"id": session_id, "user_id": user_id}, {"_id": 0})
        if not doc or doc.get("revoked_at"):
            return None
        expires_at = doc.get("expires_at")
        if isinstance(expires_at, datetime) and expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
            return None
        return doc

    async def rotate_refresh(self, *, session_id: str, refresh_payload: dict[str, Any]) -> None:
        await self._db.sessions.update_one(
            {"id": session_id, "revoked_at": None},
            {"$set": {
                "refresh_jti": refresh_payload.get("jti"),
                "last_seen_at": datetime.now(timezone.utc),
                "expires_at": token_exp_datetime(refresh_payload),
            }},
        )

    async def revoke_session(self, *, session_id: str, user_id: str | None = None) -> None:
        query = {"id": session_id}
        if user_id:
            query["user_id"] = user_id
        await self._db.sessions.update_one(query, {"$set": {"revoked_at": datetime.now(timezone.utc)}})

    async def revoke_user_sessions(self, *, user_id: str) -> int:
        res = await self._db.sessions.update_many(
            {"user_id": user_id, "revoked_at": None},
            {"$set": {"revoked_at": datetime.now(timezone.utc)}},
        )
        return int(getattr(res, "modified_count", 0))

    async def list_for_user(self, *, user_id: str, limit: int = 100) -> list[dict[str, Any]]:
        docs = await self._db.sessions.find({"user_id": user_id}, {"_id": 0}).sort("created_at", -1).to_list(max(1, min(int(limit), 500)))
        return docs

    async def blacklist_jti(self, *, jti: str | None, exp: int | None = None) -> None:
        if not jti:
            return
        expires_at = datetime.fromtimestamp(int(exp), tz=timezone.utc) if exp else datetime.now(timezone.utc)
        await self._db.token_blacklist.update_one(
            {"jti": jti},
            {"$set": {"jti": jti, "expires_at": expires_at, "exp": expires_at}},
            upsert=True,
        )

    async def is_refresh_current(self, *, session_id: str, refresh_jti: str) -> bool:
        doc = await self._db.sessions.find_one(
            {"id": session_id, "refresh_jti": refresh_jti, "revoked_at": None}, {"_id": 1},
        )
        return bool(doc)
