"""JWT and session helpers for operational auth."""
from __future__ import annotations

import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import HTTPException
from jose import JWTError, jwt

JWT_SECRET = os.environ.get("JWT_SECRET", "change-me-in-production-please-set-a-long-secret")
JWT_ALG = os.environ.get("JWT_ALG", "HS256")
ACCESS_TTL_MIN = int(os.environ.get("ACCESS_TTL_MIN", "30"))
REFRESH_TTL_DAYS = int(os.environ.get("REFRESH_TTL_DAYS", "7"))


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def now_ts() -> int:
    return int(utcnow().timestamp())


def _exp(minutes: int = 0, days: int = 0) -> datetime:
    return utcnow() + timedelta(minutes=minutes, days=days)


def _encode(payload: dict[str, Any]) -> str:
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)


def decode_token(token: str) -> dict[str, Any]:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
    except JWTError as exc:
        raise HTTPException(status_code=401, detail="جلسة غير صالحة") from exc


def create_access_token(user, *, session_id: str, property_id: str | None = None) -> tuple[str, dict[str, Any]]:
    now = utcnow()
    expires = now + timedelta(minutes=ACCESS_TTL_MIN)
    payload = {
        "sub": user.id,
        "email": user.email.value,
        "type": "access",
        "sid": session_id,
        "jti": str(uuid.uuid4()),
        "iat": int(now.timestamp()),
        "exp": int(expires.timestamp()),
        "tenant_id": user.tenant_id,
        "property_id": property_id or user.active_property_id,
        "role": user.role,
    }
    return _encode(payload), payload


def create_refresh_token(user, *, session_id: str, property_id: str | None = None) -> tuple[str, dict[str, Any]]:
    now = utcnow()
    expires = now + timedelta(days=REFRESH_TTL_DAYS)
    payload = {
        "sub": user.id,
        "email": user.email.value,
        "type": "refresh",
        "sid": session_id,
        "jti": str(uuid.uuid4()),
        "iat": int(now.timestamp()),
        "exp": int(expires.timestamp()),
        "tenant_id": user.tenant_id,
        "property_id": property_id or user.active_property_id,
        "role": user.role,
    }
    return _encode(payload), payload


def token_exp_datetime(payload: dict[str, Any]) -> datetime:
    return datetime.fromtimestamp(int(payload["exp"]), tz=timezone.utc)


def iso_to_ts(value: str | None) -> float:
    if not value:
        return 0
    try:
        return datetime.fromisoformat(str(value)).timestamp()
    except Exception:
        return 0
