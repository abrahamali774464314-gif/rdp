"""shared.realtime — WebSocket realtime abstractions."""
from __future__ import annotations

from .manager import ConnectionManager, manager

__all__ = ["ConnectionManager", "manager"]
