"""shared.realtime.manager — WebSocket connection manager with sound policy."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from fastapi import WebSocket
from shared.foundation.permissions import DEFAULT_SOUND_RULES

logger = logging.getLogger("grandhayat.realtime")


@dataclass
class _Connection:
    websocket: WebSocket
    actor: Any


class ConnectionManager:
    def __init__(self) -> None:
        self._connections: list[_Connection] = []
        self._sound_rules: dict[str, dict] = dict(DEFAULT_SOUND_RULES)

    def set_sound_rules(self, rules: dict | None) -> None:
        if isinstance(rules, dict):
            self._sound_rules = {**DEFAULT_SOUND_RULES, **rules}

    async def connect(self, websocket: WebSocket, actor: Any) -> None:
        await websocket.accept()
        self._connections.append(_Connection(websocket=websocket, actor=actor))

    async def disconnect(self, websocket: WebSocket) -> None:
        self._connections = [c for c in self._connections if c.websocket is not websocket]

    async def broadcast(self, event: str, data: dict, *, floor: int | None = None) -> None:
        await self._send(event, data, floor=floor, sound_event=None)

    async def broadcast_with_sound(
        self,
        event: str,
        data: dict,
        *,
        floor: int | None = None,
        sound_event: str | None = None,
        actor_id: str | None = None,
    ) -> None:
        await self._send(event, data, floor=floor, sound_event=sound_event, actor_id=actor_id)

    async def _send(self, event: str, data: dict, *, floor: int | None = None,
                    sound_event: str | None = None, actor_id: str | None = None) -> None:
        stale: list[WebSocket] = []
        for conn in list(self._connections):
            if floor is not None and not self._actor_can_receive_floor(conn.actor, floor):
                continue
            payload_data = dict(data)
            if sound_event and self._actor_should_hear(conn.actor, sound_event, actor_id=actor_id):
                payload_data["sound_event"] = sound_event
            try:
                await conn.websocket.send_json({"event": event, "data": payload_data})
            except Exception as exc:  # noqa: BLE001
                logger.debug("dropping stale websocket: %s", exc)
                stale.append(conn.websocket)
        for websocket in stale:
            await self.disconnect(websocket)

    @staticmethod
    def _actor_can_receive_floor(actor: Any, floor: int) -> bool:
        if actor is None:
            return True
        if getattr(actor, "role", None) in {"super_admin", "admin"}:
            return True
        floors = getattr(actor, "floors", None) or frozenset()
        return int(floor) in {int(f) for f in floors}

    def _actor_should_hear(self, actor: Any, sound_event: str, *, actor_id: str | None = None) -> bool:
        if actor is None:
            return True
        rule = self._sound_rules.get(sound_event) or {}
        if rule.get("exclude_actor") and actor_id and getattr(actor, "id", None) == actor_id:
            return False
        role = getattr(actor, "role", "staff")
        if role in {"super_admin", "admin"}:
            return bool(rule.get("admin", True))
        if role == "supervisor":
            return bool(rule.get("supervisor", rule.get("floor_supervisor", True)))
        return bool(rule.get("staff", rule.get("floor_staff", False)))


manager = ConnectionManager()
