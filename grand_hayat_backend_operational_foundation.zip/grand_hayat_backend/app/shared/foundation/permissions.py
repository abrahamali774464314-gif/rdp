"""Central PMS permission, role, department, and sound catalog."""
from __future__ import annotations

ROLE_SUPER_ADMIN = "super_admin"
ROLE_ADMIN = "admin"
ROLE_SUPERVISOR = "supervisor"
ROLE_STAFF = "staff"

ROLES = (ROLE_SUPER_ADMIN, ROLE_ADMIN, ROLE_SUPERVISOR, ROLE_STAFF)
ROLE_LABELS = {
    ROLE_SUPER_ADMIN: "مدير المنصة",
    ROLE_ADMIN: "مدير الفندق/العقار",
    ROLE_SUPERVISOR: "مشرف",
    ROLE_STAFF: "موظف",
}

DEPARTMENTS = (
    "general", "reception", "housekeeping", "maintenance", "it",
    "room_service", "billing", "laundry", "management",
)
DEPARTMENT_LABELS = {
    "general": "عام / كل الأقسام",
    "reception": "الاستقبال",
    "housekeeping": "النظافة",
    "maintenance": "الصيانة",
    "it": "تقنية المعلومات / الإنترنت",
    "room_service": "خدمة الغرف",
    "billing": "الحسابات",
    "laundry": "المغسلة",
    "management": "الإدارة",
}

PERMISSIONS: tuple[str, ...] = (
    # Properties / foundation
    "view_properties", "manage_properties",

    # Identity and access
    "view_users", "manage_users", "manage_permissions", "view_sessions", "manage_sessions",

    # Settings / notifications
    "view_settings", "manage_settings", "view_sounds", "manage_sounds",
    "view_notifications", "manage_notifications",

    # Rooms / inventory
    "view_rooms", "manage_rooms", "manage_floors", "manage_room_types",

    # Guests / reservations
    "view_guests", "manage_guests", "view_reservations", "manage_reservations",

    # Check-ins / checkouts
    "view_checkins", "create_checkin", "edit_checkin", "cancel_checkin",
    "view_checkout", "view_checkout_history", "create_checkout", "process_checkout", "cancel_checkout",

    # Requests / inspections
    "view_requests", "create_request", "accept_request", "complete_request", "delete_request", "view_history",
    "view_room_inspections", "create_room_inspection",

    # Billing
    "view_billing", "manage_billing", "post_charge", "post_payment", "void_transaction",

    # Messaging / integrations
    "view_messaging", "send_messaging", "manage_messaging", "view_sms_conversations", "send_sms", "manage_sms",
    "manage_integrations",

    # Storage / audit
    "view_storage_files", "manage_storage_files", "view_audit_logs",
)
ALL_PERMISSIONS = frozenset(PERMISSIONS)

PERMISSION_LABELS = {
    "view_properties": "عرض العقارات",
    "manage_properties": "إدارة العقارات",
    "view_users": "عرض المستخدمين",
    "manage_users": "إدارة المستخدمين",
    "manage_permissions": "إدارة الصلاحيات",
    "view_sessions": "عرض الجلسات",
    "manage_sessions": "إدارة الجلسات",
    "view_settings": "عرض الإعدادات",
    "manage_settings": "إدارة الإعدادات",
    "view_sounds": "عرض إعدادات الأصوات",
    "manage_sounds": "إدارة الأصوات والتنبيهات",
    "view_notifications": "عرض الإشعارات",
    "manage_notifications": "إدارة الإشعارات",
    "view_rooms": "عرض الغرف",
    "manage_rooms": "إدارة الغرف",
    "manage_floors": "إدارة الأدوار",
    "manage_room_types": "إدارة أنواع الغرف",
    "view_guests": "عرض النزلاء",
    "manage_guests": "إدارة النزلاء",
    "view_reservations": "عرض الحجوزات",
    "manage_reservations": "إدارة الحجوزات",
    "view_checkins": "عرض التسكين",
    "create_checkin": "تسكين نزيل",
    "edit_checkin": "تعديل التسكين",
    "cancel_checkin": "إلغاء التسكين",
    "view_checkout": "عرض طلبات الخروج",
    "view_checkout_history": "عرض سجل الخروج",
    "create_checkout": "إنشاء طلب خروج",
    "process_checkout": "تنفيذ الخروج",
    "cancel_checkout": "إلغاء الخروج",
    "view_requests": "عرض الطلبات",
    "create_request": "إنشاء طلب",
    "accept_request": "قبول طلب",
    "complete_request": "إكمال طلب",
    "delete_request": "حذف طلب",
    "view_history": "عرض سجل الطلبات",
    "view_room_inspections": "عرض فحوصات الغرف",
    "create_room_inspection": "إنشاء فحص غرفة",
    "view_billing": "عرض الحسابات",
    "manage_billing": "إدارة الحسابات",
    "post_charge": "إضافة قيد مدين",
    "post_payment": "تسجيل دفعة",
    "void_transaction": "إلغاء/عكس قيد مالي",
    "view_messaging": "عرض المحادثات",
    "send_messaging": "إرسال رسالة",
    "manage_messaging": "إدارة الرسائل",
    "view_sms_conversations": "عرض محادثات SMS",
    "send_sms": "إرسال SMS",
    "manage_sms": "إعدادات SMS والرد الآلي",
    "manage_integrations": "إدارة التكاملات",
    "view_storage_files": "عرض الملفات",
    "manage_storage_files": "إدارة الملفات",
    "view_audit_logs": "عرض سجل التدقيق",
}

REQUEST_TYPES = (
    "room_service", "housekeeping", "maintenance", "laundry",
    "internet_card", "billing", "reception", "other",
)
REQUEST_TYPE_DEPARTMENTS = {
    "room_service": "room_service",
    "housekeeping": "housekeeping",
    "maintenance": "maintenance",
    "laundry": "laundry",
    "internet_card": "it",
    "billing": "billing",
    "reception": "reception",
    "other": "general",
}

SOUND_EVENTS = (
    "request_new", "request_accepted", "request_completed",
    "checkout_new", "checkout_completed", "message_new", "sms_new",
    "room_status_changed", "inspection_new", "folio_updated",
)
SOUND_EVENT_LABELS = {
    "request_new": "طلب جديد",
    "request_accepted": "قبول طلب",
    "request_completed": "إتمام طلب",
    "checkout_new": "طلب خروج جديد",
    "checkout_completed": "إتمام الخروج",
    "message_new": "رسالة جديدة",
    "sms_new": "رسالة SMS جديدة",
    "room_status_changed": "تغيير حالة غرفة",
    "inspection_new": "فحص غرفة جديد",
    "folio_updated": "تحديث حساب/فاتورة",
}

DEFAULT_SOUND_RULES = {
    "request_new": {"admin": True, "supervisor": True, "staff": True, "exclude_actor": True},
    "request_accepted": {"admin": True, "supervisor": True, "staff": False, "exclude_actor": True},
    "request_completed": {"admin": True, "supervisor": True, "staff": False, "exclude_actor": True},
    "checkout_new": {"admin": True, "supervisor": True, "staff": False, "exclude_actor": True},
    "checkout_completed": {"admin": True, "supervisor": True, "staff": False, "exclude_actor": True},
    "message_new": {"admin": True, "supervisor": False, "staff": False, "exclude_actor": False},
    "sms_new": {"admin": True, "supervisor": False, "staff": False, "exclude_actor": False},
    "room_status_changed": {"admin": True, "supervisor": True, "staff": False, "exclude_actor": True},
    "inspection_new": {"admin": True, "supervisor": True, "staff": False, "exclude_actor": True},
    "folio_updated": {"admin": True, "supervisor": False, "staff": False, "exclude_actor": True},
}

ROLE_PERMISSION_PRESETS = {
    ROLE_SUPER_ADMIN: tuple(PERMISSIONS),
    ROLE_ADMIN: tuple(PERMISSIONS),
    ROLE_SUPERVISOR: (
        "view_rooms", "manage_rooms", "view_requests", "create_request", "accept_request", "complete_request",
        "view_history", "view_checkout", "create_checkout", "process_checkout", "view_room_inspections",
        "create_room_inspection", "view_checkins", "create_checkin", "edit_checkin", "view_messaging",
        "send_messaging", "view_notifications", "view_sounds", "view_settings", "view_guests", "manage_guests",
    ),
    ROLE_STAFF: (
        "view_rooms", "view_requests", "create_request", "accept_request", "complete_request",
        "view_checkout", "view_room_inspections", "create_room_inspection", "view_checkins",
        "create_checkin", "view_messaging", "send_messaging",
    ),
}


def normalise_permissions(values: tuple[str, ...] | list[str] | None) -> tuple[str, ...]:
    if not values:
        return ()
    cleaned = tuple(dict.fromkeys(str(v).strip() for v in values if str(v).strip()))
    unknown = tuple(v for v in cleaned if v not in ALL_PERMISSIONS)
    if unknown:
        from kernel.errors import ValidationError
        raise ValidationError(f"صلاحيات غير معروفة: {', '.join(unknown)}")
    return cleaned


def catalog() -> dict:
    return {
        "roles": [{"key": k, "label": ROLE_LABELS[k], "default_permissions": list(ROLE_PERMISSION_PRESETS[k])} for k in ROLES],
        "departments": [{"key": k, "label": DEPARTMENT_LABELS[k]} for k in DEPARTMENTS],
        "permissions": [{"key": k, "label": PERMISSION_LABELS.get(k, k)} for k in PERMISSIONS],
        "request_types": [{"key": k, "department": REQUEST_TYPE_DEPARTMENTS[k]} for k in REQUEST_TYPES],
        "sound_events": [{"key": k, "label": SOUND_EVENT_LABELS.get(k, k)} for k in SOUND_EVENTS],
        "default_sound_rules": DEFAULT_SOUND_RULES,
    }
