"""PMS Foundation constants and contracts."""
