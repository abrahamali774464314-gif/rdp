"""Central PMS Foundation constants.

Stable vocabulary for PMS workflows. Larger access and sound catalogues live in
`shared.foundation.permissions`.
"""
from __future__ import annotations

from shared.foundation.permissions import ALL_PERMISSIONS, PERMISSIONS

DEFAULT_TENANT_ID = "default"
DEFAULT_PROPERTY_ID = "main"

ROOM_STATUSES = frozenset({
    "available", "reserved", "occupied", "dirty", "cleaning", "inspected",
    "maintenance", "out_of_order",
})
CHECKIN_STATUSES = frozenset({"active", "checked_out", "cancelled", "deleted"})
CHECKOUT_STATUSES = frozenset({"pending", "in_progress", "completed", "cancelled"})
REQUEST_STATUSES = frozenset({"pending", "accepted", "in_progress", "completed", "cancelled", "rejected"})
RESERVATION_STATUSES = frozenset({"draft", "confirmed", "checked_in", "cancelled", "no_show"})
FOLIO_STATUSES = frozenset({"open", "closed", "void"})

CHANNELS = frozenset({"sms", "whatsapp", "email", "internal"})
SETTING_MODULES = frozenset({
    "property", "rooms", "checkins", "checkouts", "billing", "messaging",
    "notifications", "sounds", "integrations", "security", "pms",
})

FOUNDATION_PERMISSIONS = frozenset(PERMISSIONS)
