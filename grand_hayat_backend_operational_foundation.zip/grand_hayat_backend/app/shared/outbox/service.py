"""
shared.outbox.service — OutboxService (enqueue + dispatch)
═══════════════════════════════════════════════════════════════════

نقطتا الواجهة:

① enqueue(events, uow): تُستدعى من الـ Application Service بدل
   bus.publish_all مباشرة. تُحفظ الرسالة في outbox **ضمن نفس uow**
   للسجلّ المجالي → تُعالَج معاً (commit/rollback).

② dispatch(message): يستدعيها Worker لاحقاً. تُسلِّم الحدث للـ EventBus
   (يُشغّل كل الـ subscribers). عند الفشل تُحدِّث الـ Entity + backoff.

ملاحظة معمارية: لماذا الـ service هنا (shared) لا في كل مجال؟
  Outbox طبقة بنيوية مشتركة، لا منطق مجال. الـ Application Service لكل
  مجال يستدعي OutboxService، لكن لا يملك نسخة منه (singleton عبر container).
"""
from __future__ import annotations

import json
import logging
import uuid
from dataclasses import asdict, is_dataclass
from datetime import datetime, timedelta, timezone

from kernel.bus import EventBus
from kernel.clock import now_iso
from kernel.contracts import DomainEvent
from kernel.outbox import (
    OutboxMessage,
    OutboxRepository,
    compute_backoff_seconds,
)

logger = logging.getLogger("grandhayat.outbox")


def _serialize_event(event: DomainEvent) -> dict:
    """يُحوّل DomainEvent إلى dict آمن للتخزين (JSON-compatible).

    دالة نقية. تتعامل مع Decimal/datetime نصاً لتجنّب فقدان دقّة.
    """
    if is_dataclass(event):
        raw = asdict(event)
    else:
        raw = dict(vars(event))
    # تأكّد من قابلية الـ JSON (Decimal/datetime → نص)
    return json.loads(json.dumps(raw, default=str))


def _derive_idempotency_key(event: DomainEvent) -> str:
    """مفتاح يُمكّن المستهلِكين من تحييد التكرار.

    الصيغة: "{topic}|{event_id}" — مستقرّ وكافٍ على مستوى الـ outbox
    (الـ subscribers قد يشتقّون مفاتيح أدق محلياً، مثل notifications).
    """
    event_id = getattr(event, "event_id", "") or str(uuid.uuid4())
    return f"{event.topic}|{event_id}"


# ══════════════════════════════════════════════════════════════
# OutboxService
# ══════════════════════════════════════════════════════════════
class OutboxService:
    def __init__(self, *, outbox: OutboxRepository, bus: EventBus,
                 event_factory=None) -> None:
        """
        outbox: المستودع (Mongo في الإنتاج، fake في الاختبار)
        bus:    EventBus لتسليم الحدث للـ subscribers عند dispatch
        event_factory: دالة اختيارية تُعيد بناء DomainEvent من (topic, payload)
                       — تُستخدم في Worker. لو لم تُحقَن، Worker يُسلِّم dict.
        """
        self._outbox = outbox
        self._bus = bus
        self._event_factory = event_factory

    # ── ① enqueue: داخل uow الـ aggregate ──────────────────────
    async def enqueue(self, events: list[DomainEvent], *, uow=None) -> None:
        """يحفظ كل حدث كـ OutboxMessage. تُستدعى من Application Service."""
        if not events:
            return
        now = now_iso()
        for ev in events:
            msg = OutboxMessage(
                id=str(uuid.uuid4()),
                topic=ev.topic,
                payload=_serialize_event(ev),
                idempotency_key=_derive_idempotency_key(ev),
                created_at=now,
                next_attempt_at=now,  # متاح فوراً للـ Worker
            )
            await self._outbox.add(msg, uow=uow)

    # ── ② dispatch: تُستدعى من Worker ──────────────────────────
    async def dispatch(self, message: OutboxMessage) -> None:
        """يُسلِّم رسالة واحدة للـ EventBus. يحدّث الحالة (نجاح/فشل + backoff)."""
        try:
            event = self._reconstruct_event(message)
            await self._bus.publish(event)
            message.mark_dispatched(at=now_iso())
            await self._outbox.save(message)
            logger.debug("outbox dispatched: %s", message.id)
        except Exception as exc:  # noqa: BLE001 — أي فشل = retry
            next_at = self._compute_next_attempt(message.attempts + 1)
            message.mark_failed(at=now_iso(), error=str(exc), next_attempt_at=next_at)
            # إن استُنفدت المحاولات → DLQ
            if not message.can_retry:
                message.move_to_dlq(at=now_iso())
                logger.warning("outbox → DLQ: %s (attempts=%d, err=%s)",
                               message.id, message.attempts, exc)
            await self._outbox.save(message)

    # ── Helpers ───────────────────────────────────────────────
    def _reconstruct_event(self, message: OutboxMessage):
        """يُعيد بناء DomainEvent من الـ payload.

        إن لم يُحقَن event_factory، نُسلِّم كائن بسيط بنفس الواجهة الدنيا
        (topic + الحقول). الـ subscribers لا تعرف الفرق طالما تقرأ الحقول.
        """
        if self._event_factory:
            return self._event_factory(message.topic, message.payload)
        # fallback: SimpleNamespace بنفس الـ attributes
        # payload قد يحوي بالفعل name/event_id (من asdict)، فنبنيه أولاً
        # ثم نضع defaults لو غابت — payload له الأولوية.
        from types import SimpleNamespace
        attrs = {
            "topic": message.topic,
            "name": message.topic,
            "event_id": message.id,
        }
        attrs.update(message.payload)  # payload يطغى على الـ defaults
        return SimpleNamespace(**attrs)

    @staticmethod
    def _compute_next_attempt(next_attempt_number: int) -> str:
        """يحسب next_attempt_at بـ exponential backoff."""
        delay = compute_backoff_seconds(next_attempt_number)
        target = datetime.now(timezone.utc) + timedelta(seconds=delay)
        return target.isoformat()
