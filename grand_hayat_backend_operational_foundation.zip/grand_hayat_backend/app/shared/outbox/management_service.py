"""
shared.outbox.management_service — واجهة إدارة الـ Outbox (DLQ)
═══════════════════════════════════════════════════════════════════

خدمة رقيقة (thin) فوق MongoOutboxRepository — تقدّم للمشغّل/الإدارة
أربع عمليات لا أكثر:

  - stats()             : إحصاءات سريعة (لوحة مراقبة)
  - list_dead(...)      : تصفّح DLQ مع فلتر + ترقيم
  - replay(...)         : إعادة معالجة يدوية لرسالة في DLQ
  - purge_dead_before() : تنظيف دوري للـ DLQ القديم

تنفيذ نظيف:
  - لا منطق أعمال هنا — كل العمليات تستدعي الـ repository أو entity behavior.
  - لا تسليم مباشر — replay يُعيد الرسالة لـ pending، الـ Worker يلتقطها.
    هذا يحفظ مساراً واحداً للتسليم (لا تكرار، لا فروع).
  - الـ Service لا يعرف Mongo — يستدعي عقد OutboxRepository فقط.

ملاحظة معمارية: لماذا shared لا kernel؟
  هذه طبقة تشغيلية (operational concern)، تجمع استعلامات تخزينية. الـ kernel
  يبقى للسياسة النقية. Service رقيق هنا = توافق مع نمط outbox الحالي (service.py).
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from kernel.clock import now_iso
from kernel.errors import InvariantViolationError
from kernel.outbox import OutboxMessage, STATUS_DEAD

if TYPE_CHECKING:
    from shared.outbox.repository import MongoOutboxRepository

logger = logging.getLogger("grandhayat.outbox.mgmt")


# ══════════════════════════════════════════════════════════════
# DTOs نقية (للقراءة فقط — لا تسرّب Entity للطبقات الأعلى)
# ══════════════════════════════════════════════════════════════
def _msg_to_dict(m: OutboxMessage) -> dict:
    """تحويل آمن إلى dict للعرض (يُخفي تفاصيل الـ Entity)."""
    return {
        "id": m.id,
        "topic": m.topic,
        "status": m.status,
        "attempts": m.attempts,
        "max_attempts": m.max_attempts,
        "last_error": m.last_error,
        "created_at": m.created_at,
        "last_attempt_at": m.last_attempt_at,
        "next_attempt_at": m.next_attempt_at,
        "dead_at": m.dead_at,
        "replay_count": m.replay_count,
        "last_replayed_at": m.last_replayed_at,
        "last_replayed_by": m.last_replayed_by,
        "last_replay_reason": m.last_replay_reason,
        "idempotency_key": m.idempotency_key,
    }


# ══════════════════════════════════════════════════════════════
# OutboxManagementService
# ══════════════════════════════════════════════════════════════
class OutboxManagementService:
    """واجهة إدارية رقيقة فوق الـ outbox repository.

    تُحقَن من الـ container (singleton مثل OutboxService). لا تحتفظ بحالة.
    """

    def __init__(self, *, repository: "MongoOutboxRepository") -> None:
        self._repo = repository

    # ── ① stats: لوحة مراقبة سريعة ────────────────────────────
    async def stats(self) -> dict:
        """إحصاءات شاملة للـ outbox.

        يُرجع:
          {
            "by_status": {"pending": .., "dispatched": .., "failed": .., "dead": ..},
            "dead_by_topic": {"<topic>": <count>, ...},
            "total": <عدد الكل>,
            "dlq_size": <عدد رسائل DLQ>
          }
        """
        by_status = await self._repo.count_by_status()
        dead_by_topic = await self._repo.count_dead_by_topic()
        return {
            "by_status": by_status,
            "dead_by_topic": dead_by_topic,
            "total": sum(by_status.values()),
            "dlq_size": by_status.get(STATUS_DEAD, 0),
        }

    # ── ② list_dead: تصفّح DLQ ────────────────────────────────
    async def list_dead(self, *, topic: str | None = None,
                        limit: int = 50, skip: int = 0) -> list[dict]:
        """يُرجع رسائل DLQ كـ dicts قابلة للعرض (لا entities).

        الحدود الافتراضية محافظة (50) لتجنّب تحميل DLQ كاملاً في طلب واحد.
        """
        limit = max(1, min(int(limit), 200))  # سقف صلب للحماية
        skip = max(0, int(skip))
        msgs = await self._repo.list_dead_filtered(
            topic=topic, limit=limit, skip=skip)
        return [_msg_to_dict(m) for m in msgs]

    # ── ③ replay: إعادة معالجة يدوية ──────────────────────────
    async def replay(self, message_id: str, *, replayed_by: str,
                     reason: str = "") -> dict:
        """يُعيد رسالة من DLQ إلى pending — الـ Worker سيلتقطها.

        المنطق:
          1. جلب الرسالة بمعرّفها.
          2. التحقّق أنها موجودة (404 منطقياً) وأنها في حالة dead.
          3. استدعاء force_replay على الـ Entity (الـ Entity يتولّى reset
             الكامل + audit + رفض الحالات غير الصحيحة).
          4. حفظها — يلتقطها الـ Worker في الدورة التالية طبيعياً.

        يُسجَّل audit log واضح. لا تسليم مباشر هنا (الـ Worker مسؤول).
        """
        if not message_id:
            raise InvariantViolationError("message_id مطلوب")
        if not replayed_by:
            raise InvariantViolationError("replayed_by مطلوب (audit trail)")

        message = await self._repo.get(message_id)
        if message is None:
            raise InvariantViolationError(
                f"الرسالة غير موجودة: {message_id}")
        if message.status != STATUS_DEAD:
            raise InvariantViolationError(
                f"الـ replay مسموح للرسائل في DLQ فقط (الحالة الحالية: {message.status})")

        # الـ Entity يُجري reset الكامل + audit (FSM-safe)
        message.force_replay(at=now_iso(), by=replayed_by, reason=reason)
        await self._repo.save(message)

        logger.info(
            "outbox replay: id=%s topic=%s by=%s reason=%s (replay_count=%d)",
            message.id, message.topic, replayed_by, reason or "—",
            message.replay_count)
        return _msg_to_dict(message)

    # ── ④ purge_dead_before: تنظيف دوري ───────────────────────
    async def purge_dead_before(self, *, before: str,
                                purged_by: str = "") -> dict:
        """يحذف رسائل DLQ التي ماتت قبل تاريخ معيّن.

        تنظيف صريح يحمي من تضخّم DLQ. يُرجع عدد المحذوف. يجب أن يكون
        قراراً واعياً (المشغّل يقدّر فترة الاحتفاظ).
        """
        if not before:
            raise InvariantViolationError("before (ISO date) مطلوب")
        deleted = await self._repo.purge_dead_before(before=before)
        logger.warning(
            "outbox purge: deleted=%d before=%s by=%s",
            deleted, before, purged_by or "—")
        return {"deleted": deleted, "before": before}
