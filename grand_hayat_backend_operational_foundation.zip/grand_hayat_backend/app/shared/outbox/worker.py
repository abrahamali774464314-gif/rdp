"""
shared.outbox.worker — Background Worker
═══════════════════════════════════════════════════════════════════

asyncio task يعمل في خلفية الـ FastAPI app:
  - يستيقظ كل poll_interval ثانية
  - يقرأ list_due (pending + استحقّت الآن)
  - لكل رسالة: dispatch (نجاح → terminal | فشل → backoff/DLQ)

يبدأ في startup ويتوقّف في shutdown (يُدار من server.py).

ملاحظات:
  - graceful shutdown: ينهي الدورة الحالية ثم يتوقّف.
  - لا يستهلك أكثر من batch_size رسالة في الدورة (يحمي الـ DB).
  - فشل dispatch لا يوقف الـ Worker — يُسجَّل ويتابع.
"""
from __future__ import annotations

import asyncio
import logging

from kernel.clock import now_iso
from kernel.outbox import OutboxRepository

from shared.outbox.service import OutboxService

logger = logging.getLogger("grandhayat.outbox.worker")


class OutboxWorker:
    def __init__(self, *, outbox: OutboxRepository, service: OutboxService,
                 poll_interval_seconds: float = 1.0,
                 batch_size: int = 50) -> None:
        self._outbox = outbox
        self._service = service
        self._interval = poll_interval_seconds
        self._batch = batch_size
        self._task: asyncio.Task | None = None
        self._stop_event = asyncio.Event()

    # ── دورة الحياة ──────────────────────────────────────────
    def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._stop_event.clear()
        self._task = asyncio.create_task(self._run(), name="outbox-worker")
        logger.info("outbox worker started (interval=%.1fs, batch=%d)",
                    self._interval, self._batch)

    async def stop(self) -> None:
        self._stop_event.set()
        if self._task:
            try:
                await asyncio.wait_for(self._task, timeout=10.0)
            except asyncio.TimeoutError:
                logger.warning("outbox worker stop: timeout, cancelling")
                self._task.cancel()
            self._task = None
        logger.info("outbox worker stopped")

    # ── الحلقة الرئيسية ──────────────────────────────────────
    async def _run(self) -> None:
        while not self._stop_event.is_set():
            try:
                processed = await self._process_batch()
                if processed == 0:
                    # لا شيء مستحقّ → انتظر دورة كاملة
                    await self._sleep_or_stop(self._interval)
                else:
                    # نشاط → استمرّ بسرعة (دون انتظار)
                    await self._sleep_or_stop(0.05)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 — لا نوقف Worker بسبب فشل واحد
                logger.exception("outbox worker error: %s", exc)
                await self._sleep_or_stop(self._interval)

    async def _process_batch(self) -> int:
        due = await self._outbox.list_due(now=now_iso(), limit=self._batch)
        for msg in due:
            if self._stop_event.is_set():
                break
            await self._service.dispatch(msg)
        return len(due)

    async def _sleep_or_stop(self, seconds: float) -> None:
        """ينام مع احترام stop event (graceful)."""
        try:
            await asyncio.wait_for(self._stop_event.wait(), timeout=seconds)
        except asyncio.TimeoutError:
            pass

    # ── واجهة للمراقبة (تُستخدم من /health أو admin endpoint) ──
    async def list_dead_messages(self, *, limit: int = 100):
        """ملخّص DLQ — للمراقبة وإعادة المعالجة اليدوية لاحقاً."""
        return await self._outbox.list_dead(limit=limit)
