"""
shared.outbox.repository — تنفيذ Mongo للـ OutboxRepository
═══════════════════════════════════════════════════════════════════

المكان الوحيد المسموح فيه بـ motor للـ outbox. التنفيذ يلتزم بالعقد
في kernel.outbox دون أي تسرّب للتفاصيل خارج هذا الملف.

ملاحظة: الـ collection اسمها `outbox_messages` للتمييز عن أي مجال.
الفهارس المُقترَحة (في seed):
  - {idempotency_key: 1} unique  (لـ at-most-once insert)
  - {status: 1, next_attempt_at: 1}  (لـ list_due)
"""
from __future__ import annotations

from kernel.outbox import (
    OutboxMessage,
    OutboxRepository,
    STATUS_DEAD,
    STATUS_FAILED,
    STATUS_PENDING,
)
from kernel.persistence import session_kwargs

COLLECTION = "outbox_messages"


class MongoOutboxRepository(OutboxRepository):
    def __init__(self, db) -> None:
        self._col = db[COLLECTION]

    # ── Mappers ───────────────────────────────────────────────
    @staticmethod
    def _to_entity(doc: dict) -> OutboxMessage:
        return OutboxMessage(
            id=doc["id"],
            topic=doc["topic"],
            payload=doc.get("payload", {}),
            idempotency_key=doc["idempotency_key"],
            status=doc.get("status", STATUS_PENDING),
            attempts=int(doc.get("attempts", 0)),
            max_attempts=int(doc.get("max_attempts", 5)),
            last_error=doc.get("last_error", ""),
            created_at=doc.get("created_at", ""),
            last_attempt_at=doc.get("last_attempt_at", ""),
            next_attempt_at=doc.get("next_attempt_at", ""),
            replay_count=int(doc.get("replay_count", 0)),
            last_replayed_at=doc.get("last_replayed_at", ""),
            last_replayed_by=doc.get("last_replayed_by", ""),
            last_replay_reason=doc.get("last_replay_reason", ""),
            dead_at=doc.get("dead_at", ""),
        )

    @staticmethod
    def _to_document(m: OutboxMessage) -> dict:
        return {
            "id": m.id,
            "topic": m.topic,
            "payload": m.payload,
            "idempotency_key": m.idempotency_key,
            "status": m.status,
            "attempts": m.attempts,
            "max_attempts": m.max_attempts,
            "last_error": m.last_error,
            "created_at": m.created_at,
            "last_attempt_at": m.last_attempt_at,
            "next_attempt_at": m.next_attempt_at,
            "replay_count": m.replay_count,
            "last_replayed_at": m.last_replayed_at,
            "last_replayed_by": m.last_replayed_by,
            "last_replay_reason": m.last_replay_reason,
            "dead_at": m.dead_at,
        }

    # ── Operations ────────────────────────────────────────────
    async def add(self, message: OutboxMessage, uow=None) -> None:
        await self._col.insert_one(self._to_document(message), **session_kwargs(uow))

    async def save(self, message: OutboxMessage, uow=None) -> None:
        await self._col.update_one(
            {"id": message.id},
            {"$set": self._to_document(message)},
            upsert=True, **session_kwargs(uow),
        )

    async def list_due(self, *, now: str, limit: int = 50) -> list[OutboxMessage]:
        # pending + استحقّت الآن (next_attempt_at ≤ now أو فارغ)
        cursor = self._col.find(
            {
                "status": STATUS_PENDING,
                "$or": [
                    {"next_attempt_at": {"$lte": now}},
                    {"next_attempt_at": ""},
                    {"next_attempt_at": None},
                ],
            },
            {"_id": 0},
        ).sort("created_at", 1).limit(limit)
        return [self._to_entity(d) async for d in cursor]

    async def list_dead(self, *, limit: int = 100) -> list[OutboxMessage]:
        cursor = self._col.find({"status": STATUS_DEAD}, {"_id": 0}).limit(limit)
        return [self._to_entity(d) async for d in cursor]

    async def find_by_idempotency_key(self, key: str) -> OutboxMessage | None:
        if not key:
            return None
        doc = await self._col.find_one({"idempotency_key": key}, {"_id": 0})
        return self._to_entity(doc) if doc else None

    # ══════════════════════════════════════════════════════════
    # DLQ Management — مراقبة وإعادة معالجة (للمشغّل/الإدارة)
    # ══════════════════════════════════════════════════════════
    async def get(self, message_id: str) -> OutboxMessage | None:
        """يجلب رسالة بمعرّفها (لإعادة المعالجة اليدوية)."""
        doc = await self._col.find_one({"id": message_id}, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def count_by_status(self) -> dict[str, int]:
        """عدّ الرسائل حسب الحالة — لوحة مراقبة سريعة.

        يُرجع dict مثل {"pending": 3, "dispatched": 120, "dead": 2}.
        يستخدم aggregation $group (خفيف، يستفيد من فهرس status).
        """
        pipeline = [{"$group": {"_id": "$status", "count": {"$sum": 1}}}]
        out: dict[str, int] = {}
        async for row in self._col.aggregate(pipeline):
            out[row["_id"]] = row["count"]
        return out

    async def list_dead_filtered(self, *, topic: str | None = None,
                                 limit: int = 100,
                                 skip: int = 0) -> list[OutboxMessage]:
        """تصفّح الـ DLQ مع فلتر اختياري بالـ topic + ترقيم (pagination).

        مُرتَّب بـ dead_at تنازلياً (الأحدث موتاً أولاً — الأكثر صلة للمشغّل).
        """
        query: dict = {"status": STATUS_DEAD}
        if topic:
            query["topic"] = topic
        cursor = (self._col.find(query, {"_id": 0})
                  .sort("dead_at", -1).skip(skip).limit(limit))
        return [self._to_entity(d) async for d in cursor]

    async def count_dead_by_topic(self) -> dict[str, int]:
        """توزيع رسائل الـ DLQ حسب الـ topic — لتحديد المصدر الأكثر فشلاً."""
        pipeline = [
            {"$match": {"status": STATUS_DEAD}},
            {"$group": {"_id": "$topic", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
        ]
        out: dict[str, int] = {}
        async for row in self._col.aggregate(pipeline):
            out[row["_id"]] = row["count"]
        return out

    async def purge_dead_before(self, *, before: str) -> int:
        """يحذف رسائل DLQ التي ماتت قبل تاريخ معيّن (تنظيف دوري).

        يُرجع عدد المحذوف. يُستخدم في صيانة دورية لمنع تضخّم الـ DLQ.
        """
        result = await self._col.delete_many(
            {"status": STATUS_DEAD, "dead_at": {"$lt": before}})
        return getattr(result, "deleted_count", 0)
