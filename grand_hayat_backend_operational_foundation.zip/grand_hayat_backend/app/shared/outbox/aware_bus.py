"""
shared.outbox.aware_bus — OutboxAwareBus (Decorator)
═══════════════════════════════════════════════════════════════════

Decorator يلفّ الـ EventBus الحقيقي ويحوّل النشر إلى الـ Outbox، دون
لمس أي Application Service.

كيف يعمل (شفّاف تماماً):
  - الـ services تستدعي bus.publish_all(events) كالمعتاد.
  - عند اللفّ بهذا الـ decorator، publish_all لا تنشر فوراً، بل تستدعي
    OutboxService.enqueue(events) → تُحفظ في outbox (داخل uow إن مُرّر).
  - الـ subscribe يمرّ كما هو للـ bus الحقيقي.
  - لاحقاً، OutboxWorker يقرأ outbox ويستدعي real_bus.publish → التسليم
    الفعلي للـ subscribers (at-least-once).

نقطة معمارية: لماذا Decorator لا توريث؟
  لأنه يحفظ واجهة EventBus بالكامل (publish/publish_all/subscribe) ويسمح
  بالتفعيل/الإلغاء عبر الـ container دون أي تغيير في الـ services أو الـ kernel.

ملاحظة transactional: enqueue يقبل uow. لكن الـ services الحالية تستدعي
publish_all(events) بلا uow (توقيعها الراهن). لذا الـ decorator يوفّر
enqueue_in_uow للاستخدام المستقبلي الصريح، ويُبقي publish_all يعمل بلا uow
(at-least-once لكن خارج معاملة الـ aggregate — ترقية لاحقة دون كسر).
"""
from __future__ import annotations

import logging

from kernel.bus import EventBus
from kernel.contracts import DomainEvent

logger = logging.getLogger("grandhayat.outbox.bus")


class OutboxAwareBus:
    """يلفّ EventBus حقيقياً ويوجّه النشر إلى الـ Outbox.

    يحافظ على واجهة EventBus (publish / publish_all / subscribe) ليكون
    بديلاً مباشراً (drop-in) دون أي تعديل في المستهلِكين.
    """

    def __init__(self, *, real_bus: EventBus, outbox_service) -> None:
        self._real_bus = real_bus
        self._outbox = outbox_service

    # ── subscribe يمرّ للـ bus الحقيقي (الـ subscribers تبقى عليه) ──
    def subscribe(self, topic: str, handler, *, fail_fast: bool = True) -> None:
        self._real_bus.subscribe(topic, handler, fail_fast=fail_fast)

    def subscribe_lenient(self, topic: str, handler) -> None:
        self._real_bus.subscribe(topic, handler, fail_fast=False)

    # ── publish → outbox (بدل النشر الفوري) ───────────────────
    async def publish(self, event: DomainEvent) -> None:
        await self._outbox.enqueue([event])

    async def publish_all(self, events: list[DomainEvent]) -> None:
        if events:
            await self._outbox.enqueue(events)

    # ── enqueue صريح داخل uow (للترقية التدريجية للـ services) ──
    async def enqueue_in_uow(self, events: list[DomainEvent], *, uow) -> None:
        """نشر transactional صريح — يُحفظ ضمن نفس uow للـ aggregate.

        تستخدمه الـ services التي رُقّيت لتمرير uow (transactional outbox
        الكامل). الـ services غير المُرقّاة تبقى على publish_all (بلا uow).
        """
        if events:
            await self._outbox.enqueue(events, uow=uow)

    # ── الوصول للـ bus الحقيقي (للـ Worker عند التسليم) ────────
    @property
    def real_bus(self) -> EventBus:
        return self._real_bus
