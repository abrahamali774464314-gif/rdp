"""Composition root for the modular Grand Hayat backend."""
from __future__ import annotations

import logging
from decimal import Decimal

from kernel.bus import event_bus
from kernel.errors import PermissionDeniedError, NotFoundError
from kernel.persistence import MongoUnitOfWork
from kernel.security.scoping_rules import is_floor_allowed
from shared.security.url_guard import validate_external_url
from shared.realtime.manager import manager as ws_manager

logger = logging.getLogger("grandhayat.container")


class _FolioBalanceReader:
    """Checkout balance port backed by the billing module."""

    def __init__(self, folio_repository=None) -> None:
        self._folios = folio_repository

    async def current_balance(self, checkin_id: str) -> Decimal:
        if not self._folios:
            return Decimal("0.00")
        folio = await self._folios.get_master_for_checkin(checkin_id)
        return folio.balance() if folio else Decimal("0.00")


class _RoomOccupancyBridge:
    """Implements the checkins-owned RoomOccupancyPort in the composition root.

    This keeps the critical invariant atomic without importing the rooms module
    into checkins.application. The composition root is the only allowed bridge.
    """

    def __init__(self, rooms_repo) -> None:
        self._rooms = rooms_repo

    async def occupy_for_checkin(
        self,
        *,
        room_number: int,
        checkin_id: str,
        guest_name: str,
        guest_phone: str,
        check_in_at: str,
        expected_checkout_at: str | None,
        tenant_id: str,
        property_id: str,
        actor=None,
        uow=None,
    ) -> int:
        room = await self._rooms.get_by_number(
            room_number, tenant_id=tenant_id, property_id=property_id,
        )
        if not room:
            raise NotFoundError("الغرفة غير موجودة")
        if actor is not None and not is_floor_allowed(actor, room.floor):
            raise PermissionDeniedError("ليست لديك صلاحية لهذا الدور")
        if room.status == "occupied" and room.active_checkin_id == checkin_id:
            return room.floor
        room.occupy(
            checkin_id=checkin_id,
            guest_name=guest_name,
            guest_phone=guest_phone,
            check_in_at=check_in_at,
            expected_checkout_at=expected_checkout_at,
        )
        await self._rooms.save(room, uow=uow)
        return room.floor

    async def release_for_checkin(
        self,
        *,
        room_number: int,
        checkin_id: str,
        tenant_id: str,
        property_id: str,
        uow=None,
    ) -> None:
        room = await self._rooms.get_by_number(
            room_number, tenant_id=tenant_id, property_id=property_id,
        )
        if not room:
            return
        if room.active_checkin_id and room.active_checkin_id != checkin_id:
            return
        room.cancel_occupancy()
        await self._rooms.save(room, uow=uow)


class Container:
    def __init__(self) -> None:
        self._initialised = False
        self.db = None
        self.client = None
        self.bus = event_bus

        self.rooms = None
        self.checkins = None
        self.checkouts = None
        self.requests = None
        self.inspections = None
        self.notifications = None
        self.identity = None
        self.billing = None
        self.properties = None
        self.guests = None
        self.reservations = None
        self.settings = None
        self.messaging = None
        self.audit = None
        self.storage = None

        self.password_hasher = None
        self.scoping_rules = None
        self.query_scoper = None

        self.outbox_service = None
        self.outbox_worker = None
        self.outbox_bus = None
        self.outbox_management = None
        self._outbox_enabled = False

    def _uow_factory(self):
        if self.client is None:
            raise RuntimeError("Container.bootstrap(db, client=...) must run before using UnitOfWork")
        return MongoUnitOfWork(self.client)

    async def bootstrap(self, db, *, client=None) -> None:
        if self._initialised:
            return
        self.db = db
        self.client = client or getattr(db, "client", None)
        if self.client is None:
            raise RuntimeError("Mongo client is required for UnitOfWork")
        uow = self._uow_factory

        from modules.rooms.infrastructure.repository import MongoRoomRepository
        from modules.checkins.infrastructure.repository import MongoCheckinRepository
        from modules.checkouts.infrastructure.repository import MongoCheckoutRepository
        from modules.requests.infrastructure.repository import MongoRequestRepository
        from modules.inspections.infrastructure.repository import MongoInspectionRepository
        from modules.notifications.infrastructure.repository import MongoNotificationRepository
        from modules.identity.infrastructure.repository import MongoUserRepository
        from modules.billing.infrastructure.repository import MongoFolioRepository
        from modules.properties.infrastructure.repository import MongoPropertyRepository
        from modules.guests.infrastructure.repository import MongoGuestRepository
        from modules.reservations.infrastructure.repository import MongoReservationRepository
        from modules.settings.infrastructure.repository import MongoSettingRepository
        from modules.messaging.infrastructure.repository import MongoMessagingRepository
        from modules.audit.infrastructure.repository import MongoAuditRepository
        from modules.storage.infrastructure.repository import MongoStorageRepository

        rooms_repo = MongoRoomRepository(db)
        checkins_repo = MongoCheckinRepository(db)
        checkouts_repo = MongoCheckoutRepository(db)
        requests_repo = MongoRequestRepository(db)
        inspections_repo = MongoInspectionRepository(db)
        notifications_repo = MongoNotificationRepository(db)
        users_repo = MongoUserRepository(db)
        folios_repo = MongoFolioRepository(db)
        properties_repo = MongoPropertyRepository(db)
        guests_repo = MongoGuestRepository(db)
        reservations_repo = MongoReservationRepository(db)
        settings_repo = MongoSettingRepository(db)
        messaging_repo = MongoMessagingRepository(db)
        audit_repo = MongoAuditRepository(db)
        storage_repo = MongoStorageRepository(db)

        from modules.identity.infrastructure.repository import BcryptPasswordHasher
        from modules.notifications.infrastructure.repository import (
            HttpSmsAdapter,
            WhatsAppApiAdapter,
            WebSocketRealtimeAdapter,
        )

        async def settings_provider(key: str):
            return await db.settings.find_one({"key": key}, {"_id": 0})

        self.password_hasher = BcryptPasswordHasher()
        sms_adapter = HttpSmsAdapter(settings_provider=settings_provider, url_validator=validate_external_url)
        whatsapp_adapter = WhatsAppApiAdapter(settings_provider=settings_provider, url_validator=validate_external_url)
        realtime_adapter = WebSocketRealtimeAdapter(connection_manager=ws_manager)
        balance_reader = _FolioBalanceReader(folio_repository=folios_repo)
        room_occupancy = _RoomOccupancyBridge(rooms_repo)

        async def welcome_message_provider(guest_name: str, room_number: int) -> str:
            s = await db.settings.find_one({"key": "sms"}, {"_id": 0}) or {}
            tpl = s.get("welcome_message") or (
                "مرحباً {guest_name}، أهلاً بك في فندق جراند حياة. غرفتك رقم {room_number}.\n"
                "للخدمة عبر واتساب أرسل:\n1️⃣ نظافة الغرفة\n2️⃣ كرت إنترنت\n3️⃣ كشف الحساب"
            )
            try:
                return tpl.format(guest_name=guest_name, room_number=room_number)
            except Exception:
                return tpl

        from modules.rooms.application.service import RoomApplicationService, RoomEventSubscribers
        from modules.checkins.application.service import CheckinApplicationService, CheckOutGuest
        from modules.checkouts.application.service import CheckoutApplicationService, CheckoutEventSubscribers
        from modules.requests.application.service import RequestApplicationService, RequestEventSubscribers
        from modules.inspections.application.service import InspectionApplicationService
        from modules.notifications.application.service import NotificationApplicationService, NotificationSubscribers
        from modules.identity.application.service import IdentityApplicationService
        from modules.billing.application.service import BillingApplicationService
        from modules.properties.application.service import PropertyApplicationService, EnsureDefaultProperty
        from modules.guests.application.service import GuestApplicationService
        from modules.reservations.application.service import ReservationApplicationService
        from modules.settings.application.service import SettingApplicationService, PutSetting
        from modules.messaging.application.service import MessagingApplicationService
        from modules.audit.application.service import AuditApplicationService
        from modules.storage.application.service import StorageApplicationService

        self.rooms = RoomApplicationService(rooms=rooms_repo, uow_factory=uow, bus=self.bus)
        self.checkins = CheckinApplicationService(
            checkins=checkins_repo, uow_factory=uow, bus=self.bus, rooms=room_occupancy,
        )
        self.checkouts = CheckoutApplicationService(
            checkouts=checkouts_repo, uow_factory=uow, bus=self.bus, balance_port=balance_reader,
        )
        self.requests = RequestApplicationService(requests=requests_repo, uow_factory=uow, bus=self.bus)
        self.inspections = InspectionApplicationService(inspections=inspections_repo, uow_factory=uow, bus=self.bus)
        self.notifications = NotificationApplicationService(
            notifications=notifications_repo, uow_factory=uow, bus=self.bus,
            sms=sms_adapter, whatsapp=whatsapp_adapter, realtime=realtime_adapter,
        )
        self.identity = IdentityApplicationService(
            users=users_repo, uow_factory=uow, bus=self.bus, hasher=self.password_hasher,
        )
        self.billing = BillingApplicationService(folios=folios_repo, uow_factory=uow, bus=self.bus)
        self.properties = PropertyApplicationService(properties=properties_repo, uow_factory=uow, bus=self.bus)
        self.guests = GuestApplicationService(guests=guests_repo, uow_factory=uow, bus=self.bus)
        self.reservations = ReservationApplicationService(reservations=reservations_repo, uow_factory=uow, bus=self.bus)
        self.settings = SettingApplicationService(settings=settings_repo, uow_factory=uow, bus=self.bus)
        self.messaging = MessagingApplicationService(messaging=messaging_repo, uow_factory=uow, bus=self.bus)
        self.audit = AuditApplicationService(audit=audit_repo, uow_factory=uow, bus=self.bus)
        self.storage = StorageApplicationService(storage=storage_repo, uow_factory=uow, bus=self.bus)

        from kernel.security.scoping_rules import ScopingRules
        from shared.security.mongo_query_scoper import MongoQueryScoper
        self.scoping_rules = ScopingRules()
        self.query_scoper = MongoQueryScoper()
        for svc in (self.rooms, self.checkins, self.checkouts, self.requests, self.inspections):
            svc._scoping_rules = self.scoping_rules
            svc._scoper = self.query_scoper

        RoomEventSubscribers(self.rooms).register(self.bus)
        RequestEventSubscribers(self.requests).register(self.bus)

        async def _checkin_checkout_handler(checkin_id: str, checkout_id: str) -> None:
            try:
                await self.checkins.check_out(CheckOutGuest(checkin_id=checkin_id, actor_id="system"))
            except Exception as exc:  # noqa: BLE001 - checkout completion itself already happened
                logger.warning("checkin checkout handler failed for checkout=%s: %s", checkout_id, exc)

        CheckoutEventSubscribers(checkin_checkout_handler=_checkin_checkout_handler).register(self.bus)
        NotificationSubscribers(
            svc=self.notifications,
            welcome_template_provider=welcome_message_provider,
            prefer_whatsapp=True,
        ).register(self.bus)

        import os
        default_tenant_id = os.environ.get("DEFAULT_TENANT_ID", "default")
        default_property_id = os.environ.get("DEFAULT_PROPERTY_ID", "main")
        default_property_name = os.environ.get("DEFAULT_PROPERTY_NAME", "Grand Hayat Hotel")
        await self.properties.ensure_default(EnsureDefaultProperty(
            tenant_id=default_tenant_id, property_id=default_property_id,
            property_name=default_property_name,
        ))
        await self.settings.put(PutSetting(
            tenant_id=default_tenant_id, property_id=default_property_id,
            module="messaging", key="auto_reply", actor_id="system",
            value={
                "welcome_message": "أهلاً بكم في فندق جراند حياة. أرسل 1 للنظافة، 2 للإنترنت، 3 لكشف الحساب.",
                "option_1_action": "housekeeping",
                "option_2_action": "internet_card",
                "option_3_action": "billing",
            },
        ))
        from shared.foundation.permissions import DEFAULT_SOUND_RULES
        await self.settings.put(PutSetting(
            tenant_id=default_tenant_id, property_id=default_property_id,
            module="sounds", key="rules", actor_id="system",
            value=DEFAULT_SOUND_RULES,
        ))

        from modules.rooms.application.service import CreateFloor, CreateRoomType
        try:
            await self.rooms.create_floor(CreateFloor(
                number=1, name="الدور 1", rooms_per_floor=0,
                tenant_id=default_tenant_id, property_id=default_property_id, actor=None,
            ))
        except Exception:
            pass
        try:
            await self.rooms.create_room_type(CreateRoomType(
                code="standard", name="غرفة قياسية", base_rate=0, capacity=1, max_occupancy=2,
                tenant_id=default_tenant_id, property_id=default_property_id, actor=None,
            ))
        except Exception:
            pass

        await self._ensure_default_identity(default_tenant_id, default_property_id, default_property_name)
        await self._apply_sound_rules(db, default_tenant_id, default_property_id)
        await self._wire_sound_rule_refresh(db)
        await self._wire_session_revocation(db)
        await self._wire_outbox(db)

        self._initialised = True
        logger.info(
            "✅ Container bootstrapped — 15 modules wired "
            "(core PMS + foundation domains)"
        )

    async def _ensure_default_identity(self, tenant_id: str, property_id: str, property_name: str) -> None:
        import os
        from modules.identity.application.service import RegisterUser
        from shared.foundation.permissions import ROLE_PERMISSION_PRESETS

        async def create_if_missing(role: str, email_env: str, pass_env: str, name_env: str, email_default: str, pass_default: str, name_default: str):
            existing = await self.db.users.find_one({"tenant_id": tenant_id, "role": role}, {"_id": 1})
            if existing:
                return
            await self.identity.register(RegisterUser(
                email=os.environ.get(email_env, email_default),
                plain_password=os.environ.get(pass_env, pass_default),
                name=os.environ.get(name_env, name_default),
                role=role,
                department="management",
                floors=(),
                permissions=tuple(ROLE_PERMISSION_PRESETS[role]),
                request_types=(),
                actor_id="system",
                tenant_id=tenant_id,
                property_ids=(property_id,),
                active_property_id=property_id,
            ))
            logger.warning("Seeded default %s account for %s. Change its password immediately.", role, property_name)

        await create_if_missing(
            "super_admin", "DEFAULT_SUPER_ADMIN_EMAIL", "DEFAULT_SUPER_ADMIN_PASSWORD", "DEFAULT_SUPER_ADMIN_NAME",
            "superadmin@grandhayat.local", "ChangeMe@2026", "مدير المنصة",
        )
        await create_if_missing(
            "admin", "DEFAULT_ADMIN_EMAIL", "DEFAULT_ADMIN_PASSWORD", "DEFAULT_ADMIN_NAME",
            "admin@grandhayat.local", "Admin@2026", "مدير الفندق",
        )

    async def _apply_sound_rules(self, db, tenant_id: str, property_id: str) -> None:
        doc = await db.settings.find_one(
            {"tenant_id": tenant_id, "property_id": property_id, "module": "sounds", "key": "rules"},
            {"_id": 0, "value": 1},
        )
        try:
            ws_manager.set_sound_rules((doc or {}).get("value") or {})
        except Exception as exc:  # noqa: BLE001
            logger.warning("could not apply sound rules: %s", exc)

    async def _wire_sound_rule_refresh(self, db) -> None:
        async def refresh_sound_rules(event) -> None:
            if getattr(event, "module", "") == "sounds" and getattr(event, "key", "") == "rules":
                await self._apply_sound_rules(db, getattr(event, "tenant_id", "default"), getattr(event, "property_id", "main"))
        self.bus.subscribe("settings.updated", refresh_sound_rules, fail_fast=False)

    async def _wire_session_revocation(self, db) -> None:
        async def revoke_sessions(event) -> None:
            try:
                user_id = getattr(event, "user_id", None)
                if user_id:
                    await db.sessions.delete_many({"user_id": user_id})
                    logger.info("sessions revoked for user %s (cause=%s)", user_id, event.topic)
            except Exception as exc:  # noqa: BLE001
                logger.warning("session revocation failed: %s", exc)

        for topic in (
            "identity.user_password_changed",
            "identity.user_role_changed",
            "identity.user_permissions_changed",
            "identity.user_deactivated",
        ):
            self.bus.subscribe(topic, revoke_sessions, fail_fast=False)

    async def _wire_outbox(self, db) -> None:
        from shared.outbox.repository import MongoOutboxRepository
        from shared.outbox.service import OutboxService
        from shared.outbox.worker import OutboxWorker
        from shared.outbox.aware_bus import OutboxAwareBus
        from shared.outbox.management_service import OutboxManagementService

        outbox_repo = MongoOutboxRepository(db)
        self.outbox_service = OutboxService(outbox=outbox_repo, bus=self.bus)
        self.outbox_worker = OutboxWorker(
            outbox=outbox_repo, service=self.outbox_service,
            poll_interval_seconds=1.0, batch_size=50,
        )
        self.outbox_bus = OutboxAwareBus(real_bus=self.bus, outbox_service=self.outbox_service)
        self.outbox_management = OutboxManagementService(repository=outbox_repo)
        self._outbox_enabled = True
        logger.info("✅ Outbox wired (service + worker + aware_bus + management)")

    def enable_outbox_delivery(self) -> None:
        if not self._outbox_enabled or not self.outbox_bus:
            raise RuntimeError("Outbox is not bootstrapped")
        for svc in (self.rooms, self.checkins, self.checkouts, self.requests,
                    self.inspections, self.notifications, self.identity, self.billing,
                    self.properties, self.guests, self.reservations, self.settings,
                    self.messaging, self.audit, self.storage):
            if svc is not None and hasattr(svc, "_bus"):
                svc._bus = self.outbox_bus
        logger.info("✅ Outbox delivery enabled")


container = Container()
