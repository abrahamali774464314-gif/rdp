"""MongoDB indexes for the modular PMS/SaaS backend."""
from __future__ import annotations


async def ensure_indexes(db) -> None:
    """Create required indexes.

    The compound tenant/property indexes are the default for new deployments.
    Existing single-hotel databases may still have old global unique indexes;
    run tools/migrate_tenant_property.py before using multiple properties.
    """
    await db.users.create_index("id", unique=True)
    await db.users.create_index([("tenant_id", 1), ("email", 1)], unique=True)
    await db.users.create_index([("tenant_id", 1), ("active_property_id", 1), ("role", 1)])
    await db.sessions.create_index("id", unique=True)
    await db.sessions.create_index([("user_id", 1), ("revoked_at", 1), ("created_at", -1)])
    await db.sessions.create_index("expires_at", expireAfterSeconds=0)
    await db.token_blacklist.create_index("jti", unique=True)
    await db.token_blacklist.create_index("expires_at", expireAfterSeconds=0)

    await db.floors.create_index([("tenant_id", 1), ("property_id", 1), ("number", 1)], unique=True)
    await db.floors.create_index([("tenant_id", 1), ("property_id", 1), ("is_deleted", 1), ("number", 1)])
    await db.room_types.create_index([("tenant_id", 1), ("property_id", 1), ("code", 1)], unique=True)
    await db.room_types.create_index([("tenant_id", 1), ("property_id", 1), ("is_active", 1), ("name", 1)])

    await db.rooms.create_index([("tenant_id", 1), ("property_id", 1), ("number", 1)], unique=True)
    await db.rooms.create_index([("tenant_id", 1), ("property_id", 1), ("floor", 1)])
    await db.rooms.create_index([("tenant_id", 1), ("property_id", 1), ("status", 1), ("floor", 1)])
    await db.rooms.create_index([("tenant_id", 1), ("property_id", 1), ("active_checkin_id", 1)])
    await db.rooms.create_index([("tenant_id", 1), ("property_id", 1), ("guest_phone", 1)])

    await db.checkins.create_index("id", unique=True)
    await db.checkins.create_index([("tenant_id", 1), ("property_id", 1), ("room_number", 1), ("status", 1)])
    await db.checkins.create_index([("tenant_id", 1), ("property_id", 1), ("created_at", -1)])

    await db.checkouts.create_index("id", unique=True)
    await db.checkouts.create_index([("tenant_id", 1), ("property_id", 1), ("room_number", 1), ("status", 1)])
    await db.checkouts.create_index([("tenant_id", 1), ("property_id", 1), ("status", 1), ("created_at", -1)])

    await db.requests.create_index("id", unique=True)
    await db.requests.create_index([("tenant_id", 1), ("property_id", 1), ("room_number", 1), ("status", 1)])
    await db.requests.create_index([("tenant_id", 1), ("property_id", 1), ("department", 1), ("status", 1), ("floor", 1)])
    await db.requests.create_index([("tenant_id", 1), ("property_id", 1), ("source", 1), ("type", 1), ("room_number", 1), ("status", 1)])

    await db.room_inspections.create_index("id", unique=True)
    await db.room_inspections.create_index([("tenant_id", 1), ("property_id", 1), ("room_number", 1), ("created_at", -1)])
    await db.room_inspections.create_index([("tenant_id", 1), ("property_id", 1), ("report_type", 1), ("created_at", -1)])

    await db.folios.create_index("id", unique=True)
    await db.folios.create_index([("tenant_id", 1), ("property_id", 1), ("checkin_id", 1), ("folio_type", 1)])
    await db.folio_transactions.create_index("id", unique=True)
    await db.folio_transactions.create_index("folio_id")
    await db.folio_transactions.create_index(
        [("idempotency_key", 1)], unique=True,
        partialFilterExpression={"idempotency_key": {"$type": "string"}},
    )

    await db.notifications_log.create_index("id", unique=True)
    await db.notifications_log.create_index(
        [("idempotency_key", 1)], unique=True,
        partialFilterExpression={"idempotency_key": {"$type": "string"}},
    )
    await db.outbox_messages.create_index([("status", 1), ("next_attempt_at", 1), ("created_at", 1)])
    await db.outbox_messages.create_index("event_id", unique=True)

    # PMS Foundation modules
    await db.tenants.create_index("id", unique=True)
    await db.properties.create_index([("tenant_id", 1), ("id", 1)], unique=True)
    await db.properties.create_index([("tenant_id", 1), ("code", 1)], unique=True)
    await db.guests.create_index("id", unique=True)
    await db.guests.create_index([("tenant_id", 1), ("property_id", 1), ("phone", 1)], unique=True)
    await db.guests.create_index([("tenant_id", 1), ("property_id", 1), ("full_name", 1)])
    await db.reservations.create_index("id", unique=True)
    await db.reservations.create_index([("tenant_id", 1), ("property_id", 1), ("arrival_date", 1), ("departure_date", 1)])
    await db.reservations.create_index([("tenant_id", 1), ("property_id", 1), ("room_number", 1), ("status", 1), ("arrival_date", 1)])
    await db.settings.create_index([("tenant_id", 1), ("property_id", 1), ("module", 1), ("key", 1)], unique=True)
    await db.conversations.create_index("id", unique=True)
    await db.conversations.create_index(
        [("tenant_id", 1), ("property_id", 1), ("channel", 1), ("phone", 1)],
        unique=True,
        partialFilterExpression={"phone": {"$type": "string", "$ne": ""}},
    )
    await db.conversations.create_index([("tenant_id", 1), ("property_id", 1), ("updated_at", -1)])
    await db.messages.create_index("id", unique=True)
    await db.messages.create_index([("tenant_id", 1), ("property_id", 1), ("conversation_id", 1), ("created_at", 1)])
    await db.audit_logs.create_index("id", unique=True)
    await db.audit_logs.create_index([("tenant_id", 1), ("property_id", 1), ("created_at", -1)])
    await db.audit_logs.create_index([("tenant_id", 1), ("property_id", 1), ("action", 1), ("created_at", -1)])
    await db.stored_files.create_index("id", unique=True)
    await db.stored_files.create_index([("tenant_id", 1), ("property_id", 1), ("owner_type", 1), ("owner_id", 1)])

