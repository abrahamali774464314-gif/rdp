"""API response contract helpers.

All new PMS Foundation endpoints should return the same envelope:

{
  "data": ...,        # object/list/null
  "meta": {...},     # pagination/scope/version information
  "error": null      # or {code, message, details}
}
"""
from __future__ import annotations

from typing import Any


def success(data: Any = None, *, meta: dict[str, Any] | None = None) -> dict[str, Any]:
    return {"data": data, "meta": meta or {}, "error": None}


def collection(items: list[Any], *, meta: dict[str, Any] | None = None) -> dict[str, Any]:
    base = {"count": len(items)}
    if meta:
        base.update(meta)
    return success(items, meta=base)


def error_payload(code: str, message: str, *, details: Any = None) -> dict[str, Any]:
    err: dict[str, Any] = {"code": code, "message": message}
    if details is not None:
        err["details"] = details
    return {"data": None, "meta": {}, "error": err}
