"""
shared.security.base_scoped_repository — Mixin موحّد للاستعلامات المُقيَّدة
═══════════════════════════════════════════════════════════════════

يلغي تكرار list_scoped في كل مستودع. كل مستودع Mongo لديه بالفعل:
  - self._col      (مجموعة Mongo)
  - self._to_entity (محوّل مستند → كيان)

هذا الـ mixin يبني عليهما list_scoped موحّداً، فلا يكرّر كل مستودع المنطق.

الاستخدام:
    class MongoRequestRepository(ScopedRepositoryMixin, RequestRepository):
        _scope_default_filter = {}        # أو {"is_deleted": {"$ne": True}}
        _scope_sort_field = "created_at"
        _scope_sort_dir = -1
        ...

قواعد الأمان (fail-closed دائماً):
  - الـ mixin يستقبل scoped_filter **جاهزاً** من الـ application (بناه عبر
    MongoQueryScoper). لا يبني سياسة — يدمج فقط مع الثابت التخزيني ويُنفّذ.
  - إن جاء scoped_filter يحوي الاستعلام المستحيل ({"_id":"__no_match__"})،
    يمرّ كما هو → يُرجِع صفر نتائج (fail-closed محفوظ من طرف الـ scoper).

نقطة النقاء: هذا shared (لا kernel) — يلمس Mongo. لا منطق أمان (سياسة)
هنا؛ فقط دمج وتنفيذ. السياسة تعيش في kernel/security.
"""
from __future__ import annotations


class ScopedRepositoryMixin:
    """يوفّر list_scoped موحّداً لأي مستودع لديه _col و _to_entity.

    يُخصَّص عبر سمات صنفية (class attributes) اختيارية:
      _scope_default_filter : فلتر ثابت يُدمج دائماً (مثل عدم الحذف).
      _scope_sort_field     : حقل الترتيب (None = بلا ترتيب).
      _scope_sort_dir       : اتجاه الترتيب (1 تصاعدي، -1 تنازلي).
      _scope_default_limit  : السقف الافتراضي للنتائج.
    """

    _scope_default_filter: dict = {}
    _scope_sort_field: str | None = None
    _scope_sort_dir: int = -1
    _scope_default_limit: int = 1000

    async def list_scoped(self, scoped_filter: dict, *, limit: int | None = None):
        """يُرجع الكيانات المطابقة لاستعلام مُقيَّد جاهز.

        الـ repository غبيّ هنا: يستقبل الفلتر النهائي (الذي بناه الـ
        application عبر QueryScoper) ويدمجه مع الثابت التخزيني فقط.
        """
        query = self._merge(self._scope_default_filter, scoped_filter)
        cursor = self._col.find(query, {"_id": 0})
        if self._scope_sort_field:
            cursor = cursor.sort(self._scope_sort_field, self._scope_sort_dir)
        cap = limit if limit is not None else self._scope_default_limit
        docs = await cursor.to_list(cap)
        return [self._to_entity(d) for d in docs]

    # ── دمج آمن للفلاتر (AND صريح، يتجنّب $and عند طرف واحد) ──
    @staticmethod
    def _merge(default_filter: dict, scoped_filter: dict) -> dict:
        parts = [p for p in (default_filter, scoped_filter) if p]
        if not parts:
            return {}
        if len(parts) == 1:
            return dict(parts[0])
        return {"$and": [dict(p) for p in parts]}
