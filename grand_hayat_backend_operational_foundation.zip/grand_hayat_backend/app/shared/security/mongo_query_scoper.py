"""
shared.security.mongo_query_scoper — ترجمة AccessScope إلى استعلام Mongo
═══════════════════════════════════════════════════════════════════

هذا الملف يُجيب على **"كيف أستعلم؟"** — يأخذ AccessScope المحايد (من
kernel/security) ويترجمه إلى فلتر Mongo فعلي. هو المكان **الوحيد** الذي
تظهر فيه صياغة MongoDB ($in/$or/$eq) المتعلّقة بالـ scoping.

منطق الترجمة (AND بين القيود المختلفة، OR داخل قيد الملكية):

  AccessScope                         →  Mongo filter
  ─────────────────────────────────────────────────────────────
  full_access                         →  base_query (بلا قيود)
  denied                              →  {"_id": "__no_match__"} (يُرجِع 0)
  floors={2,3}                        →  {"floor": {"$in": [2,3]}}
  departments={"housekeeping"}        →  {"department": "housekeeping"}
  owner_id="u1",                      →  {"$or": [{"created_by":"u1"},
    owner_fields=("created_by",            {"accepted_by":"u1"}]}
                 "accepted_by")
  قيود متعدّدة                         →  {"$and": [base, floor, dept, owner]}

اعتبارات الفهارس (index considerations):
  - floor + status فهرس مركّب موجود في seed (rooms). نضع floor كـ $in
    ليستفيد الـ planner من الفهرس.
  - department + status + floor فهرس موجود للـ requests.
  - قيد الملكية ($or على عدّة حقول) قد لا يستفيد من فهرس واحد؛ لذا يُطبَّق
    على staff فقط وعلى استعلامات محدودة النتائج (history)، تماماً كالقديم.

نقطة الأمان: قيمة AccessScope **denied** تُترجَم إلى استعلام مستحيل
({"_id": "__no_match__"}) بدل إرجاع base_query — fail-closed، لا fail-open.
"""
from __future__ import annotations

from kernel.security.query_scoper import AccessScope, QueryScoper

# استعلام مستحيل المطابقة (fail-closed عند الحرمان)
IMPOSSIBLE_QUERY: dict = {"_id": "__no_match__"}


class MongoQueryScoper(QueryScoper):
    """يترجم AccessScope إلى فلتر Mongo، ويدمجه مع base_query.

    عديم الحالة (stateless) → آمن للمشاركة كـ singleton. كل المعلومات
    تأتي من المعاملات، فلا يحتفظ بأي شيء بين الاستدعاءات.
    """

    def apply(self, base_query: dict, scope: AccessScope, *,
              floor_field: str = "floor",
              department_field: str = "department",
              tenant_field: str = "tenant_id",
              property_field: str = "property_id") -> dict:
        """يبني الاستعلام النهائي من base_query + قيود الـ scope.

        الإرجاع:
          - full_access → base_query كما هو (نسخة).
          - denied      → استعلام مستحيل (fail-closed).
          - غير ذلك     → دمج AND للقيود المطبَّقة.
        """
        # ① حرمان مطلق → استعلام مستحيل (لا تسريب بيانات)
        if scope.is_empty:
            return dict(IMPOSSIBLE_QUERY)

        # ② وصول كامل → الأساس فقط
        if scope.is_unrestricted:
            return dict(base_query)

        # ③ بناء قائمة القيود (clauses) ثم دمجها
        clauses: list[dict] = []
        if base_query:
            clauses.append(dict(base_query))

        tenant_clause = self._tenant_clause(scope, tenant_field)
        if tenant_clause:
            clauses.append(tenant_clause)

        property_clause = self._property_clause(scope, property_field)
        if property_clause:
            clauses.append(property_clause)

        floor_clause = self._floor_clause(scope, floor_field)
        if floor_clause:
            clauses.append(floor_clause)

        dept_clause = self._department_clause(scope, department_field)
        if dept_clause:
            clauses.append(dept_clause)

        owner_clause = self._owner_clause(scope)
        if owner_clause:
            clauses.append(owner_clause)

        return self._combine(clauses)

    # ── بناء القيود الفردية ───────────────────────────────────
    @staticmethod
    def _tenant_clause(scope: AccessScope, field: str) -> dict | None:
        if not scope.has_tenant_constraint():
            return None
        return {field: scope.tenant_id}

    @staticmethod
    def _property_clause(scope: AccessScope, field: str) -> dict | None:
        if not scope.has_property_constraint():
            return None
        if scope.active_property_id:
            return {field: scope.active_property_id}
        property_ids = sorted(scope.property_ids or ())
        if not property_ids:
            return None
        return {field: {"$in": property_ids}}

    @staticmethod
    def _floor_clause(scope: AccessScope, field: str) -> dict | None:
        """طوابق → $in. (None = لا قيد، فارغة = denied عُولِجت سابقاً)."""
        if not scope.has_floor_constraint():
            return None
        floors = sorted(scope.floors)  # ترتيب ثابت → deterministic
        return {field: {"$in": floors}}

    @staticmethod
    def _department_clause(scope: AccessScope, field: str) -> dict | None:
        """أقسام → $eq لقسم واحد، $in لعدّة أقسام."""
        if not scope.has_department_constraint():
            return None
        depts = sorted(scope.departments)
        if len(depts) == 1:
            return {field: depts[0]}      # $eq ضمنيّ — أوضح وأخفّ
        return {field: {"$in": depts}}

    @staticmethod
    def _owner_clause(scope: AccessScope) -> dict | None:
        """ملكية → $or على كل حقول الملكية (يرى ما أنشأ أو قبِل أو أكمل...)."""
        if not scope.has_owner_constraint():
            return None
        ors = [{f: scope.owner_id} for f in scope.owner_fields]
        if len(ors) == 1:
            return ors[0]
        return {"$or": ors}

    # ── دمج القيود ────────────────────────────────────────────
    @staticmethod
    def _combine(clauses: list[dict]) -> dict:
        """يدمج القيود بـ AND. يتجنّب $and عند قيد واحد (أنظف)."""
        clauses = [c for c in clauses if c]
        if not clauses:
            return {}
        if len(clauses) == 1:
            return clauses[0]
        return {"$and": clauses}
