"""
shared.security.scoped_listing — مساعد موحّد لقائمة مُقيَّدة حسب الفاعل
═══════════════════════════════════════════════════════════════════

يُغلّف الحلقة المتكرّرة في كل Application Service:

    Actor → ScopingRules.for_X → AccessScope → MongoQueryScoper → filter
          → repository.list_scoped(filter)

بدل تكرار هذه الخطوات في كل service، يستدعي الـ service دالة واحدة:

    rooms   = await scoped_list(repo, rules.for_rooms,    actor, base, **kw)
    reqs    = await scoped_list(repo, rules.for_requests, actor, base, **kw)

يحافظ على:
  - تقليل التكرار (DRY) — الحلقة في مكان واحد.
  - fail-closed — يمرّ عبر MongoQueryScoper الذي يترجم denied لاستعلام مستحيل.
  - نقاء kernel — هذا shared، يستورد من kernel فقط (لا motor مباشر هنا).

singletons داخلية: نبني MongoQueryScoper مرّة (عديم الحالة) ونعيد استخدامه.
"""
from __future__ import annotations

from typing import Callable

from kernel.security.query_scoper import AccessScope, Actor
from shared.security.mongo_query_scoper import MongoQueryScoper

# عديم الحالة → singleton آمن
_SCOPER = MongoQueryScoper()


async def scoped_list(
    repository,
    resolve_scope: Callable[[Actor], AccessScope],
    actor: Actor,
    *,
    scoper: "MongoQueryScoper | None" = None,
    base_query: dict | None = None,
    floor_field: str = "floor",
    department_field: str = "department",
    limit: int | None = None,
):
    """يُنفّذ الحلقة الكاملة ويُرجع قائمة الكيانات المُقيَّدة.

    repository    : مستودع يطبّق ScopedRepositoryMixin (لديه list_scoped).
    resolve_scope : دالة تُرجع AccessScope من Actor (مثل rules.for_requests).
    actor         : الفاعل الحالي (صورة مبسّطة، لا UserEntity).
    scoper        : MongoQueryScoper محقون من الـ container. لو None، يُستخدم
                    الـ singleton الداخلي (توافق للاستخدام بلا container).
    base_query    : فلتر أساسي اختياري (مثل {"status": "pending"}).
    """
    active_scoper = scoper or _SCOPER
    scope = resolve_scope(actor)
    scoped_filter = active_scoper.apply(
        base_query or {}, scope,
        floor_field=floor_field, department_field=department_field,
    )
    return await repository.list_scoped(scoped_filter, limit=limit)
