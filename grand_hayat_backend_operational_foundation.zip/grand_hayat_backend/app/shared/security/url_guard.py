"""shared.security.url_guard — outbound URL validation / SSRF protection."""
from __future__ import annotations

import ipaddress
import socket
from urllib.parse import urlparse

from kernel.errors import InvariantViolationError

_BLOCKED_HOSTS = {"localhost", "metadata.google.internal", "metadata"}


def validate_external_url(url: str, allow_http: bool = False) -> str:
    if not url or not isinstance(url, str):
        raise InvariantViolationError("رابط API غير صالح")
    url = url.strip()
    try:
        parsed = urlparse(url)
    except Exception as exc:  # noqa: BLE001
        raise InvariantViolationError("رابط API غير صالح") from exc

    if parsed.scheme not in ("http", "https"):
        raise InvariantViolationError("يجب أن يبدأ الرابط بـ https:// أو http://")
    if parsed.scheme == "http" and not allow_http:
        raise InvariantViolationError("رابط API يجب أن يكون https")
    if parsed.username or parsed.password:
        raise InvariantViolationError("بيانات اعتماد داخل الرابط غير مسموح بها")

    host = (parsed.hostname or "").lower()
    if not host:
        raise InvariantViolationError("اسم المضيف مفقود في الرابط")
    if host in _BLOCKED_HOSTS:
        raise InvariantViolationError("نطاق غير مسموح به")

    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror as exc:
        raise InvariantViolationError("تعذر حل اسم المضيف") from exc

    for info in infos:
        ip_str = info[4][0]
        try:
            ip = ipaddress.ip_address(ip_str)
        except ValueError:
            continue
        if (
            ip.is_private or ip.is_loopback or ip.is_link_local
            or ip.is_multicast or ip.is_reserved or ip.is_unspecified
        ):
            raise InvariantViolationError("عنوان IP داخلي / خاص غير مسموح")
    return url
