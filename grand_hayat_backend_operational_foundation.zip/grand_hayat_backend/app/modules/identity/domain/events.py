"""
modules.identity.domain.events — أحداث مجال الهوية
═══════════════════════════════════════════════════════════════════

أحداث المستخدم وحقوقه. بعضها يحمل دلالة أمنية حسّاسة:
  - UserPasswordChanged       → يُبطل كل الجلسات القديمة (subscriber في infra)
  - UserRoleChanged           → يُبطل الجلسات لاحتمال فقدان صلاحيات
  - UserPermissionsChanged    → يُبطل الجلسات للسبب نفسه
  - UserDeactivated           → يُسقط الجلسات فوراً
  - UserLocked / UserUnlocked → آليّة منع الـ brute-force

ملاحظة: لا حدث «تسجيل دخول ناجح/فاشل» في الـ domain layer — هذه أحداث
بروتوكولية (HTTP/جلسات) مكانها في application/infrastructure، لا في
مجال الهوية النقي. المجال يهتمّ بحالة المستخدم وحقوقه فقط.
"""
from __future__ import annotations

from dataclasses import dataclass

from kernel.contracts import DomainEvent


@dataclass(frozen=True)
class UserCreated(DomainEvent):
    """أُنشئ مستخدم جديد."""
    topic = "identity.user_created"
    user_id: str = ""
    email: str = ""
    role: str = ""
    department: str = ""


@dataclass(frozen=True)
class UserPasswordChanged(DomainEvent):
    """غُيِّرت كلمة المرور — يجب إبطال كل الجلسات القديمة لهذا المستخدم.

    حسّاس: subscriber في infrastructure يستمع له ويبطل الـ JWTs قبل
    password_changed_at (نفس آلية النظام القديم).
    """
    topic = "identity.user_password_changed"
    user_id: str = ""
    changed_at: str = ""


@dataclass(frozen=True)
class UserRoleChanged(DomainEvent):
    """تغيّر دور المستخدم — قد يفقد صلاحيات، فيجب إبطال الجلسات."""
    topic = "identity.user_role_changed"
    user_id: str = ""
    old_role: str = ""
    new_role: str = ""


@dataclass(frozen=True)
class UserPermissionsChanged(DomainEvent):
    """تغيّرت قائمة الصلاحيات أو الأقسام أو الأدوار المسموحة."""
    topic = "identity.user_permissions_changed"
    user_id: str = ""


@dataclass(frozen=True)
class UserDeactivated(DomainEvent):
    """عُطِّل الحساب — يُسقط الجلسات فوراً."""
    topic = "identity.user_deactivated"
    user_id: str = ""


@dataclass(frozen=True)
class UserReactivated(DomainEvent):
    """أُعيد تفعيل الحساب."""
    topic = "identity.user_reactivated"
    user_id: str = ""


@dataclass(frozen=True)
class UserLocked(DomainEvent):
    """قُفل الحساب بعد عدد فاشل من المحاولات (brute-force protection)."""
    topic = "identity.user_locked"
    user_id: str = ""
    reason: str = ""


@dataclass(frozen=True)
class UserUnlocked(DomainEvent):
    """فُكّ قفل الحساب يدوياً من المدير."""
    topic = "identity.user_unlocked"
    user_id: str = ""
