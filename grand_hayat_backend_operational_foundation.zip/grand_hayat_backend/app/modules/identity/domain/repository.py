"""
modules.identity.domain.repository — واجهة مستودع المستخدمين
═══════════════════════════════════════════════════════════════════

Repository Law (البند 4): الـ application يعتمد على هذا Protocol فقط.

ملاحظتان دقيقتان:
  - get_by_email: يبحث بالبريد المُطبَّع (lowercase). الـ Entity يضمن
    التطبيع عبر EmailAddress، لكن المستودع يطبّع الاستعلام أيضاً للأمان.
  - has_any_admin: يستخدمه الـ seeding للتحقق إن كان admin موجوداً.
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable

from modules.identity.domain.models import UserEntity


@runtime_checkable
class UserRepository(Protocol):
    """عقد تخزين المستخدمين."""

    async def get(self, user_id: str) -> UserEntity | None:
        """يجلب مستخدماً بمعرّفه."""
        ...

    async def get_by_email(self, email: str) -> UserEntity | None:
        """يجلب مستخدماً ببريده (للـ login). يطبّع البريد lowercase داخلياً."""
        ...

    async def add(self, user: UserEntity, uow=None) -> UserEntity:
        """يُدرج مستخدماً جديداً. يجب أن يفرض تفرّد البريد على مستوى DB."""
        ...

    async def save(self, user: UserEntity, uow=None) -> UserEntity:
        """يحدّث مستخدماً قائماً."""
        ...

    async def list_all(self, *, limit: int = 200) -> list[UserEntity]:
        """قائمة كل المستخدمين (للإدارة)."""
        ...

    async def has_any_admin(self) -> bool:
        """يستخدمه الـ seeding للتحقّق من وجود مدير."""
        ...
