"""
modules.identity.domain.models — كيان المستخدم وسياسة صلاحياته
═══════════════════════════════════════════════════════════════════

Domain Ownership: يملك حساب المستخدم، حقوقه، حالته، وسياسة الفحص.

نقاط معمارية محورية:

① PasswordHash كـ value object معتم (opaque):
   المجال يحمل الهاش كنص فقط، بلا أي معرفة عن bcrypt/argon2.
   التشفير والتحقق يعيشان في infrastructure (PasswordHasherPort).
   هذا يحمي الـ domain من كل آلية تشفير ويسمح بترقيتها مستقبلاً.

② سياسة الصلاحيات في الـ Entity:
   `has_permission`, `can_access_floor`, `can_handle_request_type` —
   منطق مجالي أصيل يعيش هنا، لا في middleware ولا في الـ controllers.
   هذا يضمن وحدة القرار: لا تسريب لقواعد الـ admin يتجاوز كل شيء.

③ State Machine لحساب المستخدم:
   active → inactive (تعطيل) | locked (قفل أمني) → reactivated/unlocked.

④ password_changed_at:
   حقل أمني — أي JWT أُصدر قبل هذا الوقت يُعتبر باطلاً.
   النظام القديم يستخدمه في deps.get_current_user.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from kernel.contracts import DomainEvent, Entity
from kernel.errors import ConflictError, InvariantViolationError
from kernel.state_machine import StateMachine

from modules.identity.domain.events import (
    UserCreated,
    UserDeactivated,
    UserLocked,
    UserPasswordChanged,
    UserPermissionsChanged,
    UserReactivated,
    UserRoleChanged,
    UserUnlocked,
)

# ══════════════════════════════════════════════════════════════
# Constants — الأدوار، الأقسام، الصلاحيات
# ══════════════════════════════════════════════════════════════
ROLE_SUPER_ADMIN = "super_admin"
ROLE_ADMIN = "admin"
ROLE_SUPERVISOR = "supervisor"
ROLE_STAFF = "staff"
VALID_ROLES = frozenset({ROLE_SUPER_ADMIN, ROLE_ADMIN, ROLE_SUPERVISOR, ROLE_STAFF})

VALID_DEPARTMENTS = frozenset({
    "general", "housekeeping", "maintenance", "it",
    "reception", "room_service", "billing", "laundry", "management",
})


# ══════════════════════════════════════════════════════════════
# Value Objects
# ══════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class EmailAddress:
    """عنوان بريد. يتحقّق من البنية البسيطة فقط (تحقّق دقيق في الـ API)."""
    value: str

    def __post_init__(self) -> None:
        v = (self.value or "").strip().lower()
        if "@" not in v or len(v) < 5:
            raise InvariantViolationError(f"بريد إلكتروني غير صالح: {self.value}")
        # تطبيع: dataclass frozen يمنع التعديل المباشر، نستخدم object.__setattr__
        object.__setattr__(self, "value", v)


@dataclass(frozen=True)
class PasswordHash:
    """هاش كلمة المرور كقيمة معتمة.

    المجال لا يعرف خوارزمية التشفير — يحمل النص المشفّر فقط ويقارنه
    عبر PasswordHasherPort المحقون. هذا يفصل المجال عن bcrypt/argon2.
    """
    encoded: str

    def __post_init__(self) -> None:
        if not (self.encoded or "").strip():
            raise InvariantViolationError("هاش كلمة المرور فارغ")


# ══════════════════════════════════════════════════════════════
# Port — التحقّق من كلمة المرور (المجال يُعرّف، infrastructure يُنفّذ)
# ══════════════════════════════════════════════════════════════
@runtime_checkable
class PasswordHasherPort(Protocol):
    """عقد التشفير. التنفيذ في infrastructure (bcrypt حالياً)."""

    def hash(self, plain: str) -> PasswordHash: ...
    def verify(self, plain: str, hashed: PasswordHash) -> bool: ...


# ══════════════════════════════════════════════════════════════
# State Machine — دورة حياة الحساب
# ══════════════════════════════════════════════════════════════
USER_FSM = StateMachine(
    name="user",
    transitions={
        "active":   {"inactive", "locked"},
        "inactive": {"active"},
        "locked":   {"active"},   # فكّ القفل يدوياً من المدير
    },
)


# ══════════════════════════════════════════════════════════════
# Entity — المستخدم (Aggregate Root)
# ══════════════════════════════════════════════════════════════
@dataclass
class UserEntity(Entity):
    """حساب موظف فندقي. يحمل صلاحياته وسياسة فحصها.

    Invariants:
      - role ضمن VALID_ROLES
      - department ضمن VALID_DEPARTMENTS
      - الـ admin يحصل تلقائياً على كل الصلاحيات (لا تسريب لهذه القاعدة خارجاً)
      - failed_login_attempts ≥ 0
    """
    id: str
    email: EmailAddress
    name: str
    password_hash: PasswordHash
    role: str = ROLE_STAFF
    department: str = "general"
    floors: tuple[int, ...] = ()
    permissions: tuple[str, ...] = ()
    request_types: tuple[str, ...] = ()
    tenant_id: str = "default"
    property_ids: tuple[str, ...] = ("main",)
    active_property_id: str = "main"
    status: str = "active"
    password_changed_at: str = ""    # للأمن: يبطل JWT قبل هذا الوقت
    failed_login_attempts: int = 0
    last_login_at: str = ""
    created_at: str = ""

    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    def pull_events(self) -> list[DomainEvent]:
        ev, self._events = self._events, []
        return ev

    # ── Invariants ────────────────────────────────────────────
    def _check_invariants(self) -> None:
        if self.role not in VALID_ROLES:
            raise InvariantViolationError(f"دور غير معروف: {self.role}")
        if self.department not in VALID_DEPARTMENTS:
            raise InvariantViolationError(f"قسم غير معروف: {self.department}")
        if not (self.name or "").strip():
            raise InvariantViolationError("اسم المستخدم مطلوب")
        if self.failed_login_attempts < 0:
            raise InvariantViolationError("عدّاد المحاولات الفاشلة سالب")
        if not (self.tenant_id or "").strip():
            raise InvariantViolationError("tenant_id مطلوب")
        if self.role not in {ROLE_SUPER_ADMIN, ROLE_ADMIN} and not self.property_ids:
            raise InvariantViolationError("يجب ربط المستخدم بعقار واحد على الأقل")

    # ── سياسة الصلاحيات (منطق مجالي مركزي) ───────────────────
    @property
    def is_active(self) -> bool:
        return self.status == "active"

    def has_permission(self, permission: str) -> bool:
        """admin له كل شيء؛ غيره يفحص قائمته. السياسة في مكان واحد فقط."""
        if not self.is_active:
            return False
        if self.role in {ROLE_SUPER_ADMIN, ROLE_ADMIN}:
            return True
        return permission in self.permissions

    def can_access_floor(self, floor: int) -> bool:
        if not self.is_active:
            return False
        if self.role in {ROLE_SUPER_ADMIN, ROLE_ADMIN}:
            return True
        if not self.floors:
            return False
        return int(floor) in self.floors

    def can_handle_request_type(self, request_type: str) -> bool:
        if not self.is_active:
            return False
        if self.role in {ROLE_SUPER_ADMIN, ROLE_ADMIN} or self.department == "general":
            return True
        if self.request_types:
            return request_type in self.request_types
        # fallback: قسم القسم يحدّد الأنواع المسموحة (يُحلّ في طبقة الـ scope)
        return True

    # ── Behaviours ────────────────────────────────────────────
    def register(self) -> None:
        """يُطلق حدث الإنشاء (يُستدعى بعد البناء)."""
        self._check_invariants()
        self._events.append(UserCreated(
            user_id=self.id, email=self.email.value,
            role=self.role, department=self.department,
        ))

    def change_password(self, new_hash: PasswordHash, *, at: str) -> None:
        """يحدّث الهاش ويُصدر حدثاً يُبطل الجلسات القديمة."""
        self.password_hash = new_hash
        self.password_changed_at = at
        self.failed_login_attempts = 0   # إعادة العدّاد عند نجاح تغيير المرور
        if self.status == "locked":
            # تغيير المرور يفكّ القفل (سياسة شائعة)
            self.status = USER_FSM.transition(self.status, "active")
            self._events.append(UserUnlocked(user_id=self.id))
        self._events.append(UserPasswordChanged(user_id=self.id, changed_at=at))

    def change_role(self, new_role: str) -> None:
        if new_role not in VALID_ROLES:
            raise InvariantViolationError(f"دور غير معروف: {new_role}")
        if new_role == self.role:
            return  # idempotent
        old = self.role
        self.role = new_role
        self._check_invariants()
        self._events.append(UserRoleChanged(
            user_id=self.id, old_role=old, new_role=new_role,
        ))

    def update_permissions(self, *, permissions: tuple[str, ...] | None = None,
                           floors: tuple[int, ...] | None = None,
                           request_types: tuple[str, ...] | None = None,
                           department: str | None = None) -> None:
        changed = False
        if permissions is not None and tuple(permissions) != self.permissions:
            self.permissions = tuple(permissions)
            changed = True
        if floors is not None and tuple(floors) != self.floors:
            self.floors = tuple(floors)
            changed = True
        if request_types is not None and tuple(request_types) != self.request_types:
            self.request_types = tuple(request_types)
            changed = True
        if department is not None and department != self.department:
            if department not in VALID_DEPARTMENTS:
                raise InvariantViolationError(f"قسم غير معروف: {department}")
            self.department = department
            changed = True
        if changed:
            self._events.append(UserPermissionsChanged(user_id=self.id))

    def deactivate(self) -> None:
        if self.status == "inactive":
            return  # idempotent
        self.status = USER_FSM.transition(self.status, "inactive")
        self._events.append(UserDeactivated(user_id=self.id))

    def reactivate(self) -> None:
        if self.status == "active":
            return
        self.status = USER_FSM.transition(self.status, "active")
        self.failed_login_attempts = 0
        self._events.append(UserReactivated(user_id=self.id))

    def lock(self, *, reason: str) -> None:
        if self.status == "locked":
            return  # idempotent
        self.status = USER_FSM.transition(self.status, "locked")
        self._events.append(UserLocked(user_id=self.id, reason=reason))

    def unlock(self) -> None:
        if self.status != "locked":
            return
        self.status = USER_FSM.transition(self.status, "active")
        self.failed_login_attempts = 0
        self._events.append(UserUnlocked(user_id=self.id))

    # ── سلوك تسجيل الدخول (يُستدعى من application service) ───
    def record_successful_login(self, *, at: str) -> None:
        """نجح تسجيل الدخول — صفّر العدّاد، سجّل الوقت. لا حدث (شأن جلسة)."""
        if not self.is_active:
            raise ConflictError("الحساب غير نشط — لا يمكن تسجيل الدخول")
        self.failed_login_attempts = 0
        self.last_login_at = at

    # ── 🔒 Security: brute-force lockout ─────────────────────
    # دفاع طبقي ضد هجمات تخمين كلمة المرور:
    #   - كل فشل يزيد العدّاد بـ 1.
    #   - عند بلوغ max_attempts (افتراضياً 5)، الـ Entity تستدعي lock()
    #     ذاتياً وتنشر UserLocked → الـ container يُسقط الجلسات.
    #   - النجاح يصفّر العدّاد (record_successful_login).
    #   - تغيير المرور (مثلاً admin reset) يصفّر العدّاد ويفكّ القفل.
    # القرار يعيش هنا في الـ Entity — لا في الـ application — ليبقى
    # تطبيق السياسة مركزياً ولا يتسرّب أي تجاوز.
    def record_failed_login(self, *, max_attempts: int = 5,
                            reason: str = "too_many_failed_attempts") -> None:
        """فشل تسجيل الدخول — زِد العدّاد، اقفل عند تجاوز الحد."""
        self.failed_login_attempts += 1
        if self.failed_login_attempts >= max_attempts and self.status == "active":
            self.lock(reason=reason)
