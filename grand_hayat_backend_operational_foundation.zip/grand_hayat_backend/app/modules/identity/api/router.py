from __future__ import annotations

import uuid
from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from pydantic import BaseModel, Field

from kernel.security.query_scoper import Actor
from modules.identity.application.service import (
    Authenticate,
    RegisterUser,
    UpdatePermissions,
    ChangePassword,
    DeactivateUser,
    ReactivateUser,
    UnlockUser,
)
from shared.api.responses import collection, success
from shared.auth.dependencies import get_current_actor, require_permission
from shared.auth.session_store import SessionStore
from shared.auth.tokens import create_access_token, create_refresh_token, decode_token
from shared.config.container import container
from shared.foundation.permissions import catalog, normalise_permissions

router = APIRouter(prefix="/identity", tags=["identity"])


class LoginBody(BaseModel):
    email: str
    password: str = Field(min_length=1, max_length=200)
    property_id: str | None = Field(default=None, max_length=80)


class RefreshBody(BaseModel):
    refresh_token: str | None = None


class LogoutBody(BaseModel):
    refresh_token: str | None = None


class UserBody(BaseModel):
    email: str
    password: str = Field(min_length=6, max_length=200)
    name: str = Field(min_length=1, max_length=80)
    role: str = "staff"
    department: str = "general"
    floors: list[int] = Field(default_factory=list)
    permissions: list[str] = Field(default_factory=list)
    request_types: list[str] = Field(default_factory=list)
    property_ids: list[str] = Field(default_factory=list)
    active_property_id: str | None = None


class PermissionsBody(BaseModel):
    permissions: list[str] | None = None
    floors: list[int] | None = None
    request_types: list[str] | None = None
    department: str | None = None


class PasswordBody(BaseModel):
    new_password: str = Field(min_length=6, max_length=200)


def _store() -> SessionStore:
    if container.db is None:
        raise HTTPException(status_code=503, detail="قاعدة البيانات غير جاهزة")
    return SessionStore(container.db)


def _request_meta(request: Request) -> dict:
    return {
        "ip": request.client.host if request.client else None,
        "user_agent": request.headers.get("user-agent"),
    }


def _user_to_dict(u) -> dict:
    return {
        "id": u.id,
        "email": u.email.value,
        "name": u.name,
        "role": u.role,
        "department": u.department,
        "floors": list(u.floors),
        "permissions": list(u.permissions),
        "request_types": list(u.request_types),
        "tenant_id": u.tenant_id,
        "property_ids": list(u.property_ids),
        "active_property_id": u.active_property_id,
        "status": u.status,
        "created_at": u.created_at,
        "last_login_at": u.last_login_at,
    }


def _auth_payload(user, access: str, access_payload: dict, refresh: str, refresh_payload: dict) -> dict:
    return {
        "token_type": "bearer",
        "access_token": access,
        "refresh_token": refresh,
        "expires_at": access_payload.get("exp"),
        "refresh_expires_at": refresh_payload.get("exp"),
        "session_id": access_payload.get("sid"),
        "user": _user_to_dict(user),
    }


@router.get("/permissions/catalog")
async def permissions_catalog(actor: Actor = Depends(require_permission("manage_permissions"))):
    return success(catalog())


@router.post("/login")
async def login(body: LoginBody, request: Request, response: Response):
    outcome = await container.identity.authenticate(Authenticate(email=str(body.email), plain_password=body.password))
    if not outcome.ok or not outcome.user:
        raise HTTPException(status_code=401, detail="بيانات الدخول غير صحيحة")
    user = outcome.user
    property_id = body.property_id or user.active_property_id
    if user.role not in {"super_admin", "admin"} and property_id not in set(user.property_ids):
        raise HTTPException(status_code=403, detail="ليست لديك صلاحية لهذا الفندق/العقار")
    sid = str(uuid.uuid4())
    access, access_payload = create_access_token(user, session_id=sid, property_id=property_id)
    refresh, refresh_payload = create_refresh_token(user, session_id=sid, property_id=property_id)
    await _store().create_session(user=user, session_id=sid, refresh_payload=refresh_payload, request_meta=_request_meta(request))
    response.set_cookie("access_token", access, httponly=True, samesite="lax")
    response.set_cookie("refresh_token", refresh, httponly=True, samesite="lax")
    return success(_auth_payload(user, access, access_payload, refresh, refresh_payload))


@router.post("/refresh")
async def refresh_session(body: RefreshBody, request: Request, response: Response):
    token = body.refresh_token or request.cookies.get("refresh_token")
    if not token:
        raise HTTPException(status_code=401, detail="refresh_token مطلوب")
    payload = decode_token(token)
    if payload.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="نوع التوكن غير صحيح")
    store = _store()
    if not await store.is_refresh_current(session_id=str(payload.get("sid")), refresh_jti=str(payload.get("jti"))):
        raise HTTPException(status_code=401, detail="الجلسة منتهية")
    user = await container.identity.get_user(str(payload.get("sub")))
    if not user or user.status != "active":
        raise HTTPException(status_code=401, detail="المستخدم غير نشط")
    await store.blacklist_jti(jti=payload.get("jti"), exp=payload.get("exp"))
    access, access_payload = create_access_token(user, session_id=str(payload.get("sid")), property_id=payload.get("property_id"))
    refresh_token, refresh_payload = create_refresh_token(user, session_id=str(payload.get("sid")), property_id=payload.get("property_id"))
    await store.rotate_refresh(session_id=str(payload.get("sid")), refresh_payload=refresh_payload)
    response.set_cookie("access_token", access, httponly=True, samesite="lax")
    response.set_cookie("refresh_token", refresh_token, httponly=True, samesite="lax")
    return success(_auth_payload(user, access, access_payload, refresh_token, refresh_payload))


@router.post("/logout")
async def logout(body: LogoutBody, request: Request, response: Response, actor: Actor = Depends(get_current_actor)):
    bearer = request.headers.get("Authorization", "")
    access_token = bearer[7:].strip() if bearer.lower().startswith("bearer ") else request.cookies.get("access_token")
    access_payload = decode_token(access_token) if access_token else {}
    refresh_payload = decode_token(body.refresh_token or request.cookies.get("refresh_token")) if (body.refresh_token or request.cookies.get("refresh_token")) else {}
    store = _store()
    await store.revoke_session(session_id=str(access_payload.get("sid") or refresh_payload.get("sid") or ""), user_id=actor.id)
    await store.blacklist_jti(jti=access_payload.get("jti"), exp=access_payload.get("exp"))
    await store.blacklist_jti(jti=refresh_payload.get("jti"), exp=refresh_payload.get("exp"))
    response.delete_cookie("access_token")
    response.delete_cookie("refresh_token")
    return success({"logged_out": True})


@router.get("/me")
async def me(actor: Actor = Depends(get_current_actor)):
    user = await container.identity.get_user(actor.id)
    return success(_user_to_dict(user))


@router.get("/sessions")
async def my_sessions(actor: Actor = Depends(require_permission("view_sessions"))):
    return collection(await _store().list_for_user(user_id=actor.id))


@router.post("/sessions/{session_id}/revoke")
async def revoke_session(session_id: str, actor: Actor = Depends(require_permission("manage_sessions"))):
    await _store().revoke_session(session_id=session_id)
    return success({"revoked": True, "session_id": session_id})


@router.get("/users")
async def list_users(actor: Actor = Depends(require_permission("manage_users"))):
    return collection([_user_to_dict(u) for u in await container.identity.list_for(actor)])


@router.post("/users", status_code=status.HTTP_201_CREATED)
async def create_user(body: UserBody, actor: Actor = Depends(require_permission("manage_users"))):
    property_ids = tuple(body.property_ids or [actor.active_property_id or "main"])
    result = await container.identity.register(RegisterUser(
        email=str(body.email),
        plain_password=body.password,
        name=body.name,
        role=body.role,
        department=body.department,
        floors=tuple(body.floors),
        permissions=normalise_permissions(body.permissions),
        request_types=tuple(body.request_types),
        actor_id=actor.id,
        tenant_id=actor.tenant_id or "default",
        property_ids=property_ids,
        active_property_id=body.active_property_id or actor.active_property_id or "main",
    ))
    return success(_user_to_dict(result.data))


@router.patch("/users/{user_id}/permissions")
async def update_permissions(user_id: str, body: PermissionsBody, actor: Actor = Depends(require_permission("manage_permissions"))):
    result = await container.identity.update_permissions(UpdatePermissions(
        user_id=user_id,
        permissions=normalise_permissions(body.permissions) if body.permissions is not None else None,
        floors=tuple(body.floors) if body.floors is not None else None,
        request_types=tuple(body.request_types) if body.request_types is not None else None,
        department=body.department,
        actor_id=actor.id,
    ))
    return success(_user_to_dict(result.data))


@router.patch("/users/{user_id}/password")
async def reset_password(user_id: str, body: PasswordBody, actor: Actor = Depends(require_permission("manage_users"))):
    result = await container.identity.change_password(ChangePassword(user_id=user_id, new_plain_password=body.new_password, actor_id=actor.id, is_admin_reset=True))
    await _store().revoke_user_sessions(user_id=user_id)
    return success(_user_to_dict(result.data))


@router.post("/users/{user_id}/deactivate")
async def deactivate_user(user_id: str, actor: Actor = Depends(require_permission("manage_users"))):
    result = await container.identity.deactivate(DeactivateUser(user_id=user_id, actor_id=actor.id))
    await _store().revoke_user_sessions(user_id=user_id)
    return success(_user_to_dict(result.data))


@router.post("/users/{user_id}/reactivate")
async def reactivate_user(user_id: str, actor: Actor = Depends(require_permission("manage_users"))):
    result = await container.identity.reactivate(ReactivateUser(user_id=user_id, actor_id=actor.id))
    return success(_user_to_dict(result.data))


@router.post("/users/{user_id}/unlock")
async def unlock_user(user_id: str, actor: Actor = Depends(require_permission("manage_users"))):
    result = await container.identity.unlock(UnlockUser(user_id=user_id, actor_id=actor.id))
    return success(_user_to_dict(result.data))
