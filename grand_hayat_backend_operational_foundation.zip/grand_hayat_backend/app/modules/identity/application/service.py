"""
modules.identity.application.service — منظّم الهوية والمصادقة
═══════════════════════════════════════════════════════════════════

Orchestrator نظيف لكل عمليات حساب المستخدم.

نقاط معمارية حرجة:

① bcrypt مغيَّب تماماً من الـ application — يعمل عبر PasswordHasherPort
   المحقون (المجال يُعرّفه، infrastructure يُنفّذه).

② JWT/الجلسات ليست مسؤولية هنا. الـ application يُرجع LoginOutcome
   (نجاح + كيان المستخدم، أو سبب الفشل). إصدار التوكن يحدث في الـ API
   layer التي تستهلك النتيجة. هذا يحفظ المجال نقياً من البروتوكولات.

③ سياسة المحاولات الفاشلة:
   - فشل التحقّق من المرور → entity.record_failed_login (يقفل عند 5)
   - نجاح → entity.record_successful_login (يصفّر العدّاد)
   - الـ Entity هي من تقرّر القفل، نحن نحفظ النتيجة فقط.

④ كل تعديل ينشر الأحداث الصحيحة تلقائياً (يأتي من entity.pull_events).
"""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from enum import Enum

from kernel.bus import EventBus
from kernel.clock import now_iso
from kernel.contracts import Command, Result
from kernel.errors import ConflictError, NotFoundError, PermissionDeniedError
from kernel.text import sanitize

from modules.identity.domain.models import (
    EmailAddress,
    PasswordHash,
    PasswordHasherPort,
    UserEntity,
    VALID_DEPARTMENTS,
    VALID_ROLES,
)
from modules.identity.domain.repository import UserRepository
from shared.foundation.permissions import normalise_permissions

logger = logging.getLogger("grandhayat.identity")

MAX_FAILED_LOGIN_ATTEMPTS = 5


# ══════════════════════════════════════════════════════════════
# Commands — نوايا تُنشأ في الـ API Layer
# ══════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class RegisterUser(Command):
    email: str
    plain_password: str
    name: str
    role: str = "staff"
    department: str = "general"
    floors: tuple[int, ...] = field(default_factory=tuple)
    permissions: tuple[str, ...] = field(default_factory=tuple)
    request_types: tuple[str, ...] = field(default_factory=tuple)
    actor_id: str = ""           # المسؤول الذي ينشئ المستخدم
    tenant_id: str = "default"
    property_ids: tuple[str, ...] = ("main",)
    active_property_id: str = "main"


@dataclass(frozen=True)
class ChangePassword(Command):
    """تغيير كلمة المرور (للمستخدم نفسه أو للمدير)."""
    user_id: str
    new_plain_password: str
    actor_id: str
    is_admin_reset: bool = False  # المدير يعيد ضبط بدون التحقّق من القديمة


@dataclass(frozen=True)
class ChangeRole(Command):
    user_id: str
    new_role: str
    actor_id: str


@dataclass(frozen=True)
class UpdatePermissions(Command):
    user_id: str
    permissions: tuple[str, ...] | None
    floors: tuple[int, ...] | None
    request_types: tuple[str, ...] | None
    department: str | None
    actor_id: str


@dataclass(frozen=True)
class DeactivateUser(Command):
    user_id: str
    actor_id: str


@dataclass(frozen=True)
class ReactivateUser(Command):
    user_id: str
    actor_id: str


@dataclass(frozen=True)
class UnlockUser(Command):
    user_id: str
    actor_id: str


@dataclass(frozen=True)
class Authenticate(Command):
    """محاولة تسجيل دخول. الـ application لا يُصدر JWT — يُرجع النتيجة فقط."""
    email: str
    plain_password: str


# ══════════════════════════════════════════════════════════════
# Login outcome — نتيجة الـ Authenticate (تُترجم لاحقاً إلى JWT في الـ API)
# ══════════════════════════════════════════════════════════════
class LoginFailReason(str, Enum):
    UNKNOWN_USER = "unknown_user"
    WRONG_PASSWORD = "wrong_password"
    INACTIVE_USER = "inactive_user"
    LOCKED_USER = "locked_user"


@dataclass(frozen=True)
class LoginOutcome:
    ok: bool
    user: UserEntity | None = None
    failure_reason: LoginFailReason | None = None


# ══════════════════════════════════════════════════════════════
# Application Service (Orchestrator)
# ══════════════════════════════════════════════════════════════
class IdentityApplicationService:
    # ── 🔌 Dependency Inversion: Ports فقط ───────────────────
    # هذا الـ constructor يستقبل واجهات مجرّدة حصراً (UserRepository
    # Protocol + PasswordHasherPort Protocol). لا يعرف bcrypt ولا motor
    # ولا أي concrete adapter — التنفيذ يُحقَن من الـ composition root.
    # هذا يحفظ الـ application قابلاً للاختبار (fake hasher / fake repo)
    # ويسمح بترقية خوارزمية التشفير أو محرّك التخزين بلا لمس هذا الملف.
    def __init__(self, *, users: UserRepository, uow_factory,
                 bus: EventBus, hasher: PasswordHasherPort) -> None:
        self._users = users
        self._uow_factory = uow_factory
        self._bus = bus
        self._hasher = hasher

    # ── إدارة الحسابات ───────────────────────────────────────
    async def register(self, cmd: RegisterUser) -> Result:
        email = EmailAddress(cmd.email)
        # تفرّد البريد (الـ DB index يفرضه أيضاً، لكن نتحقّق مبكّراً لرسالة أوضح)
        existing = await self._users.get_by_email(email.value)
        if existing:
            raise ConflictError("البريد الإلكتروني مستخدم بالفعل")

        # الـ hasher في الـ port — لا bcrypt مباشر
        hashed = self._hasher.hash(cmd.plain_password)
        now = now_iso()
        entity = UserEntity(
            id=str(uuid.uuid4()),
            email=email,
            name=sanitize(cmd.name, 80) or "",
            password_hash=hashed,
            role=cmd.role,
            department=cmd.department,
            floors=tuple(int(f) for f in (cmd.floors or ())),
            permissions=normalise_permissions(cmd.permissions),
            request_types=tuple(cmd.request_types or ()),
            tenant_id=cmd.tenant_id,
            property_ids=tuple(cmd.property_ids or (cmd.active_property_id or "main",)),
            active_property_id=cmd.active_property_id or "main",
            password_changed_at=now,
            created_at=now,
        )
        entity.register()  # يفحص invariants + ينشر UserCreated

        async with self._uow_factory() as uow:
            await self._users.add(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)

    # ── 🔒 Security: change_password ─────────────────────────
    # تغيير المرور حدث أمني حسّاس:
    #   - الـ Entity تُحدّث password_changed_at → يُبطل كل JWT أُصدر قبله
    #     (يلتقطها deps.get_current_user عبر مقارنة token.iat مع هذا الحقل).
    #   - تُنشَر UserPasswordChanged → subscriber في الـ container يحذف
    #     الجلسات النشطة (revoke_sessions).
    #   - is_admin_reset=False يمنع تغيير مرور غير الذات (دفاع ضد امتيازات).
    async def change_password(self, cmd: ChangePassword) -> Result:
        entity = await self._get_or_404(cmd.user_id)
        if not cmd.is_admin_reset and cmd.actor_id != entity.id:
            # تغيير بلا is_admin_reset لمستخدم آخر = ممنوع
            raise PermissionDeniedError("لا يمكن تغيير كلمة مرور مستخدم آخر")
        new_hash = self._hasher.hash(cmd.new_plain_password)
        entity.change_password(new_hash, at=now_iso())
        return await self._persist(entity)

    async def change_role(self, cmd: ChangeRole) -> Result:
        if cmd.new_role not in VALID_ROLES:
            from kernel.errors import ValidationError
            raise ValidationError(f"دور غير معروف: {cmd.new_role}")
        entity = await self._get_or_404(cmd.user_id)
        entity.change_role(cmd.new_role)
        return await self._persist(entity)

    async def update_permissions(self, cmd: UpdatePermissions) -> Result:
        entity = await self._get_or_404(cmd.user_id)
        if cmd.department is not None and cmd.department not in VALID_DEPARTMENTS:
            from kernel.errors import ValidationError
            raise ValidationError(f"قسم غير معروف: {cmd.department}")
        entity.update_permissions(
            permissions=cmd.permissions,
            floors=tuple(int(f) for f in cmd.floors) if cmd.floors is not None else None,
            request_types=cmd.request_types,
            department=cmd.department,
        )
        return await self._persist(entity)

    async def deactivate(self, cmd: DeactivateUser) -> Result:
        entity = await self._get_or_404(cmd.user_id)
        entity.deactivate()
        return await self._persist(entity)

    async def reactivate(self, cmd: ReactivateUser) -> Result:
        entity = await self._get_or_404(cmd.user_id)
        entity.reactivate()
        return await self._persist(entity)

    async def unlock(self, cmd: UnlockUser) -> Result:
        entity = await self._get_or_404(cmd.user_id)
        entity.unlock()
        return await self._persist(entity)

    # ── 🔒 Security: authenticate ────────────────────────────
    # تسجيل الدخول — نقطة هجوم رئيسية، عدّة دفاعات مكدّسة:
    #
    #   1. Timing attack mitigation: حين لا يوجد المستخدم، نشغّل
    #      hasher.verify على هاش وهمي لإبقاء زمن الردّ ثابتاً تقريباً
    #      — حتى لا يتمكّن المهاجم من تعداد البُرد الصالحة عبر الوقت.
    #
    #   2. فحص حالة الحساب قبل المرور: locked / inactive يُرفضان فوراً
    #      دون فحص المرور — لا نكشف ما إذا كان المرور صحيحاً لحساب مقفول.
    #
    #   3. Brute-force lockout: كل فشل يستدعي record_failed_login،
    #      والـ Entity هي من تقرّر القفل عند MAX_FAILED_LOGIN_ATTEMPTS.
    #
    #   4. لا JWT هنا: نُرجع LoginOutcome فقط — إصدار التوكن مسؤولية
    #      الـ API layer (يفصل المنطق المجالي عن بروتوكول الجلسات).
    async def authenticate(self, cmd: Authenticate) -> LoginOutcome:
        """يتحقّق من المرور ويُرجع النتيجة. لا يُصدر JWT (مسؤولية الـ API)."""
        try:
            normalised = EmailAddress(cmd.email).value
        except Exception:
            return LoginOutcome(ok=False, failure_reason=LoginFailReason.UNKNOWN_USER)

        entity = await self._users.get_by_email(normalised)
        if not entity:
            # نُشغّل verify على هاش وهمي للحفاظ على وقت ثابت تقريباً
            self._hasher.verify(cmd.plain_password, PasswordHash("$dummy$hash$"))
            return LoginOutcome(ok=False, failure_reason=LoginFailReason.UNKNOWN_USER)

        # حالة الحساب أولاً (قبل التحقّق من المرور — لا فائدة من فحصه إن كان مقفولاً)
        if entity.status == "locked":
            return LoginOutcome(ok=False, user=entity, failure_reason=LoginFailReason.LOCKED_USER)
        if entity.status == "inactive":
            return LoginOutcome(ok=False, user=entity, failure_reason=LoginFailReason.INACTIVE_USER)

        if not self._hasher.verify(cmd.plain_password, entity.password_hash):
            # محاولة فاشلة → الـ Entity تقرّر القفل عند الحد
            entity.record_failed_login(max_attempts=MAX_FAILED_LOGIN_ATTEMPTS)
            await self._persist(entity)
            return LoginOutcome(ok=False, user=entity, failure_reason=LoginFailReason.WRONG_PASSWORD)

        # نجاح
        entity.record_successful_login(at=now_iso())
        await self._persist(entity)
        return LoginOutcome(ok=True, user=entity)

    async def get_user(self, user_id: str) -> UserEntity | None:
        """Read one user for auth composition without exposing repositories."""
        return await self._users.get(user_id)

    async def list_for(self, actor, *, limit: int = 200) -> list[UserEntity]:
        users = await self._users.list_all(limit=limit)
        if getattr(actor, "role", "") == "super_admin":
            return users
        tenant_id = actor.tenant_id or "default"
        property_id = actor.active_property_id or "main"
        return [u for u in users if u.tenant_id == tenant_id and (property_id in u.property_ids or u.active_property_id == property_id)]

    # ── أدوات داخلية ─────────────────────────────────────────
    async def _get_or_404(self, user_id: str) -> UserEntity:
        entity = await self._users.get(user_id)
        if not entity:
            raise NotFoundError("المستخدم غير موجود")
        return entity

    async def _persist(self, entity: UserEntity) -> Result:
        async with self._uow_factory() as uow:
            await self._users.save(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)
