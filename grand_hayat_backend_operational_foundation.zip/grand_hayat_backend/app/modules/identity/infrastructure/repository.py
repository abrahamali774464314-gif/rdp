"""
modules.identity.infrastructure.repository — التخزين + تشفير كلمات المرور
═══════════════════════════════════════════════════════════════════

هذا الملف هو المكان **الوحيد** في النظام المسموح فيه بـ:
  - bcrypt (تشفير/تحقّق كلمات المرور)
  - motor (تخزين المستخدمين)

مسؤوليتان (مجمّعتان للحفاظ على نمط الـ 5 ملفات):
  ① MongoUserRepository : حفظ/جلب الكيانات + تطبيع البريد + تفرّده
  ② BcryptPasswordHasher: ينفّذ PasswordHasherPort

ملاحظتان أمنيتان:
  - تفرّد البريد: يجب وجود فهرس فريد على db.users.email في seed.py
    (موجود في النظام القديم). نتحقّق منه في الـ application أيضاً.
  - bcrypt كسول الاستيراد: لا يُحمَّل عند الاستيراد العادي — يسهّل
    اختبار باقي الطبقات بدونه ويبقي العقد المعماري واضحاً.
"""
from __future__ import annotations

import logging

from kernel.persistence import session_kwargs
from modules.identity.domain.models import (
    EmailAddress,
    PasswordHash,
    PasswordHasherPort,
    UserEntity,
)
from modules.identity.domain.repository import UserRepository

logger = logging.getLogger("grandhayat.identity.infra")

COLLECTION = "users"


# ══════════════════════════════════════════════════════════════
# ① Mongo Repository
# ══════════════════════════════════════════════════════════════
class MongoUserRepository(UserRepository):
    def __init__(self, db) -> None:
        self._col = db[COLLECTION]

    # ── Mappers ───────────────────────────────────────────────
    @staticmethod
    def _to_entity(doc: dict) -> UserEntity:
        return UserEntity(
            id=doc["id"],
            email=EmailAddress(doc["email"]),
            name=doc.get("name", ""),
            password_hash=PasswordHash(doc["password_hash"]),
            role=doc.get("role", "staff"),
            department=doc.get("department", "general"),
            floors=tuple(int(f) for f in (doc.get("floors") or ())),
            permissions=tuple(doc.get("permissions") or ()),
            request_types=tuple(doc.get("request_types") or ()),
            tenant_id=doc.get("tenant_id", "default"),
            property_ids=tuple(str(x) for x in (doc.get("property_ids") or doc.get("properties") or (doc.get("property_id", "main"),))),
            active_property_id=doc.get("active_property_id") or doc.get("property_id") or "main",
            status=doc.get("status", "active"),
            password_changed_at=doc.get("password_changed_at", ""),
            failed_login_attempts=int(doc.get("failed_login_attempts", 0)),
            last_login_at=doc.get("last_login_at", ""),
            created_at=doc.get("created_at", ""),
        )

    @staticmethod
    def _to_document(e: UserEntity) -> dict:
        return {
            "id": e.id,
            "email": e.email.value,
            "name": e.name,
            "password_hash": e.password_hash.encoded,
            "role": e.role,
            "department": e.department,
            "floors": list(e.floors),
            "permissions": list(e.permissions),
            "request_types": list(e.request_types),
            "tenant_id": e.tenant_id,
            "property_ids": list(e.property_ids),
            "active_property_id": e.active_property_id,
            "status": e.status,
            "password_changed_at": e.password_changed_at,
            "failed_login_attempts": e.failed_login_attempts,
            "last_login_at": e.last_login_at,
            "created_at": e.created_at,
        }

    # ── Operations ────────────────────────────────────────────
    async def get(self, user_id: str) -> UserEntity | None:
        doc = await self._col.find_one({"id": user_id}, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def get_by_email(self, email: str) -> UserEntity | None:
        normalised = (email or "").strip().lower()
        if not normalised:
            return None
        doc = await self._col.find_one({"email": normalised}, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def add(self, user: UserEntity, uow=None) -> UserEntity:
        await self._col.insert_one(self._to_document(user), **session_kwargs(uow))
        return user

    async def save(self, user: UserEntity, uow=None) -> UserEntity:
        await self._col.update_one(
            {"id": user.id},
            {"$set": self._to_document(user)},
            **session_kwargs(uow),
        )
        return user

    async def list_all(self, *, limit: int = 200) -> list[UserEntity]:
        limit = max(1, min(int(limit), 1000))
        docs = await self._col.find({}, {"_id": 0}).to_list(limit)
        return [self._to_entity(d) for d in docs]

    async def has_any_admin(self) -> bool:
        doc = await self._col.find_one({"role": "admin"}, {"_id": 1})
        return doc is not None


# ══════════════════════════════════════════════════════════════
# ② BcryptPasswordHasher — ينفّذ PasswordHasherPort
# ══════════════════════════════════════════════════════════════
class BcryptPasswordHasher(PasswordHasherPort):
    """تشفير bcrypt. المكان الوحيد في النظام المسموح فيه استيراد bcrypt."""

    def hash(self, plain: str) -> PasswordHash:
        # استيراد كسول — يحدث عند الاستخدام الفعلي فقط
        import bcrypt
        encoded = bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
        return PasswordHash(encoded)

    def verify(self, plain: str, hashed: PasswordHash) -> bool:
        import bcrypt
        try:
            return bcrypt.checkpw(plain.encode("utf-8"), hashed.encoded.encode("utf-8"))
        except Exception as exc:  # noqa: BLE001 — أي خطأ في الـ encoding = فشل تحقّق
            logger.debug("bcrypt verify error: %s", exc)
            return False
