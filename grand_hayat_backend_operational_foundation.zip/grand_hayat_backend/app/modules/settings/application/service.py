from __future__ import annotations
from dataclasses import dataclass
from kernel.bus import EventBus
from kernel.clock import now_iso
from kernel.contracts import Command, Result
from kernel.text import sanitize
from modules.settings.domain.models import SettingEntity
from modules.settings.domain.repository import SettingRepository

@dataclass(frozen=True)
class PutSetting(Command):
    tenant_id: str
    property_id: str
    module: str
    key: str
    value: dict
    actor_id: str

class SettingApplicationService:
    def __init__(self, *, settings: SettingRepository, uow_factory, bus: EventBus) -> None:
        self._settings = settings
        self._uow_factory = uow_factory
        self._bus = bus

    def _scope(self, actor, base: dict | None = None) -> dict:
        q = dict(base or {})
        if getattr(actor, "role", "") != "super_admin":
            q["tenant_id"] = actor.tenant_id or "default"
            q["property_id"] = actor.active_property_id or "main"
        return q

    async def list_for(self, actor, *, base_query: dict | None = None, limit: int = 300):
        return await self._settings.list_scoped(self._scope(actor, base_query), limit=limit)

    async def get_value(self, *, tenant_id: str, property_id: str, module: str, key: str) -> dict:
        entity = await self._settings.get(tenant_id=tenant_id, property_id=property_id, module=module, key=key)
        return dict(entity.value) if entity else {}

    async def put(self, cmd: PutSetting) -> Result:
        module = sanitize(cmd.module, 80) or "pms"
        key = sanitize(cmd.key, 120) or "default"
        entity = await self._settings.get(tenant_id=cmd.tenant_id, property_id=cmd.property_id, module=module, key=key)
        if entity is None:
            entity = SettingEntity(tenant_id=cmd.tenant_id, property_id=cmd.property_id, module=module, key=key, value={})
        entity.put(value=cmd.value or {}, updated_by=cmd.actor_id, updated_at=now_iso())
        async with self._uow_factory() as uow:
            await self._settings.save(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)
