from __future__ import annotations
from dataclasses import dataclass, field
from kernel.contracts import DomainEvent, Entity
from kernel.errors import InvariantViolationError
from modules.settings.domain.events import SettingUpdated

@dataclass
class SettingEntity(Entity):
    tenant_id: str
    property_id: str
    module: str
    key: str
    value: dict = field(default_factory=dict)
    updated_by: str = ""
    updated_at: str = ""
    version: int = 1
    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    @property
    def id(self) -> str:  # type: ignore[override]
        return f"{self.tenant_id}:{self.property_id}:{self.module}:{self.key}"

    def pull_events(self) -> list[DomainEvent]:
        ev, self._events = self._events, []
        return ev

    def _check(self) -> None:
        if not self.tenant_id or not self.property_id or not self.module or not self.key:
            raise InvariantViolationError("tenant_id/property_id/module/key مطلوبة")
        if not isinstance(self.value, dict):
            raise InvariantViolationError("قيمة الإعداد يجب أن تكون object")

    def put(self, *, value: dict, updated_by: str, updated_at: str) -> None:
        self.value = dict(value or {})
        self.updated_by = updated_by
        self.updated_at = updated_at
        self.version = max(1, int(self.version or 1)) + 1
        self._check()
        self._events.append(SettingUpdated(tenant_id=self.tenant_id, property_id=self.property_id, module=self.module, key=self.key))
