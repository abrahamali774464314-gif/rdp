from __future__ import annotations
from dataclasses import dataclass
from kernel.contracts import DomainEvent

@dataclass(frozen=True)
class SettingUpdated(DomainEvent):
    tenant_id: str
    property_id: str
    module: str
    key: str
    topic = "settings.updated"
