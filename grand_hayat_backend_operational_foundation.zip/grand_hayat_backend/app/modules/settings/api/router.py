from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field

from kernel.security.query_scoper import Actor
from modules.settings.application.service import PutSetting
from shared.api.responses import collection, success
from shared.auth.dependencies import require_permission
from shared.config.container import container
from shared.foundation.constants import SETTING_MODULES
from shared.foundation.permissions import DEFAULT_SOUND_RULES, SOUND_EVENT_LABELS, catalog

router = APIRouter(prefix="/settings", tags=["settings"])


class SettingBody(BaseModel):
    value: dict = Field(default_factory=dict)


class SoundRulesBody(BaseModel):
    rules: dict = Field(default_factory=dict)


def _setting_to_dict(s) -> dict:
    return {
        "id": s.id,
        "tenant_id": s.tenant_id,
        "property_id": s.property_id,
        "module": s.module,
        "key": s.key,
        "value": s.value,
        "updated_by": s.updated_by,
        "updated_at": s.updated_at,
        "version": s.version,
    }


@router.get("/catalog")
async def settings_catalog(actor: Actor = Depends(require_permission("view_settings"))):
    return success({"modules": sorted(SETTING_MODULES), "permissions": catalog()})


@router.get("/sounds/events")
async def sound_events(actor: Actor = Depends(require_permission("view_sounds"))):
    return success({"events": [{"key": k, "label": v} for k, v in SOUND_EVENT_LABELS.items()]})


@router.get("/sounds/rules")
async def get_sound_rules(actor: Actor = Depends(require_permission("view_sounds"))):
    current = await container.settings.get_value(
        tenant_id=actor.tenant_id or "default",
        property_id=actor.active_property_id or "main",
        module="sounds",
        key="rules",
    )
    return success({"rules": {**DEFAULT_SOUND_RULES, **current}})


@router.put("/sounds/rules")
async def put_sound_rules(body: SoundRulesBody, actor: Actor = Depends(require_permission("manage_sounds"))):
    result = await container.settings.put(PutSetting(
        tenant_id=actor.tenant_id or "default",
        property_id=actor.active_property_id or "main",
        module="sounds",
        key="rules",
        value={**DEFAULT_SOUND_RULES, **body.rules},
        actor_id=actor.id,
    ))
    return success(_setting_to_dict(result.data))


@router.get("")
async def list_settings(module: str | None = Query(default=None), actor: Actor = Depends(require_permission("view_settings"))):
    base = {"module": module} if module else None
    return collection([_setting_to_dict(s) for s in await container.settings.list_for(actor, base_query=base)])


@router.put("/{module}/{key}")
async def put_setting(module: str, key: str, body: SettingBody, actor: Actor = Depends(require_permission("manage_settings"))):
    result = await container.settings.put(PutSetting(
        tenant_id=actor.tenant_id or "default",
        property_id=actor.active_property_id or "main",
        module=module,
        key=key,
        value=body.value,
        actor_id=actor.id,
    ))
    return success(_setting_to_dict(result.data))
