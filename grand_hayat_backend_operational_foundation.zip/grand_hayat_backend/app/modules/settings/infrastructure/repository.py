from __future__ import annotations
from kernel.persistence import session_kwargs
from modules.settings.domain.models import SettingEntity
from modules.settings.domain.repository import SettingRepository

class MongoSettingRepository(SettingRepository):
    def __init__(self, db) -> None:
        self._col = db["settings"]

    @staticmethod
    def _to_entity(doc: dict) -> SettingEntity:
        return SettingEntity(
            tenant_id=doc.get("tenant_id", "default"), property_id=doc.get("property_id", "main"),
            module=doc.get("module", "pms"), key=doc.get("key", "default"),
            value=doc.get("value") or {}, updated_by=doc.get("updated_by", ""),
            updated_at=doc.get("updated_at", ""), version=int(doc.get("version", 1)),
        )

    @staticmethod
    def _to_doc(e: SettingEntity) -> dict:
        return {"id": e.id, "tenant_id": e.tenant_id, "property_id": e.property_id, "module": e.module, "key": e.key, "value": dict(e.value or {}), "updated_by": e.updated_by, "updated_at": e.updated_at, "version": e.version}

    async def get(self, *, tenant_id: str, property_id: str, module: str, key: str) -> SettingEntity | None:
        doc = await self._col.find_one({"tenant_id": tenant_id, "property_id": property_id, "module": module, "key": key}, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def save(self, setting: SettingEntity, uow=None) -> SettingEntity:
        await self._col.update_one({"id": setting.id}, {"$set": self._to_doc(setting)}, upsert=True, **session_kwargs(uow))
        return setting

    async def list_scoped(self, scoped_filter: dict, *, limit: int = 300) -> list[SettingEntity]:
        limit = max(1, min(int(limit), 1000))
        docs = await self._col.find(scoped_filter or {}, {"_id": 0}).sort([("module", 1), ("key", 1)]).to_list(limit)
        return [self._to_entity(d) for d in docs]
