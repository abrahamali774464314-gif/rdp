from __future__ import annotations
from dataclasses import dataclass
from kernel.contracts import DomainEvent

@dataclass(frozen=True)
class ReservationCreated(DomainEvent):
    reservation_id: str
    tenant_id: str
    property_id: str
    room_number: int | None
    topic = "reservations.created"

@dataclass(frozen=True)
class ReservationConfirmed(DomainEvent):
    reservation_id: str
    tenant_id: str
    property_id: str
    topic = "reservations.confirmed"

@dataclass(frozen=True)
class ReservationCancelled(DomainEvent):
    reservation_id: str
    tenant_id: str
    property_id: str
    topic = "reservations.cancelled"

@dataclass(frozen=True)
class ReservationCheckedIn(DomainEvent):
    reservation_id: str
    checkin_id: str
    tenant_id: str
    property_id: str
    topic = "reservations.checked_in"
