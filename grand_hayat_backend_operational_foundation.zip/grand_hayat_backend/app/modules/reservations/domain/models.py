from __future__ import annotations
from dataclasses import dataclass, field
from kernel.contracts import DomainEvent, Entity
from kernel.errors import ConflictError, InvariantViolationError
from kernel.state_machine import StateMachine
from modules.reservations.domain.events import ReservationCancelled, ReservationCheckedIn, ReservationConfirmed, ReservationCreated

RESERVATION_FSM = StateMachine(
    name="reservation",
    transitions={
        "draft": {"confirmed", "cancelled"},
        "confirmed": {"checked_in", "cancelled", "no_show"},
        "checked_in": set(),
        "cancelled": set(),
        "no_show": set(),
    },
    terminal=frozenset({"checked_in", "cancelled", "no_show"}),
)

@dataclass
class ReservationEntity(Entity):
    id: str
    tenant_id: str
    property_id: str
    guest_id: str
    arrival_date: str
    departure_date: str
    room_number: int | None = None
    floor: int | None = None
    adults: int = 1
    children: int = 0
    source: str = "walk_in"
    status: str = "draft"
    note: str = ""
    created_by: str = ""
    created_at: str = ""
    updated_at: str = ""
    checkin_id: str | None = None
    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    def pull_events(self) -> list[DomainEvent]:
        ev, self._events = self._events, []
        return ev

    def _check(self) -> None:
        if not self.tenant_id or not self.property_id:
            raise InvariantViolationError("tenant_id/property_id مطلوبان")
        if not self.guest_id:
            raise InvariantViolationError("guest_id مطلوب للحجز")
        if not self.arrival_date or not self.departure_date:
            raise InvariantViolationError("تواريخ الحجز مطلوبة")
        if self.departure_date <= self.arrival_date:
            raise InvariantViolationError("تاريخ المغادرة يجب أن يكون بعد الوصول")
        if self.adults < 1 or self.children < 0:
            raise InvariantViolationError("عدد النزلاء غير صحيح")

    def create(self) -> None:
        self._check()
        self._events.append(ReservationCreated(reservation_id=self.id, tenant_id=self.tenant_id, property_id=self.property_id, room_number=self.room_number))

    def confirm(self) -> None:
        self.status = RESERVATION_FSM.transition(self.status, "confirmed")
        self._events.append(ReservationConfirmed(reservation_id=self.id, tenant_id=self.tenant_id, property_id=self.property_id))

    def cancel(self) -> None:
        self.status = RESERVATION_FSM.transition(self.status, "cancelled")
        self._events.append(ReservationCancelled(reservation_id=self.id, tenant_id=self.tenant_id, property_id=self.property_id))

    def mark_checked_in(self, checkin_id: str) -> None:
        if not checkin_id:
            raise ConflictError("checkin_id مطلوب")
        self.status = RESERVATION_FSM.transition(self.status, "checked_in")
        self.checkin_id = checkin_id
        self._events.append(ReservationCheckedIn(reservation_id=self.id, checkin_id=checkin_id, tenant_id=self.tenant_id, property_id=self.property_id))
