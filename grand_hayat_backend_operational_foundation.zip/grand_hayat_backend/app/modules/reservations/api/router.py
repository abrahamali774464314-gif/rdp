from __future__ import annotations
from fastapi import APIRouter, Depends, Query, status
from pydantic import BaseModel, Field
from kernel.security.query_scoper import Actor
from modules.reservations.application.service import CancelReservation, ConfirmReservation, CreateReservation, MarkReservationCheckedIn
from shared.auth.dependencies import require_permission
from shared.config.container import container

router = APIRouter(prefix="/reservations", tags=["reservations"])

class ReservationBody(BaseModel):
    guest_id: str = Field(min_length=1)
    arrival_date: str = Field(min_length=1)
    departure_date: str = Field(min_length=1)
    room_number: int | None = None
    floor: int | None = None
    adults: int = 1
    children: int = 0
    source: str = "walk_in"
    note: str = ""

class ReservationCheckinBody(BaseModel):
    checkin_id: str = Field(min_length=1)

def _reservation_to_dict(r) -> dict:
    return {"id": r.id, "guest_id": r.guest_id, "room_number": r.room_number, "floor": r.floor, "arrival_date": r.arrival_date, "departure_date": r.departure_date, "status": r.status, "source": r.source, "adults": r.adults, "children": r.children, "note": r.note, "checkin_id": r.checkin_id, "tenant_id": r.tenant_id, "property_id": r.property_id}

@router.get("")
async def list_reservations(status: str | None = Query(default=None), actor: Actor = Depends(require_permission("view_reservations"))):
    base = {"status": status} if status else None
    return [_reservation_to_dict(r) for r in await container.reservations.list_for(actor, base_query=base)]

@router.post("", status_code=status.HTTP_201_CREATED)
async def create_reservation(body: ReservationBody, actor: Actor = Depends(require_permission("manage_reservations"))):
    result = await container.reservations.create(CreateReservation(tenant_id=actor.tenant_id or "default", property_id=actor.active_property_id or "main", actor_id=actor.id, **body.model_dump()))
    return _reservation_to_dict(result.data)

@router.post("/{reservation_id}/confirm")
async def confirm_reservation(reservation_id: str, actor: Actor = Depends(require_permission("manage_reservations"))):
    result = await container.reservations.confirm(ConfirmReservation(reservation_id=reservation_id, tenant_id=actor.tenant_id or "default", property_id=actor.active_property_id or "main"))
    return _reservation_to_dict(result.data)

@router.post("/{reservation_id}/cancel")
async def cancel_reservation(reservation_id: str, actor: Actor = Depends(require_permission("manage_reservations"))):
    result = await container.reservations.cancel(CancelReservation(reservation_id=reservation_id, tenant_id=actor.tenant_id or "default", property_id=actor.active_property_id or "main"))
    return _reservation_to_dict(result.data)

@router.post("/{reservation_id}/checked-in")
async def mark_reservation_checked_in(reservation_id: str, body: ReservationCheckinBody, actor: Actor = Depends(require_permission("manage_reservations"))):
    result = await container.reservations.mark_checked_in(MarkReservationCheckedIn(reservation_id=reservation_id, checkin_id=body.checkin_id, tenant_id=actor.tenant_id or "default", property_id=actor.active_property_id or "main"))
    return _reservation_to_dict(result.data)
