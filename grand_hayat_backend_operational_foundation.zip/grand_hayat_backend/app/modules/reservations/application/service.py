from __future__ import annotations
import uuid
from dataclasses import dataclass
from kernel.bus import EventBus
from kernel.clock import now_iso
from kernel.contracts import Command, Result
from kernel.errors import ConflictError, NotFoundError
from kernel.text import sanitize
from modules.reservations.domain.models import ReservationEntity
from modules.reservations.domain.repository import ReservationRepository

@dataclass(frozen=True)
class CreateReservation(Command):
    guest_id: str
    arrival_date: str
    departure_date: str
    tenant_id: str = "default"
    property_id: str = "main"
    room_number: int | None = None
    floor: int | None = None
    adults: int = 1
    children: int = 0
    source: str = "walk_in"
    note: str = ""
    actor_id: str = ""

@dataclass(frozen=True)
class ConfirmReservation(Command):
    reservation_id: str
    tenant_id: str
    property_id: str

@dataclass(frozen=True)
class CancelReservation(Command):
    reservation_id: str
    tenant_id: str
    property_id: str

@dataclass(frozen=True)
class MarkReservationCheckedIn(Command):
    reservation_id: str
    checkin_id: str
    tenant_id: str
    property_id: str

class ReservationApplicationService:
    def __init__(self, *, reservations: ReservationRepository, uow_factory, bus: EventBus) -> None:
        self._reservations = reservations
        self._uow_factory = uow_factory
        self._bus = bus

    def _scope(self, actor, base: dict | None = None) -> dict:
        q = dict(base or {})
        if getattr(actor, "role", "") != "super_admin":
            q["tenant_id"] = actor.tenant_id or "default"
            q["property_id"] = actor.active_property_id or "main"
        return q

    async def list_for(self, actor, *, base_query: dict | None = None, limit: int = 300):
        return await self._reservations.list_scoped(self._scope(actor, base_query), limit=limit)

    async def create(self, cmd: CreateReservation) -> Result:
        if cmd.room_number is not None:
            overlap = await self._reservations.find_overlap(tenant_id=cmd.tenant_id, property_id=cmd.property_id, room_number=cmd.room_number, arrival_date=cmd.arrival_date, departure_date=cmd.departure_date)
            if overlap:
                raise ConflictError("يوجد حجز متداخل لهذه الغرفة")
        entity = ReservationEntity(
            id=str(uuid.uuid4()), tenant_id=cmd.tenant_id, property_id=cmd.property_id,
            guest_id=cmd.guest_id, room_number=cmd.room_number, floor=cmd.floor,
            arrival_date=cmd.arrival_date, departure_date=cmd.departure_date,
            adults=cmd.adults, children=cmd.children, source=sanitize(cmd.source, 80) or "walk_in",
            note=sanitize(cmd.note, 1000) or "", created_by=cmd.actor_id,
            created_at=now_iso(), updated_at=now_iso(),
        )
        entity.create()
        async with self._uow_factory() as uow:
            await self._reservations.add(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)

    async def confirm(self, cmd: ConfirmReservation) -> Result:
        entity = await self._reservations.get(cmd.reservation_id, tenant_id=cmd.tenant_id, property_id=cmd.property_id)
        if not entity:
            raise NotFoundError("الحجز غير موجود")
        entity.confirm()
        entity.updated_at = now_iso()
        async with self._uow_factory() as uow:
            await self._reservations.save(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)

    async def cancel(self, cmd: CancelReservation) -> Result:
        entity = await self._reservations.get(cmd.reservation_id, tenant_id=cmd.tenant_id, property_id=cmd.property_id)
        if not entity:
            raise NotFoundError("الحجز غير موجود")
        entity.cancel()
        entity.updated_at = now_iso()
        async with self._uow_factory() as uow:
            await self._reservations.save(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)

    async def mark_checked_in(self, cmd: MarkReservationCheckedIn) -> Result:
        entity = await self._reservations.get(cmd.reservation_id, tenant_id=cmd.tenant_id, property_id=cmd.property_id)
        if not entity:
            raise NotFoundError("الحجز غير موجود")
        entity.mark_checked_in(cmd.checkin_id)
        entity.updated_at = now_iso()
        async with self._uow_factory() as uow:
            await self._reservations.save(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)
