from __future__ import annotations
from kernel.persistence import session_kwargs
from modules.reservations.domain.models import ReservationEntity
from modules.reservations.domain.repository import ReservationRepository

class MongoReservationRepository(ReservationRepository):
    def __init__(self, db) -> None:
        self._col = db["reservations"]

    @staticmethod
    def _to_entity(doc: dict) -> ReservationEntity:
        return ReservationEntity(
            id=doc["id"], tenant_id=doc.get("tenant_id", "default"), property_id=doc.get("property_id", "main"),
            guest_id=doc.get("guest_id", ""), room_number=doc.get("room_number"), floor=doc.get("floor"),
            arrival_date=doc.get("arrival_date", ""), departure_date=doc.get("departure_date", ""),
            adults=int(doc.get("adults", 1)), children=int(doc.get("children", 0)),
            source=doc.get("source", "walk_in"), status=doc.get("status", "draft"), note=doc.get("note", ""),
            created_by=doc.get("created_by", ""), created_at=doc.get("created_at", ""), updated_at=doc.get("updated_at", ""),
            checkin_id=doc.get("checkin_id"),
        )

    @staticmethod
    def _to_doc(e: ReservationEntity) -> dict:
        return {
            "id": e.id, "tenant_id": e.tenant_id, "property_id": e.property_id,
            "guest_id": e.guest_id, "room_number": e.room_number, "floor": e.floor,
            "arrival_date": e.arrival_date, "departure_date": e.departure_date,
            "adults": e.adults, "children": e.children, "source": e.source,
            "status": e.status, "note": e.note, "created_by": e.created_by,
            "created_at": e.created_at, "updated_at": e.updated_at, "checkin_id": e.checkin_id,
        }

    async def get(self, reservation_id: str, *, tenant_id: str | None = None, property_id: str | None = None) -> ReservationEntity | None:
        q = {"id": reservation_id}
        if tenant_id:
            q["tenant_id"] = tenant_id
        if property_id:
            q["property_id"] = property_id
        doc = await self._col.find_one(q, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def find_overlap(self, *, tenant_id: str, property_id: str, room_number: int, arrival_date: str, departure_date: str, exclude_id: str | None = None) -> ReservationEntity | None:
        q = {"tenant_id": tenant_id, "property_id": property_id, "room_number": room_number, "status": {"$in": ["draft", "confirmed"]}, "arrival_date": {"$lt": departure_date}, "departure_date": {"$gt": arrival_date}}
        if exclude_id:
            q["id"] = {"$ne": exclude_id}
        doc = await self._col.find_one(q, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def add(self, reservation: ReservationEntity, uow=None) -> ReservationEntity:
        await self._col.insert_one(self._to_doc(reservation), **session_kwargs(uow))
        return reservation

    async def save(self, reservation: ReservationEntity, uow=None) -> ReservationEntity:
        await self._col.update_one({"id": reservation.id, "tenant_id": reservation.tenant_id, "property_id": reservation.property_id}, {"$set": self._to_doc(reservation)}, upsert=True, **session_kwargs(uow))
        return reservation

    async def list_scoped(self, scoped_filter: dict, *, limit: int = 300) -> list[ReservationEntity]:
        limit = max(1, min(int(limit), 1000))
        docs = await self._col.find(scoped_filter or {}, {"_id": 0}).sort("arrival_date", 1).to_list(limit)
        return [self._to_entity(d) for d in docs]
