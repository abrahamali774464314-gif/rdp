from __future__ import annotations
import uuid
from dataclasses import dataclass
from kernel.bus import EventBus
from kernel.clock import now_iso
from kernel.contracts import Command, Result
from kernel.text import sanitize
from modules.messaging.domain.models import ConversationEntity, MessageEntity
from modules.messaging.domain.repository import MessagingRepository

@dataclass(frozen=True)
class RecordMessage(Command):
    tenant_id: str
    property_id: str
    channel: str
    direction: str
    body: str
    phone: str = ""
    guest_id: str | None = None
    room_number: int | None = None
    provider: str = ""

class MessagingApplicationService:
    def __init__(self, *, messaging: MessagingRepository, uow_factory, bus: EventBus) -> None:
        self._messaging = messaging
        self._uow_factory = uow_factory
        self._bus = bus

    def _scope(self, actor, base: dict | None = None) -> dict:
        q = dict(base or {})
        if getattr(actor, "role", "") != "super_admin":
            q["tenant_id"] = actor.tenant_id or "default"
            q["property_id"] = actor.active_property_id or "main"
        return q

    async def list_conversations_for(self, actor, *, base_query: dict | None = None, limit: int = 200):
        return await self._messaging.list_conversations(self._scope(actor, base_query), limit=limit)

    async def list_messages_for(self, actor, *, conversation_id: str, limit: int = 500):
        return await self._messaging.list_messages(self._scope(actor, {"conversation_id": conversation_id}), limit=limit)

    async def record(self, cmd: RecordMessage) -> Result:
        now = now_iso()
        channel = sanitize(cmd.channel, 40) or "internal"
        phone = sanitize(cmd.phone, 40) or ""
        conversation = await self._messaging.find_conversation(tenant_id=cmd.tenant_id, property_id=cmd.property_id, channel=channel, phone=phone)
        if conversation is None:
            conversation = ConversationEntity(id=str(uuid.uuid4()), tenant_id=cmd.tenant_id, property_id=cmd.property_id, channel=channel, phone=phone, guest_id=cmd.guest_id, room_number=cmd.room_number, created_at=now)
        conversation.last_message = sanitize(cmd.body, 2000) or ""
        conversation.last_direction = cmd.direction
        conversation.updated_at = now
        if cmd.guest_id:
            conversation.guest_id = cmd.guest_id
        if cmd.room_number:
            conversation.room_number = cmd.room_number
        conversation.validate()
        message = MessageEntity(
            id=str(uuid.uuid4()), conversation_id=conversation.id, tenant_id=cmd.tenant_id,
            property_id=cmd.property_id, channel=channel, direction=cmd.direction,
            body=sanitize(cmd.body, 2000) or "", phone=phone, provider=sanitize(cmd.provider, 80) or "", created_at=now,
        )
        message.record()
        async with self._uow_factory() as uow:
            await self._messaging.save_conversation(conversation, uow=uow)
            await self._messaging.add_message(message, uow=uow)
        await self._bus.publish_all(message.pull_events())
        return Result(data={"conversation": conversation, "message": message})
