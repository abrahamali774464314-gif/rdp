from __future__ import annotations
from dataclasses import dataclass, field
from kernel.contracts import DomainEvent, Entity
from kernel.errors import InvariantViolationError
from modules.messaging.domain.events import MessageRecorded

VALID_CHANNELS = frozenset({"sms", "whatsapp", "email", "internal"})
VALID_DIRECTIONS = frozenset({"in", "out"})

@dataclass
class ConversationEntity(Entity):
    id: str
    tenant_id: str
    property_id: str
    channel: str
    phone: str = ""
    guest_id: str | None = None
    room_number: int | None = None
    status: str = "open"
    last_message: str = ""
    last_direction: str = ""
    created_at: str = ""
    updated_at: str = ""

    def validate(self) -> None:
        if self.channel not in VALID_CHANNELS:
            raise InvariantViolationError("قناة الرسائل غير صحيحة")
        if not self.tenant_id or not self.property_id:
            raise InvariantViolationError("tenant_id/property_id مطلوبان")
        if self.channel in {"sms", "whatsapp"} and not self.phone:
            raise InvariantViolationError("رقم الهاتف مطلوب لهذه القناة")

@dataclass
class MessageEntity(Entity):
    id: str
    conversation_id: str
    tenant_id: str
    property_id: str
    channel: str
    direction: str
    body: str
    phone: str = ""
    delivery_status: str = "recorded"
    provider: str = ""
    created_at: str = ""
    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    def pull_events(self) -> list[DomainEvent]:
        ev, self._events = self._events, []
        return ev

    def record(self) -> None:
        if self.channel not in VALID_CHANNELS:
            raise InvariantViolationError("قناة الرسالة غير صحيحة")
        if self.direction not in VALID_DIRECTIONS:
            raise InvariantViolationError("اتجاه الرسالة غير صحيح")
        if not self.conversation_id or not self.body:
            raise InvariantViolationError("المحادثة ونص الرسالة مطلوبان")
        self._events.append(MessageRecorded(message_id=self.id, conversation_id=self.conversation_id, channel=self.channel, direction=self.direction, tenant_id=self.tenant_id, property_id=self.property_id))
