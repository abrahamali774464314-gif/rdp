from __future__ import annotations
from dataclasses import dataclass
from kernel.contracts import DomainEvent

@dataclass(frozen=True)
class MessageRecorded(DomainEvent):
    message_id: str
    conversation_id: str
    channel: str
    direction: str
    tenant_id: str
    property_id: str
    topic = "messaging.message_recorded"
