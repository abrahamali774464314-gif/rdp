from __future__ import annotations
from kernel.persistence import session_kwargs
from modules.messaging.domain.models import ConversationEntity, MessageEntity
from modules.messaging.domain.repository import MessagingRepository

class MongoMessagingRepository(MessagingRepository):
    def __init__(self, db) -> None:
        self._conversations = db["conversations"]
        self._messages = db["messages"]

    @staticmethod
    def _conv(doc: dict) -> ConversationEntity:
        return ConversationEntity(id=doc["id"], tenant_id=doc.get("tenant_id", "default"), property_id=doc.get("property_id", "main"), channel=doc.get("channel", "internal"), phone=doc.get("phone", ""), guest_id=doc.get("guest_id"), room_number=doc.get("room_number"), status=doc.get("status", "open"), last_message=doc.get("last_message", ""), last_direction=doc.get("last_direction", ""), created_at=doc.get("created_at", ""), updated_at=doc.get("updated_at", ""))

    @staticmethod
    def _msg(doc: dict) -> MessageEntity:
        return MessageEntity(id=doc["id"], conversation_id=doc.get("conversation_id", ""), tenant_id=doc.get("tenant_id", "default"), property_id=doc.get("property_id", "main"), channel=doc.get("channel", "internal"), direction=doc.get("direction", "in"), body=doc.get("body", ""), phone=doc.get("phone", ""), delivery_status=doc.get("delivery_status", "recorded"), provider=doc.get("provider", ""), created_at=doc.get("created_at", ""))

    @staticmethod
    def _conv_doc(e: ConversationEntity) -> dict:
        return {"id": e.id, "tenant_id": e.tenant_id, "property_id": e.property_id, "channel": e.channel, "phone": e.phone, "guest_id": e.guest_id, "room_number": e.room_number, "status": e.status, "last_message": e.last_message, "last_direction": e.last_direction, "created_at": e.created_at, "updated_at": e.updated_at}

    @staticmethod
    def _msg_doc(e: MessageEntity) -> dict:
        return {"id": e.id, "conversation_id": e.conversation_id, "tenant_id": e.tenant_id, "property_id": e.property_id, "channel": e.channel, "direction": e.direction, "body": e.body, "phone": e.phone, "delivery_status": e.delivery_status, "provider": e.provider, "created_at": e.created_at}

    async def get_conversation(self, conversation_id: str, *, tenant_id: str | None = None, property_id: str | None = None) -> ConversationEntity | None:
        q = {"id": conversation_id}
        if tenant_id:
            q["tenant_id"] = tenant_id
        if property_id:
            q["property_id"] = property_id
        doc = await self._conversations.find_one(q, {"_id": 0})
        return self._conv(doc) if doc else None

    async def find_conversation(self, *, tenant_id: str, property_id: str, channel: str, phone: str) -> ConversationEntity | None:
        doc = await self._conversations.find_one({"tenant_id": tenant_id, "property_id": property_id, "channel": channel, "phone": phone}, {"_id": 0})
        return self._conv(doc) if doc else None

    async def save_conversation(self, conversation: ConversationEntity, uow=None) -> ConversationEntity:
        await self._conversations.update_one({"id": conversation.id}, {"$set": self._conv_doc(conversation)}, upsert=True, **session_kwargs(uow))
        return conversation

    async def add_message(self, message: MessageEntity, uow=None) -> MessageEntity:
        await self._messages.insert_one(self._msg_doc(message), **session_kwargs(uow))
        return message

    async def list_conversations(self, scoped_filter: dict, *, limit: int = 200) -> list[ConversationEntity]:
        limit = max(1, min(int(limit), 1000))
        docs = await self._conversations.find(scoped_filter or {}, {"_id": 0}).sort("updated_at", -1).to_list(limit)
        return [self._conv(d) for d in docs]

    async def list_messages(self, scoped_filter: dict, *, limit: int = 500) -> list[MessageEntity]:
        limit = max(1, min(int(limit), 2000))
        docs = await self._messages.find(scoped_filter or {}, {"_id": 0}).sort("created_at", 1).to_list(limit)
        return [self._msg(d) for d in docs]
