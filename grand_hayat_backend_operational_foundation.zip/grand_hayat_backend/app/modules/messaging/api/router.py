from __future__ import annotations
from fastapi import APIRouter, Depends, status
from pydantic import BaseModel, Field
from kernel.security.query_scoper import Actor
from modules.messaging.application.service import RecordMessage
from shared.auth.dependencies import require_permission
from shared.config.container import container

router = APIRouter(prefix="/messaging", tags=["messaging"])

class MessageBody(BaseModel):
    channel: str = "whatsapp"
    direction: str = "out"
    phone: str = ""
    body: str = Field(min_length=1, max_length=2000)
    guest_id: str | None = None
    room_number: int | None = None
    provider: str = ""

def _conversation_to_dict(c) -> dict:
    return {"id": c.id, "channel": c.channel, "phone": c.phone, "guest_id": c.guest_id, "room_number": c.room_number, "status": c.status, "last_message": c.last_message, "last_direction": c.last_direction, "updated_at": c.updated_at, "tenant_id": c.tenant_id, "property_id": c.property_id}

def _message_to_dict(m) -> dict:
    return {"id": m.id, "conversation_id": m.conversation_id, "channel": m.channel, "direction": m.direction, "phone": m.phone, "body": m.body, "delivery_status": m.delivery_status, "provider": m.provider, "created_at": m.created_at, "tenant_id": m.tenant_id, "property_id": m.property_id}

@router.get("/conversations")
async def list_conversations(actor: Actor = Depends(require_permission("view_messaging"))):
    return [_conversation_to_dict(c) for c in await container.messaging.list_conversations_for(actor)]

@router.get("/conversations/{conversation_id}/messages")
async def list_messages(conversation_id: str, actor: Actor = Depends(require_permission("view_messaging"))):
    return [_message_to_dict(m) for m in await container.messaging.list_messages_for(actor, conversation_id=conversation_id)]

@router.post("/messages", status_code=status.HTTP_201_CREATED)
async def record_message(body: MessageBody, actor: Actor = Depends(require_permission("send_messaging"))):
    result = await container.messaging.record(RecordMessage(tenant_id=actor.tenant_id or "default", property_id=actor.active_property_id or "main", **body.model_dump()))
    return {"conversation": _conversation_to_dict(result.data["conversation"]), "message": _message_to_dict(result.data["message"])}
