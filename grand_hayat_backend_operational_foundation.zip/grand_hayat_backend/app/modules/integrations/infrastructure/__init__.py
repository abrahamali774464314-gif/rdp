"""
modules.integrations.infrastructure — محوّلات الأنظمة الخارجية (ACL Adapters)
═══════════════════════════════════════════════════════════════════

ينفّذ البند 4: "Anti-Corruption Layer — كل تكامل خارجي يمر عبر ACL"
والبند 2: "Domain → External System (مباشر) ممنوع".

كل adapter:
  - يُنفِّذ Port مجرّد يعرّفه المجال (مثل SmsPort)
  - يترجم لغة المجال («أرسل رسالة») إلى تفاصيل البوابة (HTTP, auth, payload)
  - يُرجع ExternalResult موحّد (يحمي المجال من تفاصيل البوابة)

هذه الطبقة الوحيدة المسموح فيها httpx/الاتصال الشبكي الخارجي.
"""
from __future__ import annotations

import logging

import httpx

from kernel.acl import AntiCorruptionAdapter, ExternalResult

logger = logging.getLogger("grandhayat.acl")


class SmsGatewayAdapter(AntiCorruptionAdapter):
    """ACL لبوابة الرسائل (Twilio-style / الأوائل). يغلّف تفاصيل HTTP."""

    @property
    def adapter_name(self) -> str:
        return "sms_gateway"

    def __init__(self, *, settings_provider, url_validator) -> None:
        self._settings = settings_provider     # دالة تُرجع إعدادات البوابة
        self._validate_url = url_validator      # url_guard.validate_external_url

    async def send(self, phone: str, body: str) -> ExternalResult:
        gw = await self._settings("sms_gateway")
        if not gw or not gw.get("enabled") or not gw.get("api_url"):
            logger.warning("SMS gateway not configured")
            return ExternalResult(ok=False, error="gateway_disabled")
        try:
            safe_url = self._validate_url(gw["api_url"], allow_http=bool(gw.get("allow_http")))
            params = {
                (gw.get("phone_field") or "to"): phone,
                (gw.get("message_field") or "message"): body,
            }
            sender = (gw.get("sender_id") or "").strip()
            if sender:
                params["From"] = sender
            headers = {}
            if gw.get("auth_header_name") and gw.get("api_key"):
                prefix = (gw.get("auth_header_prefix") or "").strip()
                headers[gw["auth_header_name"]] = f"{prefix} {gw['api_key']}".strip() if prefix else gw["api_key"]
            async with httpx.AsyncClient(timeout=12.0, follow_redirects=False) as cli:
                method = (gw.get("api_method") or "POST").upper()
                resp = await (cli.get(safe_url, params=params, headers=headers) if method == "GET"
                              else cli.post(safe_url, data=params, headers=headers))
            if resp.status_code >= 400:
                return ExternalResult(ok=False, error=f"http_{resp.status_code}")
            return ExternalResult(ok=True, reference=resp.headers.get("X-Message-Id"))
        except Exception as exc:  # noqa: BLE001
            logger.warning("SMS gateway send failed: %s", exc)
            return ExternalResult(ok=False, error=str(exc))
