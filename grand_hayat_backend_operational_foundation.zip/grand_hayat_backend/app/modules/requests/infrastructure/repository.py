"""
modules.requests.infrastructure.repository — تنفيذ مستودع الطلبات
═══════════════════════════════════════════════════════════════════

الطبقة الوحيدة المسموح فيها لمس motor/db لمجال الطلبات (البند 3).
تنفّذ RequestRepository وتترجم RequestEntity ⇄ مستند MongoDB.

ملاحظة على البحث عن الطلبات المفتوحة:
  find_open_by_room تستخدم {"$in": ["pending","accepted"]} — مطابقة تماماً
  لمنطق النظام القديم في routers/requests.py (الحالات النشطة).
"""
from __future__ import annotations

from kernel.persistence import session_kwargs
from shared.security.base_scoped_repository import ScopedRepositoryMixin
from modules.requests.domain.models import RequestEntity
from modules.requests.domain.repository import RequestRepository

COLLECTION = "requests"
OPEN_STATUSES = ["pending", "accepted"]


class MongoRequestRepository(ScopedRepositoryMixin, RequestRepository):
    _scope_sort_field = "created_at"
    _scope_sort_dir = -1
    _scope_default_limit = 300
    def __init__(self, db) -> None:
        self._col = db[COLLECTION]

    # ── Mappers (حدود المجال/التخزين) ─────────────────────────
    @staticmethod
    def _to_entity(doc: dict) -> RequestEntity:
        return RequestEntity(
            id=doc["id"],
            room_number=doc["room_number"],
            floor=doc["floor"],
            type=doc["type"],
            department=doc.get("department", "general"),
            note=doc.get("note", ""),
            status=doc.get("status", "pending"),
            source=doc.get("source", "manual"),
            created_by=doc.get("created_by"),
            created_by_name=doc.get("created_by_name", ""),
            accepted_by=doc.get("accepted_by"),
            accepted_by_name=doc.get("accepted_by_name"),
            accepted_at=doc.get("accepted_at"),
            completed_by=doc.get("completed_by"),
            completed_by_name=doc.get("completed_by_name"),
            completed_at=doc.get("completed_at"),
            linked_report_id=doc.get("linked_report_id"),
            tenant_id=doc.get("tenant_id", "default"),
            property_id=doc.get("property_id", "main"),
        )

    @staticmethod
    def _to_document(e: RequestEntity) -> dict:
        return {
            "id": e.id,
            "room_number": e.room_number,
            "floor": e.floor,
            "type": e.type,
            "department": e.department,
            "note": e.note,
            "status": e.status,
            "source": e.source,
            "created_by": e.created_by,
            "created_by_name": e.created_by_name,
            "accepted_by": e.accepted_by,
            "accepted_by_name": e.accepted_by_name,
            "accepted_at": e.accepted_at,
            "completed_by": e.completed_by,
            "completed_by_name": e.completed_by_name,
            "completed_at": e.completed_at,
            "linked_report_id": e.linked_report_id,
            "tenant_id": e.tenant_id,
            "property_id": e.property_id,
        }

    # ── Operations ────────────────────────────────────────────
    async def get(self, request_id: str) -> RequestEntity | None:
        doc = await self._col.find_one({"id": request_id}, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def add(self, request: RequestEntity, uow=None) -> RequestEntity:
        await self._col.insert_one(self._to_document(request), **session_kwargs(uow))
        return request

    async def save(self, request: RequestEntity, uow=None) -> RequestEntity:
        await self._col.update_one(
            {"id": request.id},
            {"$set": self._to_document(request)},
            **session_kwargs(uow),
        )
        return request

    async def find_open_by_room(
        self, room_number: int, request_type: str | None = None,
        *, tenant_id: str | None = None, property_id: str | None = None
    ) -> RequestEntity | None:
        query: dict = {"room_number": room_number, "status": {"$in": OPEN_STATUSES}}
        if tenant_id:
            query["tenant_id"] = tenant_id
        if property_id:
            query["property_id"] = property_id
        if request_type:
            query["type"] = request_type
        doc = await self._col.find_one(query, {"_id": 0})
        return self._to_entity(doc) if doc else None
