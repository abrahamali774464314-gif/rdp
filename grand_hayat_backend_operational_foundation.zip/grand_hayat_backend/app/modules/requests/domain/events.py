"""Domain events for hotel service requests."""
from __future__ import annotations

from dataclasses import dataclass

from kernel.contracts import DomainEvent


@dataclass(frozen=True)
class RequestCreated(DomainEvent):
    topic = "requests.created"
    request_id: str = ""
    room_number: int = 0
    floor: int = 0
    request_type: str = ""
    department: str = ""
    source: str = ""
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class RequestAccepted(DomainEvent):
    topic = "requests.accepted"
    request_id: str = ""
    room_number: int = 0
    floor: int = 0
    accepted_by: str = ""
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class RequestCompleted(DomainEvent):
    topic = "requests.completed"
    request_id: str = ""
    room_number: int = 0
    floor: int = 0
    request_type: str = ""
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class RequestCompletedReleasesRoom(DomainEvent):
    topic = "requests.completed_releases_room"
    request_id: str = ""
    room_number: int = 0
    floor: int = 0
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class RequestCancelled(DomainEvent):
    topic = "requests.cancelled"
    request_id: str = ""
    room_number: int = 0
    tenant_id: str = "default"
    property_id: str = "main"
