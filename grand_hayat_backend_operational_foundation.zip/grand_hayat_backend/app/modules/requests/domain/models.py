"""
modules.requests.domain.models — كيان الطلب وسلوكه
═══════════════════════════════════════════════════════════════════

Domain Ownership: يملك سجلّ الطلب وحالته فقط. لا يلمس rooms ولا
housekeeping — ينشر أحداثاً، وتستجيب المجالات الأخرى.

منطق المجال الأصيل المنقول من request_service القديم إلى هنا:
  «أيّ طلب عند اكتماله يُحرّر الغرفة؟»
    - طلب من نوع housekeeping
    - طلب متابعة من الفحص (source ∈ inspection_maintenance / inspection_network /
      room_problem_alert)
  هذا القرار يعيش في RequestEntity.releases_room_on_completion — لا في مجال الغرف.

State Machine: pending → accepted → completed (و cancelled من أي حالة مفتوحة).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from kernel.contracts import DomainEvent, Entity
from kernel.errors import ConflictError, InvariantViolationError
from kernel.state_machine import StateMachine

from modules.requests.domain.events import (
    RequestAccepted,
    RequestCancelled,
    RequestCompleted,
    RequestCompletedReleasesRoom,
    RequestCreated,
)

# ══════════════════════════════════════════════════════════════
# أنواع الطلبات (Bounded list — مرآة لـ permissions.REQUEST_TYPES)
# ══════════════════════════════════════════════════════════════
REQUEST_TYPES = frozenset({
    "room_service", "housekeeping", "maintenance", "laundry",
    "internet_card", "billing", "reception", "other",
})

# الأنواع التي تُحرّر الغرفة عند اكتمالها
ROOM_RELEASING_TYPES = frozenset({"housekeeping"})

# مصادر المتابعة من الفحص التي تُحرّر الغرفة عند اكتمالها
ROOM_RELEASING_SOURCES = frozenset({
    "inspection_maintenance", "inspection_network", "room_problem_alert",
})


# ══════════════════════════════════════════════════════════════
# State Machine — دورة حياة الطلب
# ══════════════════════════════════════════════════════════════
REQUEST_FSM = StateMachine(
    name="request",
    transitions={
        "pending":   {"accepted", "completed", "cancelled"},
        "accepted":  {"completed", "cancelled"},
        "completed": set(),   # نهائية
        "cancelled": set(),   # نهائية
    },
    terminal=frozenset({"completed", "cancelled"}),
)


# ══════════════════════════════════════════════════════════════
# Entity — الطلب (Aggregate Root)
# ══════════════════════════════════════════════════════════════
@dataclass
class RequestEntity(Entity):
    """طلب خدمة فندقية. يملك حالته وبياناته.

    Invariants:
      - النوع ضمن REQUEST_TYPES
      - room_number و floor موجبان
      - لا انتقال من حالة نهائية (يفرضه FSM)
    """
    id: str
    room_number: int
    floor: int
    type: str
    department: str = "general"
    note: str = ""
    status: str = "pending"
    source: str = "manual"
    # تدقيق دورة الحياة
    created_by: str | None = None
    created_by_name: str = ""
    accepted_by: str | None = None
    accepted_by_name: str | None = None
    accepted_at: str | None = None
    completed_by: str | None = None
    completed_by_name: str | None = None
    completed_at: str | None = None
    # ربط بتقرير فحص (لطلبات المتابعة)
    linked_report_id: str | None = None
    tenant_id: str = "default"
    property_id: str = "main"

    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    def pull_events(self) -> list[DomainEvent]:
        ev, self._events = self._events, []
        return ev

    # ── Invariants ────────────────────────────────────────────
    def _check_invariants(self) -> None:
        if self.type not in REQUEST_TYPES:
            raise InvariantViolationError(f"نوع طلب غير معروف: {self.type}")
        if self.room_number <= 0 or self.floor <= 0:
            raise InvariantViolationError("رقم الغرفة/الدور غير صالح")

    # ── منطق المجال: هل يُحرّر هذا الطلب الغرفة عند اكتماله؟ ────
    @property
    def releases_room_on_completion(self) -> bool:
        return (
            self.type in ROOM_RELEASING_TYPES
            or self.source in ROOM_RELEASING_SOURCES
        )

    # ── Behaviours ────────────────────────────────────────────
    def create(self) -> None:
        """يُثبّت الطلب ويُطلق حدث الإنشاء (يُستدعى بعد البناء)."""
        self._check_invariants()
        self._events.append(RequestCreated(
            request_id=self.id, room_number=self.room_number, floor=self.floor,
            request_type=self.type, department=self.department, source=self.source,
            tenant_id=self.tenant_id, property_id=self.property_id,
        ))

    def accept(self, *, by: str, by_name: str, at: str) -> None:
        self.status = REQUEST_FSM.transition(self.status, "accepted")
        self.accepted_by = by
        self.accepted_by_name = by_name
        self.accepted_at = at
        self._events.append(RequestAccepted(
            request_id=self.id, room_number=self.room_number,
            floor=self.floor, accepted_by=by,
            tenant_id=self.tenant_id, property_id=self.property_id,
        ))

    def complete(self, *, by: str, by_name: str, at: str) -> None:
        self.status = REQUEST_FSM.transition(self.status, "completed")
        self.completed_by = by
        self.completed_by_name = by_name
        self.completed_at = at

        # حدث عام (تدقيق/إشعار)
        self._events.append(RequestCompleted(
            request_id=self.id, room_number=self.room_number,
            floor=self.floor, request_type=self.type,
            tenant_id=self.tenant_id, property_id=self.property_id,
        ))
        # حدث متخصّص فقط إن كان الطلب يُحرّر الغرفة (منطق مجالي)
        if self.releases_room_on_completion:
            self._events.append(RequestCompletedReleasesRoom(
                request_id=self.id, room_number=self.room_number, floor=self.floor,
                tenant_id=self.tenant_id, property_id=self.property_id,
            ))

    def cancel(self) -> None:
        if self.status in REQUEST_FSM.terminal:
            raise ConflictError("لا يمكن إلغاء طلب في حالة نهائية")
        self.status = REQUEST_FSM.transition(self.status, "cancelled")
        self._events.append(RequestCancelled(
            request_id=self.id, room_number=self.room_number,
            tenant_id=self.tenant_id, property_id=self.property_id,
        ))
