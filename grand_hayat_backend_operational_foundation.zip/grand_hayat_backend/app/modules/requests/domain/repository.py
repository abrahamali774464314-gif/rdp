"""
modules.requests.domain.repository — واجهة مستودع الطلبات
═══════════════════════════════════════════════════════════════════

Repository Law (البند 4): الـ application يعتمد على هذا Protocol فقط.
التنفيذ في infrastructure ويترجم RequestEntity ⇄ مستند MongoDB.
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable

from modules.requests.domain.models import RequestEntity


@runtime_checkable
class RequestRepository(Protocol):
    """عقد تخزين طلبات الخدمة."""

    async def get(self, request_id: str) -> RequestEntity | None:
        """يجلب طلباً بمعرّفه."""
        ...

    async def add(self, request: RequestEntity, uow=None) -> RequestEntity:
        """يُدرج طلباً جديداً."""
        ...

    async def save(self, request: RequestEntity, uow=None) -> RequestEntity:
        """يحدّث طلباً قائماً (قبول/إكمال/إلغاء)."""
        ...

    async def find_open_by_room(
        self, room_number: int, request_type: str | None = None,
        *, tenant_id: str | None = None, property_id: str | None = None
    ) -> RequestEntity | None:
        """يجلب طلباً مفتوحاً (pending/accepted) لغرفة، اختيارياً بنوع محدّد."""
        ...
