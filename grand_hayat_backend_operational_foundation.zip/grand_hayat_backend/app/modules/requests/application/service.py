"""
modules.requests.application.service — منظّم الطلبات
═══════════════════════════════════════════════════════════════════

جانبان:

① منظّم الأوامر (يدوي): إنشاء/قبول/إكمال/إلغاء طلب.
   عند الإكمال، الـ Entity يقرّر إن كان يُحرّر الغرفة، ويُصدر الحدث
   المتخصّص الذي يلتقطه مجال الغرف — دون لمس مباشر.

② Subscribers (تلقائي): مجال الطلبات يُنشئ طلبات استجابةً لأحداث
   مجالات أخرى — عبر الـ bus، لا استدعاء مباشر:
     - checkouts.completed_ready_for_cleaning → طلب نظافة تلقائي
     - inspections.maintenance_required       → طلب صيانة
     - inspections.network_required           → طلب صيانة شبكات
     - inspections.room_problem               → تنبيه استقبال

هذا يحافظ على Domain Ownership: مجال checkout/inspection لا يُنشئ طلبات
في collection الطلبات بنفسه (كما كان يفعل النظام القديم)، بل يُعلن حدثاً،
ومجال الطلبات — المالك الوحيد لـ db.requests — هو من يُنشئها.
"""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass

from kernel.bus import EventBus
from kernel.contracts import Command, Result
from kernel.errors import ConflictError, NotFoundError
from kernel.clock import now_iso
from kernel.text import sanitize

from modules.requests.domain.models import RequestEntity
from modules.requests.domain.repository import RequestRepository

logger = logging.getLogger("grandhayat.requests")


# ══════════════════════════════════════════════════════════════
# Commands
# ══════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class CreateRequest(Command):
    room_number: int
    floor: int
    type: str
    department: str
    note: str
    source: str
    actor_id: str | None
    actor_name: str
    linked_report_id: str | None = None
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class AcceptRequest(Command):
    request_id: str
    actor_id: str
    actor_name: str


@dataclass(frozen=True)
class CompleteRequest(Command):
    request_id: str
    actor_id: str
    actor_name: str


@dataclass(frozen=True)
class CancelRequest(Command):
    request_id: str
    actor_id: str


# ══════════════════════════════════════════════════════════════
# Application Service (Orchestrator)
# ══════════════════════════════════════════════════════════════
class RequestApplicationService:
    def __init__(self, *, requests: RequestRepository, uow_factory, bus: EventBus) -> None:
        self._requests = requests
        self._uow_factory = uow_factory
        self._bus = bus

    async def list_for(self, actor, *, own_only: bool = False,
                       base_query: dict | None = None,
                       limit: int | None = None):
        """يُرجع السجلّات المُقيَّدة حسب نطاق الفاعل (floor/department/own_only).

        الحلقة الكاملة عبر helper موحّد:
          Actor → ScopingRules.for_requests → AccessScope → Mongo filter → repo
        """
        from shared.security.scoped_listing import scoped_list
        # نستخدم الـ singletons المحقونة من الـ container إن توفّرت،
        # وإلا نبنيها كسولاً (توافق مع الاستخدام بلا container).
        rules = getattr(self, "_scoping_rules", None)
        if rules is None:
            from kernel.security.scoping_rules import ScopingRules
            rules = ScopingRules()
        scoper = getattr(self, "_scoper", None)
        return await scoped_list(
            self._requests, lambda a: rules.for_requests(a, own_only=own_only), actor,
            scoper=scoper, base_query=base_query, limit=limit,
        )


    async def _persist_new(self, entity: RequestEntity) -> RequestEntity:
        async with self._uow_factory() as uow:
            await self._requests.add(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return entity

    async def _persist_update(self, entity: RequestEntity) -> RequestEntity:
        async with self._uow_factory() as uow:
            await self._requests.save(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return entity

    # ── أوامر يدوية ───────────────────────────────────────────
    async def create(self, cmd: CreateRequest) -> Result:
        entity = RequestEntity(
            id=str(uuid.uuid4()),
            room_number=cmd.room_number,
            floor=cmd.floor,
            type=cmd.type,
            department=cmd.department or "general",
            note=sanitize(cmd.note, 1000) or "",
            source=cmd.source or "manual",
            created_by=cmd.actor_id,
            created_by_name=cmd.actor_name,
            linked_report_id=cmd.linked_report_id,
            tenant_id=cmd.tenant_id,
            property_id=cmd.property_id,
        )
        entity.create()
        await self._persist_new(entity)
        return Result(data=entity)

    async def accept(self, cmd: AcceptRequest) -> Result:
        entity = await self._requests.get(cmd.request_id)
        if not entity:
            raise NotFoundError("الطلب غير موجود")
        entity.accept(by=cmd.actor_id, by_name=cmd.actor_name, at=now_iso())
        await self._persist_update(entity)
        return Result(data=entity)

    async def complete(self, cmd: CompleteRequest) -> Result:
        entity = await self._requests.get(cmd.request_id)
        if not entity:
            raise NotFoundError("الطلب غير موجود")
        entity.complete(by=cmd.actor_id, by_name=cmd.actor_name, at=now_iso())
        # عند الإكمال: إن كان الطلب يُحرّر الغرفة، صدر الحدث المتخصّص تلقائياً
        await self._persist_update(entity)
        return Result(data=entity)

    async def cancel(self, cmd: CancelRequest) -> Result:
        entity = await self._requests.get(cmd.request_id)
        if not entity:
            raise NotFoundError("الطلب غير موجود")
        entity.cancel()
        await self._persist_update(entity)
        return Result(data=entity)

    # ── إنشاء تلقائي (يُستدعى من الـ subscribers) ──────────────
    async def create_auto(self, *, room_number: int, floor: int, type: str,
                          department: str, note: str, source: str,
                          linked_report_id: str | None = None,
                          tenant_id: str = "default", property_id: str = "main") -> RequestEntity:
        existing = await self._requests.find_open_by_room(
            room_number, type, tenant_id=tenant_id, property_id=property_id
        )
        if existing and existing.source == source:
            return existing
        entity = RequestEntity(
            id=str(uuid.uuid4()),
            room_number=room_number, floor=floor, type=type,
            department=department, note=sanitize(note, 1000) or "",
            source=source, created_by=None, created_by_name="النظام",
            linked_report_id=linked_report_id,
            tenant_id=tenant_id, property_id=property_id,
        )
        entity.create()
        return await self._persist_new(entity)


# ══════════════════════════════════════════════════════════════
# Subscribers — إنشاء طلبات تلقائياً استجابةً لأحداث مجالات أخرى
# ══════════════════════════════════════════════════════════════
class RequestEventSubscribers:
    """مجال الطلبات يُنشئ الطلبات التلقائية (المالك الوحيد لـ db.requests)."""

    def __init__(self, app: RequestApplicationService) -> None:
        self._app = app

    def register(self, bus: EventBus) -> None:
        bus.subscribe("checkouts.completed_ready_for_cleaning", self._on_checkout_cleaning)
        bus.subscribe("inspections.maintenance_required", self._on_maintenance)
        bus.subscribe("inspections.network_required", self._on_network)
        bus.subscribe("inspections.room_problem", self._on_room_problem)

    async def _on_checkout_cleaning(self, event) -> None:
        await self._app.create_auto(
            room_number=event.room_number, floor=event.floor,
            type="housekeeping", department="housekeeping",
            note="طلب نظافة تلقائي بعد إكمال Checkout", source="checkout",
            tenant_id=getattr(event, "tenant_id", "default"),
            property_id=getattr(event, "property_id", "main"),
        )

    async def _on_maintenance(self, event) -> None:
        await self._app.create_auto(
            room_number=event.room_number, floor=event.floor,
            type="maintenance", department="maintenance",
            note="طلب صيانة تلقائي من تقرير فحص الغرفة", source="inspection_maintenance",
            linked_report_id=getattr(event, "report_id", None),
            tenant_id=getattr(event, "tenant_id", "default"),
            property_id=getattr(event, "property_id", "main"),
        )

    async def _on_network(self, event) -> None:
        await self._app.create_auto(
            room_number=event.room_number, floor=event.floor,
            type="internet_card", department="it",
            note="طلب صيانة شبكات من تقرير الفحص", source="inspection_network",
            linked_report_id=getattr(event, "report_id", None),
            tenant_id=getattr(event, "tenant_id", "default"),
            property_id=getattr(event, "property_id", "main"),
        )

    async def _on_room_problem(self, event) -> None:
        await self._app.create_auto(
            room_number=event.room_number, floor=event.floor,
            type="other", department="reception",
            note="تنبيه للاستقبال: مشكلة بالغرفة حسب تقرير الفحص", source="room_problem_alert",
            linked_report_id=getattr(event, "report_id", None),
            tenant_id=getattr(event, "tenant_id", "default"),
            property_id=getattr(event, "property_id", "main"),
        )
