from __future__ import annotations
from fastapi import APIRouter, Depends, Query, status
from pydantic import BaseModel, Field
from kernel.security.query_scoper import Actor
from modules.requests.application.service import AcceptRequest, CancelRequest, CompleteRequest, CreateRequest
from shared.auth.dependencies import require_permission
from shared.config.container import container

router = APIRouter(prefix="/requests", tags=["requests"])

class RequestBody(BaseModel):
    room_number: int = Field(ge=1)
    floor: int = Field(ge=1)
    type: str = Field(min_length=1, max_length=80)
    department: str = "general"
    note: str = ""
    source: str = "manual"
    linked_report_id: str | None = None

def _request_to_dict(r) -> dict:
    return {"id": r.id, "room_number": r.room_number, "floor": r.floor, "type": r.type, "department": r.department, "note": r.note, "status": r.status, "source": r.source, "created_by": r.created_by, "created_by_name": r.created_by_name, "accepted_by": r.accepted_by, "accepted_at": r.accepted_at, "completed_by": r.completed_by, "completed_at": r.completed_at, "linked_report_id": r.linked_report_id, "tenant_id": r.tenant_id, "property_id": r.property_id}

@router.get("")
async def list_requests(status: str | None = Query(default=None), own_only: bool = Query(default=False), actor: Actor = Depends(require_permission("view_requests"))):
    base = {"status": status} if status else None
    return [_request_to_dict(r) for r in await container.requests.list_for(actor, own_only=own_only, base_query=base)]

@router.post("", status_code=status.HTTP_201_CREATED)
async def create_request(body: RequestBody, actor: Actor = Depends(require_permission("create_request"))):
    result = await container.requests.create(CreateRequest(tenant_id=actor.tenant_id or "default", property_id=actor.active_property_id or "main", actor_id=actor.id, actor_name=actor.name, **body.model_dump()))
    return _request_to_dict(result.data)

@router.post("/{request_id}/accept")
async def accept_request(request_id: str, actor: Actor = Depends(require_permission("accept_request"))):
    result = await container.requests.accept(AcceptRequest(request_id=request_id, actor_id=actor.id, actor_name=actor.name))
    return _request_to_dict(result.data)

@router.post("/{request_id}/complete")
async def complete_request(request_id: str, actor: Actor = Depends(require_permission("complete_request"))):
    result = await container.requests.complete(CompleteRequest(request_id=request_id, actor_id=actor.id, actor_name=actor.name))
    return _request_to_dict(result.data)

@router.post("/{request_id}/cancel")
async def cancel_request(request_id: str, actor: Actor = Depends(require_permission("delete_request"))):
    result = await container.requests.cancel(CancelRequest(request_id=request_id, actor_id=actor.id))
    return _request_to_dict(result.data)
