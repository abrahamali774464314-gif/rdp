"""
modules.billing.domain.repository — واجهة مستودع الفواتير
═══════════════════════════════════════════════════════════════════

Repository Law (البند 4): المجال والـ application يعتمدان على هذا
Protocol المجرّد فقط. التنفيذ (MongoFolioRepository) في infrastructure.

نقطة مالية مهمة: idempotency على مستويين:
  - داخل الذاكرة  : FolioEntity.post يتحقق من idempotency_key في الدفتر المحمّل
  - عبر الطلبات   : find_txn_by_idempotency_key يفحص التخزين قبل بدء العملية
هذا يمنع الترحيل المزدوج حتى لو وصل طلبان متزامنان (شبكة/إعادة محاولة).

الدفتر append-only: save تكتب القيود الجديدة فقط، ولا تحذف/تعدّل القديمة.
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable

from modules.billing.domain.models import FolioEntity, FolioTransaction


@runtime_checkable
class FolioRepository(Protocol):
    """عقد تخزين الفواتير. تعتمد عليه طبقة الـ application فقط."""

    async def get(self, folio_id: str) -> FolioEntity | None:
        """يجلب فاتورة بكامل دفتر قيودها (hydrated aggregate)."""
        ...

    async def get_master_for_checkin(self, checkin_id: str) -> FolioEntity | None:
        """يجلب الفاتورة الرئيسية المرتبطة بتسكين (لربط الرسوم التلقائية)."""
        ...

    async def save(self, folio: FolioEntity, uow=None) -> FolioEntity:
        """يحفظ رأس الفاتورة + يضيف القيود الجديدة (append-only)."""
        ...

    async def find_txn_by_idempotency_key(self, key: str) -> FolioTransaction | None:
        """فحص idempotency عبر الطلبات — يمنع الترحيل المزدوج."""
        ...

    async def list_scoped(self, scoped_filter: dict, *, limit: int = 200) -> list[FolioEntity]:
        """قائمة فواتير مقيّدة حسب tenant/property."""
        ...
