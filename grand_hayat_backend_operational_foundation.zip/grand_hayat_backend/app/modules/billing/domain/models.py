"""
modules.billing.domain.models — النواة المالية (Financial Core)
═══════════════════════════════════════════════════════════════════

أهم وأخطر مجال في النظام. القيود الدستورية المطبَّقة هنا:

  ① Financial Immutability (البند 4)
     FolioTransaction مُعرَّف frozen=True → غير قابل للتعديل بعد الإنشاء
     على مستوى لغة Python نفسها. أي محاولة تعديل ترفع FrozenInstanceError.

  ② Reversal Entries فقط (البند 3)
     "ممنوع تعديل البيانات المالية بعد التثبيت". الإلغاء لا يحذف ولا يعدّل،
     بل يضيف قيداً عكسياً جديداً ويسم الأصلي is_void=True (وسم فقط).

  ③ Append-only Ledger
     القيود تُضاف فقط، لا تُحذف. الرصيد يُحسب دائماً من القيود غير الملغاة.

  ④ Decimal في كل الحسابات
     لا float إطلاقاً في المبالغ — تجنّباً لأخطاء التقريب المالي.

  ⑤ State Machine Authority (البند 4)
     حالة الفاتورة تتغيّر عبر FOLIO_FSM فقط.

  ⑥ لا Side Effects (البند 2)
     لا motor، لا HTTP، لا SMS. منطق نقي فقط.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from decimal import Decimal, ROUND_HALF_UP

from kernel.contracts import DomainEvent, Entity
from kernel.errors import (
    ConflictError,
    FinancialImmutabilityError,
    InvariantViolationError,
    PermissionDeniedError,
)
from kernel.state_machine import StateMachine

from modules.billing.domain.events import (
    ChargePosted,
    DiscountApplied,
    FolioClosed,
    PaymentPosted,
    TransactionReversed,
)

# الدقة المالية الموحّدة: منزلتان عشريتان، تقريب نصفي لأعلى
CENTS = Decimal("0.01")
ZERO = Decimal("0.00")


def _money(value) -> Decimal:
    """يحوّل أي قيمة إلى Decimal مالي مضبوط (منزلتان). لا float أبداً."""
    return Decimal(str(value)).quantize(CENTS, rounding=ROUND_HALF_UP)


# ══════════════════════════════════════════════════════════════
# أنواع القيود (Transaction Types) — تحدد إشارة القيد في الرصيد
# ══════════════════════════════════════════════════════════════
# مدين (يزيد ما على النزيل):
DEBIT_TYPES = frozenset({"charge", "transfer_in"})
# دائن (يقلّل ما على النزيل):
CREDIT_TYPES = frozenset({"payment", "discount", "transfer_out"})
ALL_TXN_TYPES = DEBIT_TYPES | CREDIT_TYPES | {"adjustment"}


# ══════════════════════════════════════════════════════════════
# State Machine — دورة حياة الفاتورة
# ══════════════════════════════════════════════════════════════
FOLIO_FSM = StateMachine(
    name="folio",
    transitions={
        "open":     {"closed", "disputed"},
        "disputed": {"open", "closed"},
        "closed":   {"open"},   # إعادة فتح — للمدير فقط (يُتحقق في application)
    },
)


# ══════════════════════════════════════════════════════════════
# Value Object — قيد مالي (Financial Transaction) — غير قابل للتعديل
# ══════════════════════════════════════════════════════════════
@dataclass(frozen=True)  # ① frozen = Financial Immutability على مستوى اللغة
class FolioTransaction:
    """قيد واحد في دفتر الأستاذ. بمجرد إنشائه = ثابت أبدي.

    لا يُعدَّل مبلغه ولا نوعه. الإلغاء يتم عبر قيد عكسي منفصل (reverse).
    الحقول reversed_* / is_void تُملأ مرة واحدة فقط عند العكس عبر replace()،
    منتجةً كائناً جديداً (الأصلي يبقى سليماً في الذاكرة لحظة الاستبدال).
    """
    id: str
    folio_id: str
    type: str                          # charge | payment | discount | transfer_in/out | adjustment
    subtype: str                       # room_rate | minibar | cash | card ...
    amount: Decimal                    # دائماً موجب؛ الإشارة تُستنتج من type
    currency: str
    description: str
    business_date: str                 # تاريخ العمل (Night Audit)، لا تاريخ النظام
    posted_by: str
    posted_at: str
    # — ضريبة / تفاصيل اختيارية —
    tax_amount: Decimal = ZERO
    tax_breakdown: tuple = ()          # ((name, rate, amount), ...) ثابتة
    discounts: tuple = ()
    # — ربط محاسبي —
    charge_code: str | None = None
    reference_id: str | None = None    # رقم إيصال/مرجع خارجي
    posted_to_window_id: str | None = None
    # — حقول العكس (Reversal) —
    linked_txn_id: str | None = None   # في القيد العكسي: يشير للأصلي
    is_void: bool = False              # في الأصلي: يُوسم True عند عكسه
    reversed_by: str | None = None
    reversed_at: str | None = None
    reversal_txn_id: str | None = None
    # — تتبّع —
    idempotency_key: str | None = None
    source: str = "manual"             # manual | reversal | night_audit | sms | system

    def __post_init__(self) -> None:
        # تحقّقات لا تُعدّل الحقول (frozen) — ترفع فقط عند الخطأ
        if self.type not in ALL_TXN_TYPES:
            raise InvariantViolationError(f"نوع قيد غير معروف: {self.type}")
        if self.amount < ZERO:
            raise InvariantViolationError("مبلغ القيد لا يمكن أن يكون سالباً")

    @property
    def signed_amount(self) -> Decimal:
        """المبلغ بإشارته المحاسبية: مدين موجب، دائن سالب."""
        if self.is_void or self.source == "reversal":
            return ZERO
        if self.type in DEBIT_TYPES:
            return self.amount
        if self.type in CREDIT_TYPES:
            return -self.amount
        return ZERO  # adjustment يُحسب يدوياً عند الحاجة


# ══════════════════════════════════════════════════════════════
# Aggregate Root — الفاتورة (Folio)
# ══════════════════════════════════════════════════════════════
@dataclass
class FolioEntity(Entity):
    """جذر تجميع الفاتورة. يملك دفتر القيود ويحرس كل الثوابت المالية.

    Invariants:
      - لا ترحيل على فاتورة غير مفتوحة
      - القيود append-only: لا حذف، لا تعديل (Reversal فقط)
      - الرصيد = Σ(القيود غير الملغاة بإشاراتها)
      - لا عكس لقيد مُلغى مسبقاً
      - idempotency: لا يُرحَّل قيدان بنفس idempotency_key
    """
    id: str
    checkin_id: str
    room_number: int
    guest_name: str
    folio_type: str = "master"         # master | guest_window | group
    status: str = "open"
    currency: str = "YER"
    business_date: str = ""
    tenant_id: str = "default"
    property_id: str = "main"
    # دفتر القيود — مغلّف، لا يُكشف للتعديل المباشر
    _transactions: list[FolioTransaction] = field(default_factory=list)
    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    def pull_events(self) -> list[DomainEvent]:
        ev, self._events = self._events, []
        return ev

    @property
    def transactions(self) -> tuple[FolioTransaction, ...]:
        """عرض للقراءة فقط — لا يمكن للخارج تعديل الدفتر."""
        return tuple(self._transactions)

    # ── حُرّاس الحالة ─────────────────────────────────────────
    def _assert_open(self) -> None:
        if self.status != "open":
            raise ConflictError("لا يمكن الترحيل على فاتورة غير مفتوحة")

    def _assert_idempotent(self, key: str | None) -> FolioTransaction | None:
        """يمنع التكرار: إن وُجد قيد بنفس المفتاح، يُرجعه بدل ترحيل جديد."""
        if not key:
            return None
        return next((t for t in self._transactions if t.idempotency_key == key), None)

    # ── الترحيل (Append-only) ─────────────────────────────────
    def post(self, txn: FolioTransaction) -> FolioTransaction:
        """يضيف قيداً للدفتر. idempotent عبر idempotency_key.

        يُرجع القيد المُرحَّل (أو القيد الموجود مسبقاً إن تكرر المفتاح).
        """
        self._assert_open()
        if txn.is_void:
            raise InvariantViolationError("لا يجوز ترحيل قيد مُلغى ابتداءً")
        if txn.folio_id != self.id:
            raise InvariantViolationError("القيد لا يخص هذه الفاتورة")

        existing = self._assert_idempotent(txn.idempotency_key)
        if existing is not None:
            return existing  # تكرار — لا نُرحّل مجدداً

        self._transactions.append(txn)
        self._emit_posted_event(txn)
        return txn

    def _emit_posted_event(self, txn: FolioTransaction) -> None:
        if txn.type == "charge":
            self._events.append(ChargePosted(
                folio_id=self.id, txn_id=txn.id, charge_code=txn.charge_code or txn.subtype,
                amount=str(txn.amount), currency=self.currency))
        elif txn.type == "payment":
            self._events.append(PaymentPosted(
                folio_id=self.id, txn_id=txn.id, method_code=txn.subtype,
                amount=str(txn.amount), currency=self.currency))
        elif txn.type == "discount":
            self._events.append(DiscountApplied(
                folio_id=self.id, txn_id=txn.id, amount=str(txn.amount)))

    # ── العكس (Reversal — لا تعديل، لا حذف) ───────────────────
    def reverse(self, original_id: str, reversal: FolioTransaction) -> FolioTransaction:
        """يعكس قيداً: يضيف القيد العكسي ويسم الأصلي is_void.

        تطبيق صارم لـ "Reversal Entries فقط" (البند 3): مبلغ الأصلي
        لا يتغيّر أبداً — نُنشئ نسخة موسومة عبر replace() (frozen-safe).
        """
        self._assert_open()
        idx = next((i for i, t in enumerate(self._transactions) if t.id == original_id), None)
        if idx is None:
            raise InvariantViolationError("القيد الأصلي غير موجود في الفاتورة")

        original = self._transactions[idx]
        if original.is_void:
            raise FinancialImmutabilityError("القيد مُلغى بالفعل — لا يُعكس مرتين")
        if reversal.linked_txn_id != original_id:
            raise InvariantViolationError("القيد العكسي يجب أن يشير للأصلي عبر linked_txn_id")
        if reversal.amount != original.amount or reversal.currency != original.currency:
            raise InvariantViolationError("القيد العكسي يجب أن يطابق مبلغ وعملة القيد الأصلي")
        if reversal.source != "reversal":
            raise InvariantViolationError("مصدر القيد العكسي يجب أن يكون reversal")

        # وسم الأصلي بنسخة جديدة (الأصلي frozen، فلا نعدّله مباشرة).
        # القيد العكسي audit-only لأن signed_amount يرجع صفراً لمصدر reversal؛
        # هذا يمنع خطأ احتساب الأصل صفر + العكس سالب.
        self._transactions[idx] = replace(
            original,
            is_void=True,
            reversed_by=reversal.posted_by,
            reversed_at=reversal.posted_at,
            reversal_txn_id=reversal.id,
        )
        self._transactions.append(reversal)
        self._events.append(TransactionReversed(
            folio_id=self.id, original_txn_id=original_id, reversal_txn_id=reversal.id))
        return reversal

    # ── الرصيد (محسوب دائماً من الدفتر — مصدر الحقيقة الوحيد) ──
    def balance(self) -> Decimal:
        total = sum((t.signed_amount for t in self._transactions), ZERO)
        return total.quantize(CENTS, rounding=ROUND_HALF_UP)

    def total_charges(self) -> Decimal:
        return sum((t.amount for t in self._transactions
                    if not t.is_void and t.source != "reversal" and t.type in DEBIT_TYPES), ZERO).quantize(CENTS)

    def total_payments(self) -> Decimal:
        return sum((t.amount for t in self._transactions
                    if not t.is_void and t.source != "reversal" and t.type in CREDIT_TYPES), ZERO).quantize(CENTS)

    # ── دورة الحياة ───────────────────────────────────────────
    def close(self, *, force: bool, is_admin: bool) -> None:
        bal = self.balance()
        if bal != ZERO and not force:
            raise ConflictError(f"لا يمكن إغلاق الفاتورة برصيد غير صفري ({bal} {self.currency})")
        if force and not is_admin:
            raise PermissionDeniedError("الإغلاق القسري متاح للمدير فقط")
        self.status = FOLIO_FSM.transition(self.status, "closed")
        self._events.append(FolioClosed(folio_id=self.id, final_balance=str(bal)))

    def reopen(self, *, is_admin: bool) -> None:
        if not is_admin:
            raise PermissionDeniedError("إعادة فتح الفاتورة متاحة للمدير فقط")
        self.status = FOLIO_FSM.transition(self.status, "open")
