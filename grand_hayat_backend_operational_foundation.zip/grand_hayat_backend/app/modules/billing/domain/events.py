"""
modules.billing.domain.events — أحداث النواة المالية
═══════════════════════════════════════════════════════════════════

أحداث = حقائق مالية وقعت بالفعل (past tense). تُنشر عبر Event Bus.
مجالات أخرى تشترك فيها (مثلاً: الإشعارات تبثّ تحديث الرصيد، التدقيق
الليلي يستمع لـ FolioClosed).

ملاحظة دستورية: الأحداث تحمل مبالغ كنصوص (str) لا Decimal، لأنها تعبر
حدود المجال (قد تُسلسَل/تُخزَّن). الحساب الدقيق يبقى داخل المجال بـ Decimal.
"""
from __future__ import annotations

from dataclasses import dataclass

from kernel.contracts import DomainEvent


@dataclass(frozen=True)
class FolioOpened(DomainEvent):
    """فُتحت فاتورة (folio) جديدة لنزيل."""
    topic = "billing.folio_opened"
    folio_id: str = ""
    checkin_id: str = ""
    room_number: int = 0


@dataclass(frozen=True)
class ChargePosted(DomainEvent):
    """رُحِّل مبلغ مدين (charge) على الفاتورة."""
    topic = "billing.charge_posted"
    folio_id: str = ""
    txn_id: str = ""
    charge_code: str = ""
    amount: str = "0.00"
    currency: str = "YER"


@dataclass(frozen=True)
class PaymentPosted(DomainEvent):
    """رُحِّل مبلغ دائن (payment) على الفاتورة."""
    topic = "billing.payment_posted"
    folio_id: str = ""
    txn_id: str = ""
    method_code: str = ""
    amount: str = "0.00"
    currency: str = "YER"


@dataclass(frozen=True)
class DiscountApplied(DomainEvent):
    """طُبِّق خصم على الفاتورة."""
    topic = "billing.discount_applied"
    folio_id: str = ""
    txn_id: str = ""
    amount: str = "0.00"


@dataclass(frozen=True)
class TransactionReversed(DomainEvent):
    """أُلغي قيد عبر قيد عكسي (Reversal). الأصلي وُسم is_void."""
    topic = "billing.transaction_reversed"
    folio_id: str = ""
    original_txn_id: str = ""
    reversal_txn_id: str = ""


@dataclass(frozen=True)
class FolioClosed(DomainEvent):
    """أُغلقت الفاتورة (رصيد صفري أو إغلاق قسري من المدير)."""
    topic = "billing.folio_closed"
    folio_id: str = ""
    final_balance: str = "0.00"
