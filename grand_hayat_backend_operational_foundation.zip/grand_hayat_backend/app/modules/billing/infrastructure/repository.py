"""
modules.billing.infrastructure.repository — تنفيذ Mongo (append-only)
═══════════════════════════════════════════════════════════════════

المكان الوحيد المسموح فيه بـ motor لمجال Billing. ينفّذ عقد FolioRepository
دون أي تسرّب للتفاصيل خارج هذا الملف.

البنية المالية الحرجة — Append-Only Ledger:
  - الفاتورة (Folio) محفوظة في collection 'folios' (رأس فقط — لا قيود).
  - القيود (Transactions) محفوظة في collection منفصل 'folio_transactions'.
  - عند save:
      * رأس الفاتورة → upsert (status, business_date, ...).
      * القيود → insert_only للجديد (يُعرف عبر id).
      * القيد المُلغى (is_void) → update لحقول الـ reversal فقط
        (is_void, reversed_by, reversed_at, reversal_txn_id).
  - **ممنوع:** delete، تعديل amount/type/posted_at لأي قيد.

هذا يطابق دستور Financial Immutability على مستوى التخزين، لا الذاكرة فقط.
حتى لو حاول كود مخرّب تعديل الـ amount، الـ save لن يكتبه.

الفهارس المطلوبة (في seed):
  - folios.id (unique)
  - folios.checkin_id + folio_type (للبحث السريع عن الفاتورة الرئيسية)
  - folio_transactions.id (unique)
  - folio_transactions.folio_id (للجمع)
  - folio_transactions.idempotency_key (sparse + unique — يمنع التكرار)
"""
from __future__ import annotations

from decimal import Decimal

from kernel.persistence import session_kwargs
from modules.billing.domain.models import (
    CENTS,
    FolioEntity,
    FolioTransaction,
)
from modules.billing.domain.repository import FolioRepository

FOLIOS_COLLECTION = "folios"
TXNS_COLLECTION = "folio_transactions"


class MongoFolioRepository(FolioRepository):
    """تنفيذ Mongo لـ FolioRepository — append-only ledger."""

    def __init__(self, db) -> None:
        self._folios = db[FOLIOS_COLLECTION]
        self._txns = db[TXNS_COLLECTION]

    # ── Mappers (Decimal ↔ str لتجنّب فقدان الدقّة في Mongo) ──
    @staticmethod
    def _txn_to_doc(t: FolioTransaction) -> dict:
        """يخزّن الـ Decimal كـ string لتفادي تحويل Mongo التلقائي إلى float."""
        return {
            "id": t.id,
            "folio_id": t.folio_id,
            "type": t.type,
            "subtype": t.subtype,
            "amount": str(t.amount),
            "currency": t.currency,
            "description": t.description,
            "business_date": t.business_date,
            "posted_by": t.posted_by,
            "posted_at": t.posted_at,
            "tax_amount": str(t.tax_amount),
            "tax_breakdown": list(t.tax_breakdown),
            "discounts": list(t.discounts),
            "charge_code": t.charge_code,
            "reference_id": t.reference_id,
            "posted_to_window_id": t.posted_to_window_id,
            "linked_txn_id": t.linked_txn_id,
            "is_void": t.is_void,
            "reversed_by": t.reversed_by,
            "reversed_at": t.reversed_at,
            "reversal_txn_id": t.reversal_txn_id,
            "idempotency_key": t.idempotency_key,
            "source": t.source,
        }

    @staticmethod
    def _doc_to_txn(d: dict) -> FolioTransaction:
        return FolioTransaction(
            id=d["id"],
            folio_id=d["folio_id"],
            type=d["type"],
            subtype=d["subtype"],
            amount=Decimal(d["amount"]).quantize(CENTS),
            currency=d["currency"],
            description=d.get("description", ""),
            business_date=d.get("business_date", ""),
            posted_by=d.get("posted_by", ""),
            posted_at=d.get("posted_at", ""),
            tax_amount=Decimal(d.get("tax_amount", "0.00")).quantize(CENTS),
            tax_breakdown=tuple(tuple(x) for x in d.get("tax_breakdown", [])),
            discounts=tuple(d.get("discounts", [])),
            charge_code=d.get("charge_code"),
            reference_id=d.get("reference_id"),
            posted_to_window_id=d.get("posted_to_window_id"),
            linked_txn_id=d.get("linked_txn_id"),
            is_void=bool(d.get("is_void", False)),
            reversed_by=d.get("reversed_by"),
            reversed_at=d.get("reversed_at"),
            reversal_txn_id=d.get("reversal_txn_id"),
            idempotency_key=d.get("idempotency_key"),
            source=d.get("source", "manual"),
        )

    @staticmethod
    def _folio_head_to_doc(f: FolioEntity) -> dict:
        """رأس الفاتورة فقط — القيود في collection منفصل."""
        return {
            "id": f.id,
            "checkin_id": f.checkin_id,
            "room_number": f.room_number,
            "guest_name": f.guest_name,
            "folio_type": f.folio_type,
            "status": f.status,
            "currency": f.currency,
            "business_date": f.business_date,
            "tenant_id": f.tenant_id,
            "property_id": f.property_id,
        }

    # ── ① get: تحميل الـ aggregate كاملاً (رأس + كل القيود) ──
    async def get(self, folio_id: str) -> FolioEntity | None:
        head = await self._folios.find_one({"id": folio_id}, {"_id": 0})
        if head is None:
            return None
        return await self._hydrate(head)

    # ── ② get_master_for_checkin: للبحث عن الفاتورة الرئيسية ──
    async def get_master_for_checkin(self, checkin_id: str) -> FolioEntity | None:
        head = await self._folios.find_one(
            {"checkin_id": checkin_id, "folio_type": "master"}, {"_id": 0})
        if head is None:
            return None
        return await self._hydrate(head)

    async def _hydrate(self, head: dict) -> FolioEntity:
        """يُعيد بناء الـ aggregate من رأس + كل قيوده (مرتّبة بـ posted_at)."""
        txn_docs = await (self._txns
                          .find({"folio_id": head["id"]}, {"_id": 0})
                          .sort("posted_at", 1)
                          .to_list(10000))
        folio = FolioEntity(
            id=head["id"],
            checkin_id=head["checkin_id"],
            room_number=head["room_number"],
            guest_name=head.get("guest_name", ""),
            folio_type=head.get("folio_type", "master"),
            status=head.get("status", "open"),
            currency=head.get("currency", "YER"),
            business_date=head.get("business_date", ""),
            tenant_id=head.get("tenant_id", "default"),
            property_id=head.get("property_id", "main"),
        )
        # نُحمّل القيود مباشرة في الدفتر الخاص (لا عبر post — تجاوز
        # invariants سليم هنا لأننا نُعيد بناء aggregate من مصدره الموثوق).
        folio._transactions = [self._doc_to_txn(d) for d in txn_docs]
        return folio

    # ── ③ save: append-only + تحديث رأس + reversal markers فقط ──
    async def save(self, folio: FolioEntity, uow=None) -> FolioEntity:
        """يحفظ التغييرات بحيث يحرس الـ append-only على مستوى التخزين.

        المنطق:
          1. رأس الفاتورة: upsert (status/business_date قابلة للتغيير).
          2. القيود الجديدة: insert (تُعرَف بـ id غير موجود في DB).
          3. القيود الموسومة void: update لحقول الـ reversal فقط
             (amount/type يبقيان كما هما — يحرسه الـ $set المحدود).
        """
        kw = session_kwargs(uow)
        # 1) رأس الفاتورة
        await self._folios.update_one(
            {"id": folio.id},
            {"$set": self._folio_head_to_doc(folio)},
            upsert=True, **kw,
        )

        # 2+3) القيود: نُقارن مع DB لتحديد الجديد vs المُعدَّل (للـ reversal)
        existing_ids = set()
        async for d in self._txns.find(
                {"folio_id": folio.id}, {"_id": 0, "id": 1, "is_void": 1}):
            existing_ids.add(d["id"])

        for t in folio.transactions:
            if t.id not in existing_ids:
                # قيد جديد → insert كامل
                await self._txns.insert_one(self._txn_to_doc(t), **kw)
            elif t.is_void:
                # قيد موجود وأصبح void → update لحقول reversal فقط
                # (amount/type/posted_at لا تُلمَس — Immutability محفوظة)
                await self._txns.update_one(
                    {"id": t.id, "folio_id": folio.id},
                    {"$set": {
                        "is_void": True,
                        "reversed_by": t.reversed_by,
                        "reversed_at": t.reversed_at,
                        "reversal_txn_id": t.reversal_txn_id,
                    }},
                    **kw,
                )
        return folio

    # ── ④ find_txn_by_idempotency_key — fail-fast قبل تحميل الـ aggregate ──
    async def find_txn_by_idempotency_key(self, key: str) -> FolioTransaction | None:
        if not key:
            return None
        doc = await self._txns.find_one({"idempotency_key": key}, {"_id": 0})
        return self._doc_to_txn(doc) if doc else None


    async def list_scoped(self, scoped_filter: dict, *, limit: int = 200) -> list[FolioEntity]:
        limit = max(1, min(int(limit), 1000))
        heads = await self._folios.find(scoped_filter or {}, {"_id": 0}).sort("business_date", -1).to_list(limit)
        return [await self._hydrate(h) for h in heads]
