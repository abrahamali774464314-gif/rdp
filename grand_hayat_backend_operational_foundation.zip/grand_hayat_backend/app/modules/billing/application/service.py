"""
modules.billing.application.service — تنسيق العمليات المالية
═══════════════════════════════════════════════════════════════════

طبقة الـ application لمجال Billing. مسؤوليتها الوحيدة: orchestration —
استقبال أمر (Command)، تحميل aggregate من repository، استدعاء سلوك domain،
حفظ التغييرات، نشر الأحداث.

الـ Domain هو المرجع الوحيد للقواعد المالية:
  - immutability (FolioTransaction frozen)
  - idempotency داخل الـ aggregate (post يفحص idempotency_key)
  - reversal فقط (لا حذف، لا تعديل)
  - quantization مركزي (_money / CENTS / ROUND_HALF_UP)
  - FSM (open/closed/disputed)

الـ Application يضيف:
  - بناء الـ Commands (DTOs)
  - بناء الـ Transaction id (UUID)
  - فحص idempotency عبر الطلبات (find_txn_by_idempotency_key قبل البدء)
  - تحميل/حفظ عبر repository
  - نشر الأحداث على الـ bus

ممنوع هنا:
  - DB access (يمرّ عبر repository فقط)
  - منطق محاسبي (في domain فقط)
  - I/O خارجي
"""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from decimal import Decimal

from kernel.bus import EventBus
from kernel.clock import now_iso
from kernel.contracts import DomainEvent
from kernel.errors import InvariantViolationError, NotFoundError
from modules.billing.domain.events import FolioOpened
from modules.billing.domain.models import (
    CENTS,
    FolioEntity,
    FolioTransaction,
    _money,
)
from modules.billing.domain.repository import FolioRepository

logger = logging.getLogger("grandhayat.billing")


# ══════════════════════════════════════════════════════════════
# Commands — DTOs مالية صريحة (Idempotency-aware)
# ══════════════════════════════════════════════════════════════
# المبالغ في الـ Commands تأتي كنصوص أو Decimal — الـ application يطبّع
# عبر _money() قبل تمريرها للـ domain. هذا يضمن انضباط الـ quantization.

@dataclass(frozen=True)
class OpenFolio:
    """فتح فاتورة جديدة لتسكين."""
    checkin_id: str
    room_number: int
    guest_name: str
    business_date: str
    currency: str = "YER"
    folio_type: str = "master"
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class PostCharge:
    """ترحيل مبلغ مدين (رسم خدمة، إيجار غرفة، ...)."""
    folio_id: str
    subtype: str                  # room_rate | minibar | laundry | ...
    amount: str                   # نص → Decimal مضبوط (لا float)
    description: str
    posted_by: str
    business_date: str
    charge_code: str | None = None
    tax_amount: str = "0.00"
    idempotency_key: str | None = None  # ← يحمي من الترحيل المزدوج


@dataclass(frozen=True)
class PostPayment:
    """ترحيل مبلغ دائن (دفع نقدي/بطاقة/...)"""
    folio_id: str
    subtype: str                  # cash | card | transfer | ...
    amount: str
    description: str
    posted_by: str
    business_date: str
    reference_id: str | None = None
    idempotency_key: str | None = None


@dataclass(frozen=True)
class ApplyDiscount:
    """تطبيق خصم على فاتورة."""
    folio_id: str
    subtype: str                  # promo | manager_override | loyalty
    amount: str
    description: str
    posted_by: str
    business_date: str
    idempotency_key: str | None = None


@dataclass(frozen=True)
class ReverseTransaction:
    """عكس قيد (إنشاء قيد عكسي + وسم الأصلي)."""
    folio_id: str
    original_txn_id: str
    reason: str
    posted_by: str
    business_date: str
    idempotency_key: str | None = None


@dataclass(frozen=True)
class CloseFolio:
    """إغلاق فاتورة (تتطلّب رصيداً صفرياً، أو force من admin)."""
    folio_id: str
    closed_by: str
    force: bool = False
    is_admin: bool = False


@dataclass(frozen=True)
class ReopenFolio:
    """إعادة فتح (admin فقط)."""
    folio_id: str
    reopened_by: str
    is_admin: bool


# ══════════════════════════════════════════════════════════════
# BillingApplicationService — Orchestration فقط
# ══════════════════════════════════════════════════════════════
class BillingApplicationService:
    """ينسّق العمليات المالية. لا منطق محاسبي هنا — كله في الـ domain."""

    def __init__(self, *, folios: FolioRepository, uow_factory,
                 bus: EventBus) -> None:
        self._folios = folios
        self._uow_factory = uow_factory
        self._bus = bus


    async def list_for(self, actor, *, base_query: dict | None = None, limit: int = 200):
        q = dict(base_query or {})
        if getattr(actor, "role", "") != "super_admin":
            q["tenant_id"] = actor.tenant_id or "default"
            q["property_id"] = actor.active_property_id or "main"
        return await self._folios.list_scoped(q, limit=limit)

    # ── ① فتح فاتورة جديدة ────────────────────────────────────
    async def open_folio(self, cmd: OpenFolio) -> FolioEntity:
        """يفتح فاتورة لتسكين. idempotent على مستوى checkin (يُرجِع الموجودة)."""
        existing = await self._folios.get_master_for_checkin(cmd.checkin_id)
        if existing is not None:
            return existing  # idempotent: نفس التسكين = نفس الفاتورة

        folio = FolioEntity(
            id=str(uuid.uuid4()),
            checkin_id=cmd.checkin_id,
            room_number=cmd.room_number,
            guest_name=cmd.guest_name,
            folio_type=cmd.folio_type,
            currency=cmd.currency,
            business_date=cmd.business_date,
            tenant_id=cmd.tenant_id,
            property_id=cmd.property_id,
        )
        folio._events.append(FolioOpened(
            folio_id=folio.id, checkin_id=cmd.checkin_id,
            room_number=cmd.room_number))

        async with self._uow_factory() as uow:
            await self._folios.save(folio, uow=uow)
        await self._publish_events(folio)
        logger.info("folio opened: %s (checkin=%s)", folio.id, cmd.checkin_id)
        return folio

    # ── ② ترحيل قيود (charge/payment/discount) ────────────────
    async def post_charge(self, cmd: PostCharge) -> FolioTransaction:
        return await self._post(cmd, txn_type="charge",
                                charge_code=cmd.charge_code,
                                tax_amount=cmd.tax_amount)

    async def post_payment(self, cmd: PostPayment) -> FolioTransaction:
        return await self._post(cmd, txn_type="payment",
                                reference_id=cmd.reference_id)

    async def apply_discount(self, cmd: ApplyDiscount) -> FolioTransaction:
        return await self._post(cmd, txn_type="discount")

    async def _post(self, cmd, *, txn_type: str,
                    charge_code: str | None = None,
                    tax_amount: str = "0.00",
                    reference_id: str | None = None) -> FolioTransaction:
        """مسار الترحيل الموحّد: fast-path idempotency → load → post → save."""
        # fast-path: فحص idempotency عبر الـ DB قبل تحميل الـ aggregate
        if cmd.idempotency_key:
            existing = await self._folios.find_txn_by_idempotency_key(
                cmd.idempotency_key)
            if existing is not None:
                return existing  # نفس المفتاح = نفس القيد (لا ترحيل مكرّر)

        folio = await self._load_or_raise(cmd.folio_id)
        amount_dec = _money(cmd.amount)
        if amount_dec <= Decimal("0.00"):
            raise InvariantViolationError("المبلغ يجب أن يكون موجباً")

        txn = FolioTransaction(
            id=str(uuid.uuid4()),
            folio_id=folio.id,
            type=txn_type,
            subtype=cmd.subtype,
            amount=amount_dec,
            currency=folio.currency,
            description=cmd.description,
            business_date=cmd.business_date,
            posted_by=cmd.posted_by,
            posted_at=now_iso(),
            tax_amount=_money(tax_amount),
            charge_code=charge_code,
            reference_id=reference_id,
            idempotency_key=cmd.idempotency_key,
        )

        # الـ Domain يحرس: open + idempotency داخل الـ aggregate + invariants
        result = folio.post(txn)

        async with self._uow_factory() as uow:
            await self._folios.save(folio, uow=uow)
        await self._publish_events(folio)
        return result

    # ── ③ عكس قيد (Reversal — لا تعديل، لا حذف) ───────────────
    async def reverse_transaction(self, cmd: ReverseTransaction) -> FolioTransaction:
        if cmd.idempotency_key:
            existing = await self._folios.find_txn_by_idempotency_key(
                cmd.idempotency_key)
            if existing is not None:
                return existing

        folio = await self._load_or_raise(cmd.folio_id)
        # نجد القيد الأصلي عبر الـ aggregate (مصدر الحقيقة)
        original = next(
            (t for t in folio.transactions if t.id == cmd.original_txn_id),
            None)
        if original is None:
            raise NotFoundError(f"القيد الأصلي غير موجود: {cmd.original_txn_id}")

        # القيد العكسي: audit-only reversal بنفس المبلغ، يشير للأصلي.
        # التأثير المالي يلغى عبر وسم الأصلي is_void=True، لذلك source=reversal
        # لا يدخل في balance لتجنب احتساب مزدوج.
        reversal = FolioTransaction(
            id=str(uuid.uuid4()),
            folio_id=folio.id,
            type=self._reversal_type_for(original.type),
            subtype=f"reversal_{original.subtype}",
            amount=original.amount,
            currency=folio.currency,
            description=f"عكس قيد {cmd.original_txn_id}: {cmd.reason}",
            business_date=cmd.business_date,
            posted_by=cmd.posted_by,
            posted_at=now_iso(),
            linked_txn_id=original.id,
            idempotency_key=cmd.idempotency_key,
            source="reversal",
        )

        result = folio.reverse(original.id, reversal)
        async with self._uow_factory() as uow:
            await self._folios.save(folio, uow=uow)
        await self._publish_events(folio)
        return result

    @staticmethod
    def _reversal_type_for(original_type: str) -> str:
        """يُحدّد نوع القيد العكسي ليُلغي تأثير الأصلي على الرصيد."""
        # charge (مدين) ← يُعكس بـ payment (دائن) بنفس المبلغ
        # payment/discount (دائن) ← يُعكس بـ charge (مدين)
        if original_type == "charge":
            return "payment"
        if original_type in ("payment", "discount"):
            return "charge"
        return "adjustment"

    # ── ④ إغلاق / إعادة فتح ───────────────────────────────────
    async def close_folio(self, cmd: CloseFolio) -> FolioEntity:
        folio = await self._load_or_raise(cmd.folio_id)
        folio.close(force=cmd.force, is_admin=cmd.is_admin)
        async with self._uow_factory() as uow:
            await self._folios.save(folio, uow=uow)
        await self._publish_events(folio)
        logger.info("folio closed: %s (balance=%s)", folio.id, folio.balance())
        return folio

    async def reopen_folio(self, cmd: ReopenFolio) -> FolioEntity:
        folio = await self._load_or_raise(cmd.folio_id)
        folio.reopen(is_admin=cmd.is_admin)
        async with self._uow_factory() as uow:
            await self._folios.save(folio, uow=uow)
        await self._publish_events(folio)
        return folio

    # ── ⑤ قراءة الرصيد (للقارئ في الـ container) ─────────────
    async def get_balance(self, folio_id: str) -> Decimal:
        """رصيد فاتورة (مدين موجب)."""
        folio = await self._folios.get(folio_id)
        if folio is None:
            raise NotFoundError(f"الفاتورة غير موجودة: {folio_id}")
        return folio.balance()

    async def get_balance_for_checkin(self, checkin_id: str) -> Decimal:
        """رصيد فاتورة تسكين (للقارئ في الـ container — checkouts يستخدمه)."""
        folio = await self._folios.get_master_for_checkin(checkin_id)
        if folio is None:
            return Decimal("0.00")  # لا فاتورة = لا رصيد
        return folio.balance()

    # ── Helpers ───────────────────────────────────────────────
    async def _load_or_raise(self, folio_id: str) -> FolioEntity:
        folio = await self._folios.get(folio_id)
        if folio is None:
            raise NotFoundError(f"الفاتورة غير موجودة: {folio_id}")
        return folio

    async def _publish_events(self, folio: FolioEntity) -> None:
        events = folio.pull_events()
        if events:
            await self._bus.publish_all(events)
