from __future__ import annotations
from fastapi import APIRouter, Depends, Query, status
from pydantic import BaseModel, Field
from kernel.security.query_scoper import Actor
from modules.billing.application.service import ApplyDiscount, CloseFolio, OpenFolio, PostCharge, PostPayment, ReopenFolio, ReverseTransaction
from shared.auth.dependencies import require_permission
from shared.config.container import container

router = APIRouter(prefix="/billing", tags=["billing"])

class OpenFolioBody(BaseModel):
    checkin_id: str
    room_number: int
    guest_name: str
    business_date: str
    currency: str = "YER"
    folio_type: str = "master"

class TxnBody(BaseModel):
    subtype: str
    amount: str
    description: str = ""
    business_date: str
    idempotency_key: str | None = None
    reference_id: str | None = None
    charge_code: str | None = None
    tax_amount: str = "0.00"

class ReverseBody(BaseModel):
    original_txn_id: str
    reason: str = ""
    business_date: str
    idempotency_key: str | None = None

class CloseBody(BaseModel):
    force: bool = False

def _folio_to_dict(f) -> dict:
    return {"id": f.id, "checkin_id": f.checkin_id, "room_number": f.room_number, "guest_name": f.guest_name, "folio_type": f.folio_type, "status": f.status, "currency": f.currency, "business_date": f.business_date, "balance": str(f.balance()), "transactions": [{"id": t.id, "type": t.type, "subtype": t.subtype, "amount": str(t.amount), "description": t.description, "business_date": t.business_date, "is_void": t.is_void, "source": t.source} for t in f.transactions], "tenant_id": f.tenant_id, "property_id": f.property_id}

def _txn_to_dict(t) -> dict:
    return {"id": t.id, "folio_id": t.folio_id, "type": t.type, "subtype": t.subtype, "amount": str(t.amount), "description": t.description, "business_date": t.business_date, "is_void": t.is_void, "source": t.source, "idempotency_key": t.idempotency_key}

@router.get("/folios")
async def list_folios(status: str | None = Query(default=None), actor: Actor = Depends(require_permission("view_billing"))):
    base = {"status": status} if status else None
    return [_folio_to_dict(f) for f in await container.billing.list_for(actor, base_query=base)]

@router.post("/folios", status_code=status.HTTP_201_CREATED)
async def open_folio(body: OpenFolioBody, actor: Actor = Depends(require_permission("manage_billing"))):
    folio = await container.billing.open_folio(OpenFolio(tenant_id=actor.tenant_id or "default", property_id=actor.active_property_id or "main", **body.model_dump()))
    return _folio_to_dict(folio)

@router.post("/folios/{folio_id}/charges")
async def post_charge(folio_id: str, body: TxnBody, actor: Actor = Depends(require_permission("manage_billing"))):
    txn = await container.billing.post_charge(PostCharge(folio_id=folio_id, posted_by=actor.id, subtype=body.subtype, amount=body.amount, description=body.description, business_date=body.business_date, charge_code=body.charge_code, tax_amount=body.tax_amount, idempotency_key=body.idempotency_key))
    return _txn_to_dict(txn)

@router.post("/folios/{folio_id}/payments")
async def post_payment(folio_id: str, body: TxnBody, actor: Actor = Depends(require_permission("manage_billing"))):
    txn = await container.billing.post_payment(PostPayment(folio_id=folio_id, posted_by=actor.id, subtype=body.subtype, amount=body.amount, description=body.description, business_date=body.business_date, reference_id=body.reference_id, idempotency_key=body.idempotency_key))
    return _txn_to_dict(txn)

@router.post("/folios/{folio_id}/discounts")
async def apply_discount(folio_id: str, body: TxnBody, actor: Actor = Depends(require_permission("manage_billing"))):
    txn = await container.billing.apply_discount(ApplyDiscount(folio_id=folio_id, posted_by=actor.id, subtype=body.subtype, amount=body.amount, description=body.description, business_date=body.business_date, idempotency_key=body.idempotency_key))
    return _txn_to_dict(txn)

@router.post("/folios/{folio_id}/reverse")
async def reverse_transaction(folio_id: str, body: ReverseBody, actor: Actor = Depends(require_permission("manage_billing"))):
    txn = await container.billing.reverse_transaction(ReverseTransaction(folio_id=folio_id, original_txn_id=body.original_txn_id, reason=body.reason, posted_by=actor.id, business_date=body.business_date, idempotency_key=body.idempotency_key))
    return _txn_to_dict(txn)

@router.post("/folios/{folio_id}/close")
async def close_folio(folio_id: str, body: CloseBody, actor: Actor = Depends(require_permission("manage_billing"))):
    folio = await container.billing.close_folio(CloseFolio(folio_id=folio_id, closed_by=actor.id, force=body.force, is_admin=actor.role in {"super_admin", "admin"}))
    return _folio_to_dict(folio)

@router.post("/folios/{folio_id}/reopen")
async def reopen_folio(folio_id: str, actor: Actor = Depends(require_permission("manage_billing"))):
    folio = await container.billing.reopen_folio(ReopenFolio(folio_id=folio_id, reopened_by=actor.id, is_admin=actor.role in {"super_admin", "admin"}))
    return _folio_to_dict(folio)
