from __future__ import annotations
from fastapi import APIRouter, Depends, Query, status
from pydantic import BaseModel, Field
from kernel.security.query_scoper import Actor
from modules.checkouts.application.service import CancelCheckout, CreateCheckout, ProcessCheckout
from shared.auth.dependencies import require_permission
from shared.config.container import container

router = APIRouter(prefix="/checkouts", tags=["checkouts"])

class CheckoutBody(BaseModel):
    room_number: int = Field(ge=1)
    floor: int = Field(ge=1)
    checkin_id: str | None = None
    guest_name: str | None = None
    guest_phone: str | None = None
    checklist_labels: list[str] = Field(default_factory=list)
    note: str = ""

class CheckoutProcessBody(BaseModel):
    checklist: list[tuple[str, bool]] = Field(default_factory=list)
    decision: str = "ready_for_cleaning"
    note: str | None = None

def _checkout_to_dict(c) -> dict:
    return {"id": c.id, "room_number": c.room_number, "floor": c.floor, "checkin_id": c.checkin_id, "guest_name": c.guest_name, "guest_phone": c.guest_phone, "status": c.status, "note": c.note, "checklist": [{"label": x.label, "done": x.done} for x in c.checklist], "final_balance": str(c.final_balance), "decision": c.decision, "created_by": c.created_by, "processed_by": c.processed_by, "processed_at": c.processed_at, "tenant_id": c.tenant_id, "property_id": c.property_id}

@router.get("")
async def list_checkouts(status: str | None = Query(default=None), actor: Actor = Depends(require_permission("view_checkout"))):
    base = {"status": status} if status else None
    return [_checkout_to_dict(c) for c in await container.checkouts.list_for(actor, base_query=base)]

@router.post("", status_code=status.HTTP_201_CREATED)
async def create_checkout(body: CheckoutBody, actor: Actor = Depends(require_permission("create_checkout"))):
    result = await container.checkouts.create(CreateCheckout(tenant_id=actor.tenant_id or "default", property_id=actor.active_property_id or "main", actor_id=actor.id, actor_name=actor.name, actor=actor, checklist_labels=tuple(body.checklist_labels), room_number=body.room_number, floor=body.floor, checkin_id=body.checkin_id, guest_name=body.guest_name, guest_phone=body.guest_phone, note=body.note))
    return _checkout_to_dict(result.data)

@router.post("/{checkout_id}/process")
async def process_checkout(checkout_id: str, body: CheckoutProcessBody, actor: Actor = Depends(require_permission("process_checkout"))):
    result = await container.checkouts.process(ProcessCheckout(checkout_id=checkout_id, checklist=tuple((str(a), bool(b)) for a, b in body.checklist), decision=body.decision, note=body.note, actor_id=actor.id, actor_name=actor.name, actor=actor))
    return _checkout_to_dict(result.data)

@router.post("/{checkout_id}/cancel")
async def cancel_checkout(checkout_id: str, actor: Actor = Depends(require_permission("process_checkout"))):
    result = await container.checkouts.cancel(CancelCheckout(checkout_id=checkout_id, actor_id=actor.id, actor=actor))
    return _checkout_to_dict(result.data)
