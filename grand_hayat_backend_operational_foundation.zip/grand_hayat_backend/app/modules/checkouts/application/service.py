"""Application service for checkout workflows."""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from decimal import Decimal
from typing import Protocol

from kernel.bus import EventBus
from kernel.clock import now_iso
from kernel.contracts import Command, Result
from kernel.errors import ConflictError, NotFoundError, PermissionDeniedError
from kernel.security.query_scoper import Actor
from kernel.security.scoping_rules import is_floor_allowed
from kernel.text import sanitize

from modules.checkouts.domain.events import CheckoutCreated
from modules.checkouts.domain.models import (
    ChecklistItem,
    CheckoutEntity,
    DECISION_READY_FOR_CLEANING,
)
from modules.checkouts.domain.repository import CheckoutRepository

logger = logging.getLogger("grandhayat.checkouts")


class FolioBalancePort(Protocol):
    async def current_balance(self, checkin_id: str) -> Decimal: ...


@dataclass(frozen=True)
class CreateCheckout(Command):
    room_number: int
    floor: int
    checkin_id: str | None
    guest_name: str | None
    guest_phone: str | None
    checklist_labels: tuple[str, ...]
    note: str
    actor_id: str
    actor_name: str
    tenant_id: str = "default"
    property_id: str = "main"
    actor: Actor | None = None


@dataclass(frozen=True)
class ProcessCheckout(Command):
    checkout_id: str
    checklist: tuple[tuple[str, bool], ...]
    decision: str
    note: str | None
    actor_id: str
    actor_name: str
    actor: Actor | None = None


@dataclass(frozen=True)
class CancelCheckout(Command):
    checkout_id: str
    actor_id: str
    actor: Actor | None = None


class CheckoutApplicationService:
    def __init__(self, *, checkouts: CheckoutRepository, uow_factory,
                 bus: EventBus, balance_port: FolioBalancePort) -> None:
        self._checkouts = checkouts
        self._uow_factory = uow_factory
        self._bus = bus
        self._balance = balance_port

    async def list_for(self, actor, *, own_only: bool = False,
                       base_query: dict | None = None,
                       limit: int | None = None):
        from shared.security.scoped_listing import scoped_list
        rules = getattr(self, "_scoping_rules", None)
        if rules is None:
            from kernel.security.scoping_rules import ScopingRules
            rules = ScopingRules()
        scoper = getattr(self, "_scoper", None)
        return await scoped_list(
            self._checkouts, lambda a: rules.for_checkouts(a, own_only=own_only), actor,
            scoper=scoper, base_query=base_query, limit=limit,
        )

    @staticmethod
    def _ensure_actor_can_access(entity: CheckoutEntity, actor: Actor | None) -> None:
        if actor is None:
            return
        if actor.tenant_id and entity.tenant_id != actor.tenant_id:
            raise PermissionDeniedError("لا يمكنك الوصول إلى بيانات Tenant آخر")
        if actor.active_property_id and entity.property_id != actor.active_property_id:
            raise PermissionDeniedError("لا يمكنك الوصول إلى بيانات فندق/عقار آخر")
        if not is_floor_allowed(actor, entity.floor):
            raise PermissionDeniedError("ليست لديك صلاحية لهذا الدور")

    async def create(self, cmd: CreateCheckout) -> Result:
        if cmd.actor and not is_floor_allowed(cmd.actor, cmd.floor):
            raise PermissionDeniedError("ليست لديك صلاحية لهذا الدور")
        existing = await self._checkouts.find_open_by_room(
            cmd.room_number, tenant_id=cmd.tenant_id, property_id=cmd.property_id,
        )
        if existing:
            raise ConflictError("يوجد طلب مغادرة مفتوح لهذه الغرفة")

        entity = CheckoutEntity(
            id=str(uuid.uuid4()),
            room_number=cmd.room_number,
            floor=cmd.floor,
            checkin_id=cmd.checkin_id,
            guest_name=cmd.guest_name,
            guest_phone=cmd.guest_phone,
            note=sanitize(cmd.note, 1000) or "",
            created_by=cmd.actor_id,
            created_by_name=cmd.actor_name,
            tenant_id=cmd.tenant_id,
            property_id=cmd.property_id,
        )
        items = [ChecklistItem(label=sanitize(lbl, 120), done=False)
                 for lbl in cmd.checklist_labels if (lbl or "").strip()]
        entity.initialise(items)
        entity._events.append(CheckoutCreated(
            checkout_id=entity.id, room_number=entity.room_number, floor=entity.floor,
            tenant_id=entity.tenant_id, property_id=entity.property_id,
        ))

        async with self._uow_factory() as uow:
            await self._checkouts.add(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)

    async def process(self, cmd: ProcessCheckout) -> Result:
        entity = await self._checkouts.get(cmd.checkout_id)
        if not entity:
            raise NotFoundError("طلب المغادرة غير موجود")
        self._ensure_actor_can_access(entity, cmd.actor)

        final_balance = Decimal("0.00")
        if entity.checkin_id:
            final_balance = await self._balance.current_balance(entity.checkin_id)
        if final_balance > Decimal("0.00"):
            raise ConflictError("لا يمكن إكمال المغادرة قبل تسوية الرصيد المستحق")

        items = [ChecklistItem(label=sanitize(lbl, 120), done=bool(done))
                 for (lbl, done) in cmd.checklist]
        entity.process(
            items=items,
            decision=cmd.decision or DECISION_READY_FOR_CLEANING,
            by=cmd.actor_id,
            by_name=cmd.actor_name,
            at=now_iso(),
            final_balance=final_balance,
            note=sanitize(cmd.note, 1000) if cmd.note is not None else None,
        )

        async with self._uow_factory() as uow:
            await self._checkouts.save(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)

    async def cancel(self, cmd: CancelCheckout) -> Result:
        entity = await self._checkouts.get(cmd.checkout_id)
        if not entity:
            raise NotFoundError("طلب المغادرة غير موجود")
        self._ensure_actor_can_access(entity, cmd.actor)
        entity.cancel()
        async with self._uow_factory() as uow:
            await self._checkouts.save(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)


class CheckoutEventSubscribers:
    def __init__(self, *, checkin_checkout_handler) -> None:
        self._handle = checkin_checkout_handler

    def register(self, bus: EventBus) -> None:
        bus.subscribe("checkouts.completed", self._on_completed)

    async def _on_completed(self, event) -> None:
        if event.checkin_id:
            await self._handle(event.checkin_id, event.checkout_id)
