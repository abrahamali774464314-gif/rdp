"""
modules.checkouts.domain.repository — واجهة مستودع المغادرة
═══════════════════════════════════════════════════════════════════

Repository Law (البند 4): الـ application يعتمد على هذا Protocol فقط.
التنفيذ في infrastructure ويترجم CheckoutEntity ⇄ مستند MongoDB.
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable

from modules.checkouts.domain.models import CheckoutEntity


@runtime_checkable
class CheckoutRepository(Protocol):
    """عقد تخزين طلبات المغادرة."""

    async def get(self, checkout_id: str) -> CheckoutEntity | None:
        """يجلب طلب مغادرة بمعرّفه."""
        ...

    async def add(self, checkout: CheckoutEntity, uow=None) -> CheckoutEntity:
        """يُدرج طلب مغادرة جديد."""
        ...

    async def save(self, checkout: CheckoutEntity, uow=None) -> CheckoutEntity:
        """يحدّث طلب مغادرة قائم (معالجة/إلغاء)."""
        ...

    async def find_open_by_room(
        self, room_number: int, *, tenant_id: str | None = None, property_id: str | None = None
    ) -> CheckoutEntity | None:
        """يجلب طلب المغادرة المفتوح لغرفة (pending/in_progress)."""
        ...
