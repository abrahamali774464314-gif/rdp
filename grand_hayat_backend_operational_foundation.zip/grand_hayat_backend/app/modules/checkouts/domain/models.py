"""
modules.checkouts.domain.models — كيان المغادرة وسلوكها
═══════════════════════════════════════════════════════════════════

Domain Ownership: يملك سجلّ المغادرة (الـ checklist + حالته) فقط.
لا يلمس rooms ولا billing ولا checkins — ينشر أحداثاً، وهم يستجيبون.

منطق المجال الأصيل المنقول من الـ service القديم إلى هنا:
  - اكتمال كل بنود الـ checklist ⇒ الحالة completed
  - عند الاكتمال: تُترجم decision إلى الحدث المناسب (cleaning / maintenance)

القرار (decision) يأتي من تقرير الفحص خارجياً ويُمرَّر كوسيط — المجال
لا يقرأ تقارير الفحص بنفسه (يبقى ضمن ملكيته).

استخدام Decimal للرصيد النهائي (يُمرَّر من مجال billing عبر الأمر).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP

from kernel.contracts import DomainEvent, Entity
from kernel.errors import ConflictError, InvariantViolationError
from kernel.state_machine import StateMachine

from modules.checkouts.domain.events import (
    CheckoutCancelled,
    CheckoutCompleted,
    CheckoutCompletedNeedsMaintenance,
    CheckoutCompletedReadyForCleaning,
)

CENTS = Decimal("0.01")
ZERO = Decimal("0.00")

# القرارات الممكنة من تقرير الفحص
DECISION_READY_FOR_CLEANING = "ready_for_cleaning"
DECISION_NEEDS_MAINTENANCE = "maintenance_required"
VALID_DECISIONS = frozenset({DECISION_READY_FOR_CLEANING, DECISION_NEEDS_MAINTENANCE})


# ══════════════════════════════════════════════════════════════
# State Machine — دورة حياة المغادرة
# ══════════════════════════════════════════════════════════════
CHECKOUT_FSM = StateMachine(
    name="checkout",
    transitions={
        "pending":     {"in_progress", "completed", "cancelled"},
        "in_progress": {"completed", "cancelled"},
        "completed":   set(),   # نهائية
        "cancelled":   set(),   # نهائية
    },
    terminal=frozenset({"completed", "cancelled"}),
)


# ══════════════════════════════════════════════════════════════
# Value Object — بند في قائمة المغادرة
# ══════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class ChecklistItem:
    """بند تحقّق غير قابل للتعديل. التحديث يُنتج قائمة جديدة."""
    label: str
    done: bool = False


# ══════════════════════════════════════════════════════════════
# Entity — المغادرة (Aggregate Root)
# ══════════════════════════════════════════════════════════════
@dataclass
class CheckoutEntity(Entity):
    """طلب مغادرة. يملك الـ checklist وحالته.

    Invariants:
      - الـ checklist غير فارغة عند الإنشاء
      - الاكتمال يتطلّب إنجاز كل البنود
      - لا تعديل بعد بلوغ حالة نهائية (يفرضه FSM)
    """
    id: str
    room_number: int
    floor: int
    checkin_id: str | None = None
    guest_name: str | None = None
    guest_phone: str | None = None
    status: str = "pending"
    note: str = ""
    _checklist: list[ChecklistItem] = field(default_factory=list)
    final_balance: Decimal = ZERO
    decision: str = DECISION_READY_FOR_CLEANING
    # تدقيق
    created_by: str = ""
    created_by_name: str = ""
    processed_by: str | None = None
    processed_by_name: str | None = None
    processed_at: str | None = None
    tenant_id: str = "default"
    property_id: str = "main"

    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    def pull_events(self) -> list[DomainEvent]:
        ev, self._events = self._events, []
        return ev

    @property
    def checklist(self) -> tuple[ChecklistItem, ...]:
        return tuple(self._checklist)

    # ── Invariants ────────────────────────────────────────────
    def _check_invariants(self) -> None:
        if self.room_number <= 0 or self.floor <= 0:
            raise InvariantViolationError("رقم الغرفة/الدور غير صالح")

    @property
    def _all_done(self) -> bool:
        return bool(self._checklist) and all(item.done for item in self._checklist)

    def _assert_mutable(self) -> None:
        if self.status in CHECKOUT_FSM.terminal:
            raise ConflictError("تمّت معالجة هذا الـ Checkout بالفعل")

    # ── Behaviours ────────────────────────────────────────────
    def initialise(self, items: list[ChecklistItem]) -> None:
        """يُهيّئ الـ checklist عند الإنشاء."""
        if not items:
            raise InvariantViolationError("قائمة المغادرة لا يمكن أن تكون فارغة")
        self._checklist = list(items)
        self._check_invariants()

    def process(self, *, items: list[ChecklistItem], decision: str,
                by: str, by_name: str, at: str,
                final_balance: Decimal, note: str | None = None) -> None:
        """يطبّق تحديث الـ checklist ويُكمل المغادرة إن تمّت كل البنود.

        decision يأتي من تقرير الفحص (يُمرَّر من الـ application/inspection).
        final_balance يأتي من مجال billing (يُمرَّر عبر الأمر).
        """
        self._assert_mutable()
        if decision not in VALID_DECISIONS:
            decision = DECISION_READY_FOR_CLEANING

        self._checklist = list(items)
        self.decision = decision
        self.processed_by = by
        self.processed_by_name = by_name
        self.processed_at = at
        self.final_balance = self._money(final_balance)
        if note is not None:
            self.note = note

        if self._all_done:
            self._complete()
        else:
            self.status = CHECKOUT_FSM.transition(self.status, "in_progress")

    def _complete(self) -> None:
        self.status = CHECKOUT_FSM.transition(self.status, "completed")

        # الحدث العام (للتدقيق/الإشعارات)
        self._events.append(CheckoutCompleted(
            checkout_id=self.id, room_number=self.room_number, floor=self.floor,
            checkin_id=self.checkin_id, decision=self.decision,
            final_balance=str(self.final_balance),
            tenant_id=self.tenant_id, property_id=self.property_id,
        ))

        # ترجمة القرار إلى حدث متخصّص يلتقطه مجال الغرف (+ housekeeping)
        if self.decision == DECISION_NEEDS_MAINTENANCE:
            self._events.append(CheckoutCompletedNeedsMaintenance(
                checkout_id=self.id, room_number=self.room_number, floor=self.floor,
                tenant_id=self.tenant_id, property_id=self.property_id,
            ))
        else:
            self._events.append(CheckoutCompletedReadyForCleaning(
                checkout_id=self.id, room_number=self.room_number, floor=self.floor,
                tenant_id=self.tenant_id, property_id=self.property_id,
            ))

    def cancel(self) -> None:
        self._assert_mutable()
        self.status = CHECKOUT_FSM.transition(self.status, "cancelled")
        self._events.append(CheckoutCancelled(
            checkout_id=self.id, room_number=self.room_number,
            tenant_id=self.tenant_id, property_id=self.property_id,
        ))

    # ── أدوات ─────────────────────────────────────────────────
    @staticmethod
    def _money(value) -> Decimal:
        return Decimal(str(value)).quantize(CENTS, rounding=ROUND_HALF_UP)
