"""modules.checkouts.domain.events — أحداث مجال المغادرة."""
from __future__ import annotations

from dataclasses import dataclass

from kernel.contracts import DomainEvent


@dataclass(frozen=True)
class CheckoutCreated(DomainEvent):
    topic = "checkouts.created"
    checkout_id: str = ""
    room_number: int = 0
    floor: int = 0
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class CheckoutCompleted(DomainEvent):
    topic = "checkouts.completed"
    checkout_id: str = ""
    room_number: int = 0
    floor: int = 0
    checkin_id: str | None = None
    decision: str = "ready_for_cleaning"
    final_balance: str = "0.00"
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class CheckoutCompletedReadyForCleaning(DomainEvent):
    topic = "checkouts.completed_ready_for_cleaning"
    checkout_id: str = ""
    room_number: int = 0
    floor: int = 0
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class CheckoutCompletedNeedsMaintenance(DomainEvent):
    topic = "checkouts.completed_needs_maintenance"
    checkout_id: str = ""
    room_number: int = 0
    floor: int = 0
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class CheckoutCancelled(DomainEvent):
    topic = "checkouts.cancelled"
    checkout_id: str = ""
    room_number: int = 0
    tenant_id: str = "default"
    property_id: str = "main"
