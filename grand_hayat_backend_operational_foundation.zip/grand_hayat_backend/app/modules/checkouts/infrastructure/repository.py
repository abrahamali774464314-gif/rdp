"""
modules.checkouts.infrastructure.repository — تنفيذ مستودع المغادرة
═══════════════════════════════════════════════════════════════════

الطبقة الوحيدة المسموح فيها لمس motor/db لمجال المغادرة (البند 3).
تنفّذ CheckoutRepository وتترجم CheckoutEntity ⇄ مستند MongoDB،
بما في ذلك تحويل الـ checklist (ChecklistItem ⇄ dict) والرصيد (Decimal).
"""
from __future__ import annotations

from decimal import Decimal

from kernel.persistence import session_kwargs
from shared.security.base_scoped_repository import ScopedRepositoryMixin
from modules.checkouts.domain.models import ChecklistItem, CheckoutEntity

COLLECTION = "checkouts"
OPEN_STATUSES = ["pending", "in_progress"]


class MongoCheckoutRepository(ScopedRepositoryMixin):
    _scope_sort_field = "created_at"
    _scope_sort_dir = -1
    _scope_default_limit = 300
    def __init__(self, db) -> None:
        self._col = db[COLLECTION]

    # ── Mappers ───────────────────────────────────────────────
    @staticmethod
    def _to_entity(doc: dict) -> CheckoutEntity:
        entity = CheckoutEntity(
            id=doc["id"],
            room_number=doc["room_number"],
            floor=doc["floor"],
            checkin_id=doc.get("checkin_id"),
            guest_name=doc.get("guest_name"),
            guest_phone=doc.get("guest_phone"),
            status=doc.get("status", "pending"),
            note=doc.get("note", ""),
            final_balance=Decimal(str(doc.get("final_balance", "0") or "0")),
            decision=doc.get("decision", "ready_for_cleaning"),
            created_by=doc.get("created_by", ""),
            created_by_name=doc.get("created_by_name", ""),
            processed_by=doc.get("processed_by"),
            processed_by_name=doc.get("processed_by_name"),
            processed_at=doc.get("processed_at"),
            tenant_id=doc.get("tenant_id", "default"),
            property_id=doc.get("property_id", "main"),
        )
        entity._checklist = [
            ChecklistItem(label=i.get("label", ""), done=bool(i.get("done")))
            for i in (doc.get("checklist") or [])
        ]
        return entity

    @staticmethod
    def _to_document(e: CheckoutEntity) -> dict:
        return {
            "id": e.id,
            "room_number": e.room_number,
            "floor": e.floor,
            "checkin_id": e.checkin_id,
            "guest_name": e.guest_name,
            "guest_phone": e.guest_phone,
            "status": e.status,
            "note": e.note,
            "checklist": [{"label": i.label, "done": i.done} for i in e.checklist],
            "final_balance": e.final_balance,
            "decision": e.decision,
            "created_by": e.created_by,
            "created_by_name": e.created_by_name,
            "processed_by": e.processed_by,
            "processed_by_name": e.processed_by_name,
            "processed_at": e.processed_at,
            "tenant_id": e.tenant_id,
            "property_id": e.property_id,
        }

    # ── Operations ────────────────────────────────────────────
    async def get(self, checkout_id: str) -> CheckoutEntity | None:
        doc = await self._col.find_one({"id": checkout_id}, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def add(self, checkout: CheckoutEntity, uow=None) -> CheckoutEntity:
        await self._col.insert_one(self._to_document(checkout), **session_kwargs(uow))
        return checkout

    async def save(self, checkout: CheckoutEntity, uow=None) -> CheckoutEntity:
        await self._col.update_one(
            {"id": checkout.id},
            {"$set": self._to_document(checkout)},
            **session_kwargs(uow),
        )
        return checkout

    async def find_open_by_room(
        self, room_number: int, *, tenant_id: str | None = None, property_id: str | None = None
    ) -> CheckoutEntity | None:
        query = {"room_number": room_number, "status": {"$in": OPEN_STATUSES}}
        if tenant_id:
            query["tenant_id"] = tenant_id
        if property_id:
            query["property_id"] = property_id
        doc = await self._col.find_one(query, {"_id": 0})
        return self._to_entity(doc) if doc else None
