from __future__ import annotations
from kernel.persistence import session_kwargs
from modules.guests.domain.models import GuestEntity
from modules.guests.domain.repository import GuestRepository

class MongoGuestRepository(GuestRepository):
    def __init__(self, db) -> None:
        self._col = db["guests"]

    @staticmethod
    def _to_entity(doc: dict) -> GuestEntity:
        return GuestEntity(
            id=doc["id"], full_name=doc.get("full_name", ""), phone=doc.get("phone", ""),
            tenant_id=doc.get("tenant_id", "default"), property_id=doc.get("property_id", "main"),
            email=doc.get("email", ""), nationality=doc.get("nationality", ""),
            document_type=doc.get("document_type", ""), document_number=doc.get("document_number", ""),
            notes=doc.get("notes", ""), status=doc.get("status", "active"),
            created_at=doc.get("created_at", ""), updated_at=doc.get("updated_at", ""),
            last_stay_id=doc.get("last_stay_id"),
        )

    @staticmethod
    def _to_doc(e: GuestEntity) -> dict:
        return {
            "id": e.id, "full_name": e.full_name, "phone": e.phone,
            "tenant_id": e.tenant_id, "property_id": e.property_id,
            "email": e.email, "nationality": e.nationality,
            "document_type": e.document_type, "document_number": e.document_number,
            "notes": e.notes, "status": e.status, "created_at": e.created_at,
            "updated_at": e.updated_at, "last_stay_id": e.last_stay_id,
        }

    async def get(self, guest_id: str, *, tenant_id: str | None = None, property_id: str | None = None) -> GuestEntity | None:
        q = {"id": guest_id}
        if tenant_id:
            q["tenant_id"] = tenant_id
        if property_id:
            q["property_id"] = property_id
        doc = await self._col.find_one(q, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def find_by_phone(self, phone: str, *, tenant_id: str, property_id: str) -> GuestEntity | None:
        doc = await self._col.find_one({"tenant_id": tenant_id, "property_id": property_id, "phone": phone, "status": {"$ne": "deleted"}}, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def add(self, guest: GuestEntity, uow=None) -> GuestEntity:
        await self._col.insert_one(self._to_doc(guest), **session_kwargs(uow))
        return guest

    async def save(self, guest: GuestEntity, uow=None) -> GuestEntity:
        await self._col.update_one({"id": guest.id, "tenant_id": guest.tenant_id, "property_id": guest.property_id}, {"$set": self._to_doc(guest)}, upsert=True, **session_kwargs(uow))
        return guest

    async def list_scoped(self, scoped_filter: dict, *, limit: int = 300) -> list[GuestEntity]:
        limit = max(1, min(int(limit), 1000))
        docs = await self._col.find(scoped_filter or {}, {"_id": 0}).sort("updated_at", -1).to_list(limit)
        return [self._to_entity(d) for d in docs]
