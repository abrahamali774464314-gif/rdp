from __future__ import annotations
from fastapi import APIRouter, Depends, Query, status
from pydantic import BaseModel, Field
from kernel.security.query_scoper import Actor
from modules.guests.application.service import UpsertGuest, UpdateGuest
from shared.auth.dependencies import require_permission
from shared.config.container import container

router = APIRouter(prefix="/guests", tags=["guests"])

class GuestBody(BaseModel):
    full_name: str = Field(min_length=1, max_length=120)
    phone: str = Field(min_length=3, max_length=40)
    email: str = ""
    nationality: str = ""
    document_type: str = ""
    document_number: str = ""
    notes: str = ""

class GuestPatch(BaseModel):
    full_name: str | None = None
    phone: str | None = None
    email: str | None = None
    nationality: str | None = None
    document_type: str | None = None
    document_number: str | None = None
    notes: str | None = None
    status: str | None = None

def _guest_to_dict(g) -> dict:
    return {"id": g.id, "full_name": g.full_name, "phone": g.phone, "email": g.email, "nationality": g.nationality, "document_type": g.document_type, "document_number": g.document_number, "notes": g.notes, "status": g.status, "tenant_id": g.tenant_id, "property_id": g.property_id, "last_stay_id": g.last_stay_id}

@router.get("")
async def list_guests(q: str | None = Query(default=None), actor: Actor = Depends(require_permission("view_guests"))):
    base = {"$or": [{"full_name": {"$regex": q, "$options": "i"}}, {"phone": {"$regex": q, "$options": "i"}}]} if q else None
    return [_guest_to_dict(g) for g in await container.guests.list_for(actor, base_query=base)]

@router.post("", status_code=status.HTTP_201_CREATED)
async def upsert_guest(body: GuestBody, actor: Actor = Depends(require_permission("manage_guests"))):
    result = await container.guests.upsert(UpsertGuest(tenant_id=actor.tenant_id or "default", property_id=actor.active_property_id or "main", **body.model_dump()))
    return _guest_to_dict(result.data)

@router.patch("/{guest_id}")
async def update_guest(guest_id: str, body: GuestPatch, actor: Actor = Depends(require_permission("manage_guests"))):
    result = await container.guests.update(UpdateGuest(guest_id=guest_id, tenant_id=actor.tenant_id or "default", property_id=actor.active_property_id or "main", **body.model_dump()))
    return _guest_to_dict(result.data)
