from __future__ import annotations
from dataclasses import dataclass, field
from kernel.contracts import DomainEvent, Entity
from kernel.errors import InvariantViolationError
from modules.guests.domain.events import GuestRegistered, GuestUpdated

@dataclass
class GuestEntity(Entity):
    id: str
    full_name: str
    phone: str
    tenant_id: str = "default"
    property_id: str = "main"
    email: str = ""
    nationality: str = ""
    document_type: str = ""
    document_number: str = ""
    notes: str = ""
    status: str = "active"
    created_at: str = ""
    updated_at: str = ""
    last_stay_id: str | None = None
    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    def pull_events(self) -> list[DomainEvent]:
        ev, self._events = self._events, []
        return ev

    def _check(self) -> None:
        if not (self.tenant_id or "").strip() or not (self.property_id or "").strip():
            raise InvariantViolationError("tenant_id/property_id مطلوبان")
        if not (self.full_name or "").strip():
            raise InvariantViolationError("اسم النزيل مطلوب")
        if not (self.phone or "").strip():
            raise InvariantViolationError("رقم هاتف النزيل مطلوب")
        if self.status not in {"active", "blocked", "deleted"}:
            raise InvariantViolationError("حالة النزيل غير صحيحة")

    def register(self) -> None:
        self._check()
        self._events.append(GuestRegistered(guest_id=self.id, tenant_id=self.tenant_id, property_id=self.property_id, phone=self.phone))

    def update_profile(self, *, full_name: str | None = None, phone: str | None = None,
                       email: str | None = None, nationality: str | None = None,
                       document_type: str | None = None, document_number: str | None = None,
                       notes: str | None = None, status: str | None = None,
                       updated_at: str = "") -> None:
        if full_name is not None:
            self.full_name = full_name
        if phone is not None:
            self.phone = phone
        if email is not None:
            self.email = email
        if nationality is not None:
            self.nationality = nationality
        if document_type is not None:
            self.document_type = document_type
        if document_number is not None:
            self.document_number = document_number
        if notes is not None:
            self.notes = notes
        if status is not None:
            self.status = status
        self.updated_at = updated_at or self.updated_at
        self._check()
        self._events.append(GuestUpdated(guest_id=self.id, tenant_id=self.tenant_id, property_id=self.property_id))

    def link_stay(self, checkin_id: str, *, at: str) -> None:
        self.last_stay_id = checkin_id
        self.updated_at = at
        self._events.append(GuestUpdated(guest_id=self.id, tenant_id=self.tenant_id, property_id=self.property_id))
