from __future__ import annotations
from dataclasses import dataclass
from kernel.contracts import DomainEvent

@dataclass(frozen=True)
class GuestRegistered(DomainEvent):
    guest_id: str
    tenant_id: str
    property_id: str
    phone: str
    topic = "guests.registered"

@dataclass(frozen=True)
class GuestUpdated(DomainEvent):
    guest_id: str
    tenant_id: str
    property_id: str
    topic = "guests.updated"
