from __future__ import annotations
import uuid
from dataclasses import dataclass
from kernel.bus import EventBus
from kernel.clock import now_iso
from kernel.contracts import Command, Result
from kernel.errors import ConflictError, NotFoundError
from kernel.text import sanitize
from modules.guests.domain.models import GuestEntity
from modules.guests.domain.repository import GuestRepository

@dataclass(frozen=True)
class UpsertGuest(Command):
    full_name: str
    phone: str
    tenant_id: str = "default"
    property_id: str = "main"
    email: str = ""
    nationality: str = ""
    document_type: str = ""
    document_number: str = ""
    notes: str = ""

@dataclass(frozen=True)
class UpdateGuest(Command):
    guest_id: str
    tenant_id: str
    property_id: str
    full_name: str | None = None
    phone: str | None = None
    email: str | None = None
    nationality: str | None = None
    document_type: str | None = None
    document_number: str | None = None
    notes: str | None = None
    status: str | None = None

class GuestApplicationService:
    def __init__(self, *, guests: GuestRepository, uow_factory, bus: EventBus) -> None:
        self._guests = guests
        self._uow_factory = uow_factory
        self._bus = bus

    def _scope(self, actor, base: dict | None = None) -> dict:
        q = dict(base or {})
        if getattr(actor, "role", "") != "super_admin":
            q["tenant_id"] = actor.tenant_id or "default"
            q["property_id"] = actor.active_property_id or "main"
        return q

    async def list_for(self, actor, *, base_query: dict | None = None, limit: int = 300):
        return await self._guests.list_scoped(self._scope(actor, base_query), limit=limit)

    async def get(self, guest_id: str, *, tenant_id: str, property_id: str) -> GuestEntity | None:
        return await self._guests.get(guest_id, tenant_id=tenant_id, property_id=property_id)

    async def upsert(self, cmd: UpsertGuest) -> Result:
        phone = sanitize(cmd.phone, 40) or ""
        existing = await self._guests.find_by_phone(phone, tenant_id=cmd.tenant_id, property_id=cmd.property_id)
        now = now_iso()
        if existing:
            existing.update_profile(
                full_name=sanitize(cmd.full_name, 120) or existing.full_name,
                email=sanitize(cmd.email, 160) if cmd.email is not None else None,
                nationality=sanitize(cmd.nationality, 80) if cmd.nationality is not None else None,
                document_type=sanitize(cmd.document_type, 40) if cmd.document_type is not None else None,
                document_number=sanitize(cmd.document_number, 80) if cmd.document_number is not None else None,
                notes=sanitize(cmd.notes, 1000) if cmd.notes is not None else None,
                updated_at=now,
            )
            async with self._uow_factory() as uow:
                await self._guests.save(existing, uow=uow)
            await self._bus.publish_all(existing.pull_events())
            return Result(data=existing)
        entity = GuestEntity(
            id=str(uuid.uuid4()), full_name=sanitize(cmd.full_name, 120) or "ضيف",
            phone=phone, tenant_id=cmd.tenant_id, property_id=cmd.property_id,
            email=sanitize(cmd.email, 160) or "", nationality=sanitize(cmd.nationality, 80) or "",
            document_type=sanitize(cmd.document_type, 40) or "", document_number=sanitize(cmd.document_number, 80) or "",
            notes=sanitize(cmd.notes, 1000) or "", created_at=now, updated_at=now,
        )
        entity.register()
        async with self._uow_factory() as uow:
            await self._guests.add(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)

    async def update(self, cmd: UpdateGuest) -> Result:
        entity = await self._guests.get(cmd.guest_id, tenant_id=cmd.tenant_id, property_id=cmd.property_id)
        if not entity:
            raise NotFoundError("النزيل غير موجود")
        if cmd.phone is not None:
            other = await self._guests.find_by_phone(sanitize(cmd.phone, 40) or "", tenant_id=cmd.tenant_id, property_id=cmd.property_id)
            if other and other.id != entity.id:
                raise ConflictError("رقم الهاتف مرتبط بنزيل آخر")
        entity.update_profile(
            full_name=sanitize(cmd.full_name, 120) if cmd.full_name is not None else None,
            phone=sanitize(cmd.phone, 40) if cmd.phone is not None else None,
            email=sanitize(cmd.email, 160) if cmd.email is not None else None,
            nationality=sanitize(cmd.nationality, 80) if cmd.nationality is not None else None,
            document_type=sanitize(cmd.document_type, 40) if cmd.document_type is not None else None,
            document_number=sanitize(cmd.document_number, 80) if cmd.document_number is not None else None,
            notes=sanitize(cmd.notes, 1000) if cmd.notes is not None else None,
            status=cmd.status, updated_at=now_iso(),
        )
        async with self._uow_factory() as uow:
            await self._guests.save(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)
