"""modules.checkins.application.service — منظّم التسكين."""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from typing import Protocol

from kernel.bus import EventBus
from kernel.clock import now_iso
from kernel.contracts import Command, Result
from kernel.errors import NotFoundError, PermissionDeniedError
from kernel.security.query_scoper import Actor
from kernel.security.scoping_rules import is_floor_allowed
from kernel.text import sanitize

from modules.checkins.domain.models import CheckinEntity
from modules.checkins.domain.repository import CheckinRepository

logger = logging.getLogger("grandhayat.checkins")


class RoomOccupancyPort(Protocol):
    """Local port owned by checkins; implemented in the composition root."""

    async def occupy_for_checkin(
        self,
        *,
        room_number: int,
        checkin_id: str,
        guest_name: str,
        guest_phone: str,
        check_in_at: str,
        expected_checkout_at: str | None,
        tenant_id: str,
        property_id: str,
        actor: Actor | None = None,
        uow=None,
    ) -> int: ...

    async def release_for_checkin(
        self,
        *,
        room_number: int,
        checkin_id: str,
        tenant_id: str,
        property_id: str,
        uow=None,
    ) -> None: ...


@dataclass(frozen=True)
class RegisterCheckin(Command):
    room_number: int
    floor: int
    guest_name: str
    guest_phone: str
    check_in_at: str | None
    expected_checkout_at: str | None
    note: str
    actor_id: str
    actor_name: str
    tenant_id: str = "default"
    property_id: str = "main"
    actor: Actor | None = None


@dataclass(frozen=True)
class CheckOutGuest(Command):
    checkin_id: str
    actor_id: str
    actor_name: str = ""
    actor: Actor | None = None


@dataclass(frozen=True)
class DeleteCheckin(Command):
    checkin_id: str
    actor_id: str
    actor_name: str = ""
    actor: Actor | None = None


class CheckinApplicationService:
    def __init__(
        self,
        *,
        checkins: CheckinRepository,
        uow_factory,
        bus: EventBus,
        rooms: RoomOccupancyPort | None = None,
    ) -> None:
        self._checkins = checkins
        self._uow_factory = uow_factory
        self._bus = bus
        self._rooms = rooms

    async def list_for(self, actor, *, own_only: bool = False,
                       base_query: dict | None = None,
                       limit: int | None = None):
        from shared.security.scoped_listing import scoped_list
        rules = getattr(self, "_scoping_rules", None)
        if rules is None:
            from kernel.security.scoping_rules import ScopingRules
            rules = ScopingRules()
        scoper = getattr(self, "_scoper", None)
        return await scoped_list(
            self._checkins, lambda a: rules.for_checkins(a, own_only=own_only), actor,
            scoper=scoper, base_query=base_query, limit=limit,
        )

    @staticmethod
    def _ensure_actor_can_access(entity: CheckinEntity, actor: Actor | None) -> None:
        if actor is None:
            return
        if actor.tenant_id and entity.tenant_id != actor.tenant_id:
            raise PermissionDeniedError("لا يمكنك الوصول إلى بيانات Tenant آخر")
        if actor.active_property_id and entity.property_id != actor.active_property_id:
            raise PermissionDeniedError("لا يمكنك الوصول إلى بيانات فندق/عقار آخر")
        if not is_floor_allowed(actor, entity.floor):
            raise PermissionDeniedError("ليست لديك صلاحية لهذا الدور")

    async def register(self, cmd: RegisterCheckin) -> Result:
        checkin_id = str(uuid.uuid4())
        check_in_at = cmd.check_in_at or now_iso()
        entity = CheckinEntity(
            id=checkin_id,
            room_number=cmd.room_number,
            floor=cmd.floor,
            guest_name=sanitize(cmd.guest_name, 120),
            guest_phone=sanitize(cmd.guest_phone, 40),
            check_in_at=check_in_at,
            expected_checkout_at=cmd.expected_checkout_at,
            note=sanitize(cmd.note, 1000) or "",
            created_by=cmd.actor_id,
            created_by_name=cmd.actor_name,
            tenant_id=cmd.tenant_id,
            property_id=cmd.property_id,
        )

        async with self._uow_factory() as uow:
            if self._rooms is not None:
                # Critical invariant: room occupancy and checkin creation share one UoW.
                actual_floor = await self._rooms.occupy_for_checkin(
                    room_number=entity.room_number,
                    checkin_id=entity.id,
                    guest_name=entity.guest_name,
                    guest_phone=entity.guest_phone,
                    check_in_at=entity.check_in_at,
                    expected_checkout_at=entity.expected_checkout_at,
                    tenant_id=entity.tenant_id,
                    property_id=entity.property_id,
                    actor=cmd.actor,
                    uow=uow,
                )
                entity.floor = actual_floor
            entity.register()
            await self._checkins.add(entity, uow=uow)

        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)

    async def check_out(self, cmd: CheckOutGuest) -> Result:
        entity = await self._checkins.get(cmd.checkin_id)
        if not entity:
            raise NotFoundError("سجل التسكين غير موجود")
        self._ensure_actor_can_access(entity, cmd.actor)
        entity.check_out(by=cmd.actor_id, at=now_iso())
        async with self._uow_factory() as uow:
            await self._checkins.save(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)

    async def delete(self, cmd: DeleteCheckin) -> Result:
        entity = await self._checkins.get(cmd.checkin_id)
        if not entity:
            raise NotFoundError("سجل التسكين غير موجود")
        self._ensure_actor_can_access(entity, cmd.actor)
        entity.soft_delete()
        async with self._uow_factory() as uow:
            if self._rooms is not None:
                await self._rooms.release_for_checkin(
                    room_number=entity.room_number,
                    checkin_id=entity.id,
                    tenant_id=entity.tenant_id,
                    property_id=entity.property_id,
                    uow=uow,
                )
            await self._checkins.save(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)
