"""
modules.checkins.api.router — Thin Router لمجال التسكين
═══════════════════════════════════════════════════════════════════

نفس معايير الـ Thin Router من rooms:
  - parse → service → response.
  - Actor من dependency (لا يُبنى هنا).
  - لا scoping يدوي — list_for(actor) يتولّاه في الـ service.
  - لا منطق أعمال، لا transactions، لا publish.

ملاحظة: actor_id/actor_name في الـ Commands يأتيان من الـ Actor المحقون،
لا من جسم الطلب — العميل لا يستطيع انتحال هوية.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from kernel.security.query_scoper import Actor
from modules.checkins.application.service import (
    CheckOutGuest,
    DeleteCheckin,
    RegisterCheckin,
)
from shared.auth.dependencies import get_current_actor, require_permission
from shared.config.container import container

router = APIRouter(prefix="/checkins", tags=["checkins"])


# ── DTOs (validation فقط) ─────────────────────────────────────
class RegisterCheckinBody(BaseModel):
    room_number: int = Field(ge=1)
    floor: int = Field(ge=1)
    guest_name: str = Field(min_length=1, max_length=120)
    guest_phone: str = Field(min_length=3, max_length=40)
    check_in_at: str | None = None
    expected_checkout_at: str | None = None
    note: str = ""


# TODO(Response Contracts Phase):
# استبدال هذا mapper بـ Response DTO / Read Model.
# السبب: Feature Freeze الحالي يمنع إدخال response contracts.
# الخطر الحالي: Coupling محتمل بين Domain و API response shape.
def _checkin_to_dict(c) -> dict:
    return {
        "id": c.id, "room_number": c.room_number, "floor": c.floor,
        "guest_name": c.guest_name, "guest_phone": c.guest_phone,
        "check_in_at": c.check_in_at,
        "expected_checkout_at": c.expected_checkout_at,
        "note": c.note, "status": c.status,
        "checked_out_at": c.checked_out_at,
        "checked_out_by": c.checked_out_by,
        "created_by": c.created_by, "created_by_name": c.created_by_name,
        "tenant_id": getattr(c, "tenant_id", None),
        "property_id": getattr(c, "property_id", None),
    }


# ══════════════════════════════════════════════════════════════
# Endpoints
# ══════════════════════════════════════════════════════════════
@router.get("")
async def list_checkins(
    own_only: bool = Query(default=False),
    actor: Actor = Depends(require_permission("view_checkins")),
):
    checkins = await container.checkins.list_for(actor, own_only=own_only)
    return [_checkin_to_dict(c) for c in checkins]


@router.get("/{checkin_id}")
async def get_checkin(
    checkin_id: str,
    actor: Actor = Depends(require_permission("view_checkins")),
):
    # TODO(Response Contracts Phase):
    # استبدال هذا mapper بـ Response DTO / Read Model.
    # السبب: Feature Freeze الحالي يمنع إدخال response contracts.
    # الخطر الحالي: Coupling محتمل بين Domain و API response shape.
    # ملاحظة إضافية: نستخدم list_for + filter بدلاً من get_for(actor, id)
    # المفقود في الـ Application Service — يحترم scoping تلقائياً.
    checkins = await container.checkins.list_for(actor)
    match = next((c for c in checkins if c.id == checkin_id), None)
    if match is None:
        raise HTTPException(status_code=404, detail="سجلّ التسكين غير موجود")
    return _checkin_to_dict(match)


@router.post("", status_code=status.HTTP_201_CREATED)
async def register_checkin(
    body: RegisterCheckinBody,
    actor: Actor = Depends(require_permission("create_checkin")),
):
    cmd = RegisterCheckin(
        **body.model_dump(), actor_id=actor.id, actor_name=actor.name,
        tenant_id=actor.tenant_id or "default",
        property_id=actor.active_property_id or "main",
        actor=actor,
    )
    result = await container.checkins.register(cmd)
    return _checkin_to_dict(result.data)


@router.post("/{checkin_id}/check-out", status_code=status.HTTP_200_OK)
async def check_out(
    checkin_id: str,
    actor: Actor = Depends(require_permission("edit_checkin")),
):
    cmd = CheckOutGuest(checkin_id=checkin_id, actor_id=actor.id, actor_name=actor.name, actor=actor)
    result = await container.checkins.check_out(cmd)
    return _checkin_to_dict(result.data)


@router.delete("/{checkin_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_checkin(
    checkin_id: str,
    actor: Actor = Depends(require_permission("edit_checkin")),
):
    cmd = DeleteCheckin(checkin_id=checkin_id, actor_id=actor.id, actor_name=actor.name, actor=actor)
    await container.checkins.delete(cmd)
