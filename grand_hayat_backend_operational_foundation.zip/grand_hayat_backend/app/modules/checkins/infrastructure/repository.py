"""
modules.checkins.infrastructure.repository — تنفيذ مستودع التسكين
═══════════════════════════════════════════════════════════════════

الطبقة الوحيدة المسموح فيها لمس motor/db لمجال التسكين (البند 3).
تنفّذ CheckinRepository وتترجم CheckinEntity ⇄ مستند MongoDB.

التحويل الصريح (_to_entity / _to_document) يضمن عدم تسرّب كائن التخزين
إلى المجال (البند 3: فصل Domain / DTO / Persistence).
"""
from __future__ import annotations

from kernel.persistence import session_kwargs
from shared.security.base_scoped_repository import ScopedRepositoryMixin
from modules.checkins.domain.models import CheckinEntity
from modules.checkins.domain.repository import CheckinRepository

COLLECTION = "checkins"


class MongoCheckinRepository(ScopedRepositoryMixin, CheckinRepository):
    _scope_sort_field = "created_at"
    _scope_sort_dir = -1
    _scope_default_limit = 300
    def __init__(self, db) -> None:
        self._col = db[COLLECTION]

    # ── Mappers ───────────────────────────────────────────────
    @staticmethod
    def _to_entity(doc: dict) -> CheckinEntity:
        return CheckinEntity(
            id=doc["id"],
            room_number=doc["room_number"],
            floor=doc["floor"],
            guest_name=doc.get("guest_name", ""),
            guest_phone=doc.get("guest_phone", ""),
            check_in_at=doc.get("check_in_at", ""),
            expected_checkout_at=doc.get("expected_checkout_at"),
            note=doc.get("note", ""),
            status=doc.get("status", "active"),
            checked_out_at=doc.get("checked_out_at"),
            checked_out_by=doc.get("checked_out_by"),
            created_by=doc.get("created_by", ""),
            created_by_name=doc.get("created_by_name", ""),
            tenant_id=doc.get("tenant_id", "default"),
            property_id=doc.get("property_id", "main"),
        )

    @staticmethod
    def _to_document(e: CheckinEntity) -> dict:
        return {
            "id": e.id,
            "room_number": e.room_number,
            "floor": e.floor,
            "guest_name": e.guest_name,
            "guest_phone": e.guest_phone,
            "check_in_at": e.check_in_at,
            "expected_checkout_at": e.expected_checkout_at,
            "note": e.note,
            "status": e.status,
            "checked_out_at": e.checked_out_at,
            "checked_out_by": e.checked_out_by,
            "created_by": e.created_by,
            "created_by_name": e.created_by_name,
            "tenant_id": e.tenant_id,
            "property_id": e.property_id,
        }

    # ── Operations ────────────────────────────────────────────
    async def get(self, checkin_id: str) -> CheckinEntity | None:
        doc = await self._col.find_one({"id": checkin_id}, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def add(self, checkin: CheckinEntity, uow=None) -> CheckinEntity:
        await self._col.insert_one(self._to_document(checkin), **session_kwargs(uow))
        return checkin

    async def save(self, checkin: CheckinEntity, uow=None) -> CheckinEntity:
        await self._col.update_one(
            {"id": checkin.id},
            {"$set": self._to_document(checkin)},
            **session_kwargs(uow),
        )
        return checkin

    async def get_active_by_room(
        self, room_number: int, *, tenant_id: str | None = None, property_id: str | None = None
    ) -> CheckinEntity | None:
        query = {"room_number": room_number, "status": "active"}
        if tenant_id:
            query["tenant_id"] = tenant_id
        if property_id:
            query["property_id"] = property_id
        doc = await self._col.find_one(query, {"_id": 0})
        return self._to_entity(doc) if doc else None
