"""
modules.checkins.domain.models — كيان التسكين وسلوكه
═══════════════════════════════════════════════════════════════════

Domain Ownership: هذا المجال يملك سجلّ التسكين فقط. لا يلمس بيانات
الغرفة ولا الفاتورة — يكتفي بإطلاق الأحداث، وتستجيب المجالات الأخرى.

(قبل التحويل كان checkin_service يكتب في db.rooms و db.settings مباشرة،
ويرسل SMS — انتهاك صارخ لـ Domain Ownership والبند 2. الآن مفصول تماماً.)

قيود الطبقة:
  ✗ لا motor / لا db          (Repository Law)
  ✗ لا side effects           (لا SMS / لا WS / لا HTTP)
  ✓ منطق نقي + invariants + انتقالات عبر CHECKIN_FSM
"""
from __future__ import annotations

from dataclasses import dataclass, field

from kernel.contracts import DomainEvent, Entity
from kernel.errors import ConflictError, InvariantViolationError
from kernel.state_machine import StateMachine

from modules.checkins.domain.events import (
    CheckinCheckedOut,
    CheckinDeleted,
    CheckinRegistered,
)

# ══════════════════════════════════════════════════════════════
# State Machine — دورة حياة التسكين
# active هي الحالة المنتجة الوحيدة؛ checked_out و deleted نهائيتان.
# ══════════════════════════════════════════════════════════════
CHECKIN_FSM = StateMachine(
    name="checkin",
    transitions={
        "active":      {"checked_out", "deleted"},
        "checked_out": set(),   # نهائية
        "deleted":     set(),   # نهائية
    },
    terminal=frozenset({"checked_out", "deleted"}),
)


# ══════════════════════════════════════════════════════════════
# Entity — التسكين (Aggregate Root)
# ══════════════════════════════════════════════════════════════
@dataclass
class CheckinEntity(Entity):
    """سجلّ تسكين نزيل. يملك بياناته الخاصة فقط.

    Invariants:
      - guest_name و guest_phone غير فارغين عند التسجيل
      - room_number و floor موجبان
      - لا انتقال من حالة نهائية (يفرضه CHECKIN_FSM.terminal)
    """
    id: str
    room_number: int
    floor: int
    guest_name: str
    guest_phone: str
    check_in_at: str
    expected_checkout_at: str | None = None
    note: str = ""
    status: str = "active"
    # تتبّع المغادرة
    checked_out_at: str | None = None
    checked_out_by: str | None = None
    # تدقيق
    created_by: str = ""
    created_by_name: str = ""
    tenant_id: str = "default"
    property_id: str = "main"

    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    def pull_events(self) -> list[DomainEvent]:
        ev, self._events = self._events, []
        return ev

    # ── Invariants ────────────────────────────────────────────
    def _check_invariants(self) -> None:
        if not (self.guest_name or "").strip():
            raise InvariantViolationError("اسم النزيل مطلوب")
        if not (self.guest_phone or "").strip():
            raise InvariantViolationError("رقم هاتف النزيل مطلوب")
        if self.room_number <= 0 or self.floor <= 0:
            raise InvariantViolationError("رقم الغرفة/الدور غير صالح")

    # ── Behaviours ────────────────────────────────────────────
    def register(self) -> None:
        """يُثبّت التسكين ويُطلق الحدث المحوري (يُستدعى بعد البناء)."""
        self._check_invariants()
        self._events.append(CheckinRegistered(
            checkin_id=self.id, room_number=self.room_number, floor=self.floor,
            guest_name=self.guest_name, guest_phone=self.guest_phone,
            check_in_at=self.check_in_at, expected_checkout_at=self.expected_checkout_at,
            tenant_id=self.tenant_id, property_id=self.property_id,
        ))

    def check_out(self, *, by: str, at: str) -> None:
        """مغادرة طبيعية للنزيل."""
        self.status = CHECKIN_FSM.transition(self.status, "checked_out")
        self.checked_out_at = at
        self.checked_out_by = by
        self._events.append(CheckinCheckedOut(
            checkin_id=self.id, room_number=self.room_number,
            tenant_id=self.tenant_id, property_id=self.property_id,
        ))

    def soft_delete(self) -> None:
        """إلغاء/حذف إداري للتسكين (مثلاً تسكين خاطئ)."""
        if self.status == "deleted":
            return  # idempotent
        if self.status == "checked_out":
            raise ConflictError("لا يمكن حذف تسكين تمّت مغادرته")
        self.status = CHECKIN_FSM.transition(self.status, "deleted")
        self._events.append(CheckinDeleted(
            checkin_id=self.id, room_number=self.room_number,
            tenant_id=self.tenant_id, property_id=self.property_id,
        ))
