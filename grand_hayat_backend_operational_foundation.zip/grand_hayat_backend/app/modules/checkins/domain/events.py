"""modules.checkins.domain.events — أحداث مجال التسكين."""
from __future__ import annotations

from dataclasses import dataclass

from kernel.contracts import DomainEvent


@dataclass(frozen=True)
class CheckinRegistered(DomainEvent):
    """سُجِّل تسكين نزيل جديد."""
    topic = "checkins.registered"
    checkin_id: str = ""
    room_number: int = 0
    floor: int = 0
    guest_name: str = ""
    guest_phone: str = ""
    check_in_at: str = ""
    expected_checkout_at: str | None = None
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class CheckinCheckedOut(DomainEvent):
    """تمّت مغادرة النزيل."""
    topic = "checkins.checked_out"
    checkin_id: str = ""
    room_number: int = 0
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class CheckinDeleted(DomainEvent):
    """أُلغي/حُذف التسكين إدارياً."""
    topic = "checkins.deleted"
    checkin_id: str = ""
    room_number: int = 0
    tenant_id: str = "default"
    property_id: str = "main"
