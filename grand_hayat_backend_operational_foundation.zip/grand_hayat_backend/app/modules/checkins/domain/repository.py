"""
modules.checkins.domain.repository — واجهة مستودع التسكين
═══════════════════════════════════════════════════════════════════

Repository Law (البند 4): الـ application يعتمد على هذا Protocol فقط.
التنفيذ (MongoCheckinRepository) في infrastructure ويترجم Entity ⇄ Document.
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable

from modules.checkins.domain.models import CheckinEntity


@runtime_checkable
class CheckinRepository(Protocol):
    """عقد تخزين التسكين."""

    async def get(self, checkin_id: str) -> CheckinEntity | None:
        """يجلب سجلّ تسكين بمعرّفه."""
        ...

    async def add(self, checkin: CheckinEntity, uow=None) -> CheckinEntity:
        """يُدرج سجلّ تسكين جديد ضمن معاملة."""
        ...

    async def save(self, checkin: CheckinEntity, uow=None) -> CheckinEntity:
        """يحدّث سجلّ تسكين قائم (مغادرة/حذف)."""
        ...

    async def get_active_by_room(
        self, room_number: int, *, tenant_id: str | None = None, property_id: str | None = None
    ) -> CheckinEntity | None:
        """يجلب التسكين النشط لغرفة (للتحقق قبل مغادرة/حذف)."""
        ...
