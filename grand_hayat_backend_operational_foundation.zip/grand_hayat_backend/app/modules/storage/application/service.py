from __future__ import annotations
import uuid
from dataclasses import dataclass
from kernel.bus import EventBus
from kernel.clock import now_iso
from kernel.contracts import Command, Result
from kernel.text import sanitize
from modules.storage.domain.models import StoredFileEntity
from modules.storage.domain.repository import StorageRepository

@dataclass(frozen=True)
class RegisterStoredFile(Command):
    tenant_id: str
    property_id: str
    owner_type: str
    owner_id: str
    filename: str
    content_type: str
    size: int
    storage_key: str
    url: str = ""
    checksum_sha256: str = ""
    actor_id: str = ""

class StorageApplicationService:
    def __init__(self, *, storage: StorageRepository, uow_factory, bus: EventBus) -> None:
        self._storage = storage
        self._uow_factory = uow_factory
        self._bus = bus

    def _scope(self, actor, base: dict | None = None) -> dict:
        q = dict(base or {})
        if getattr(actor, "role", "") != "super_admin":
            q["tenant_id"] = actor.tenant_id or "default"
            q["property_id"] = actor.active_property_id or "main"
        return q

    async def list_for(self, actor, *, base_query: dict | None = None, limit: int = 300):
        return await self._storage.list_scoped(self._scope(actor, base_query), limit=limit)

    async def register(self, cmd: RegisterStoredFile) -> Result:
        entity = StoredFileEntity(
            id=str(uuid.uuid4()), tenant_id=cmd.tenant_id, property_id=cmd.property_id,
            owner_type=sanitize(cmd.owner_type, 80) or "general", owner_id=sanitize(cmd.owner_id, 120) or "unknown",
            filename=sanitize(cmd.filename, 240) or "file", content_type=sanitize(cmd.content_type, 120) or "application/octet-stream",
            size=int(cmd.size), storage_key=sanitize(cmd.storage_key, 500) or "", url=sanitize(cmd.url, 1000) or "",
            checksum_sha256=sanitize(cmd.checksum_sha256, 80) or "", created_by=cmd.actor_id, created_at=now_iso(),
        )
        entity.register()
        async with self._uow_factory() as uow:
            await self._storage.add(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)
