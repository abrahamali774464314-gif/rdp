from __future__ import annotations
from dataclasses import dataclass, field
from kernel.contracts import DomainEvent, Entity
from kernel.errors import InvariantViolationError
from modules.storage.domain.events import StoredFileRegistered

@dataclass
class StoredFileEntity(Entity):
    id: str
    tenant_id: str
    property_id: str
    owner_type: str
    owner_id: str
    filename: str
    content_type: str
    size: int
    storage_key: str
    url: str = ""
    checksum_sha256: str = ""
    status: str = "active"
    created_by: str = ""
    created_at: str = ""
    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    def pull_events(self) -> list[DomainEvent]:
        ev, self._events = self._events, []
        return ev

    def register(self) -> None:
        if not self.tenant_id or not self.property_id or not self.owner_type or not self.owner_id:
            raise InvariantViolationError("بيانات ربط الملف مطلوبة")
        if not self.filename or not self.storage_key:
            raise InvariantViolationError("اسم الملف ومفتاح التخزين مطلوبان")
        if self.size < 0:
            raise InvariantViolationError("حجم الملف غير صحيح")
        self._events.append(StoredFileRegistered(file_id=self.id, tenant_id=self.tenant_id, property_id=self.property_id, owner_type=self.owner_type, owner_id=self.owner_id))
