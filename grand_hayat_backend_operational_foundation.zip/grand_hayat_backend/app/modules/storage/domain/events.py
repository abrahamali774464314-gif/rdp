from __future__ import annotations
from dataclasses import dataclass
from kernel.contracts import DomainEvent

@dataclass(frozen=True)
class StoredFileRegistered(DomainEvent):
    file_id: str
    tenant_id: str
    property_id: str
    owner_type: str
    owner_id: str
    topic = "storage.file_registered"
