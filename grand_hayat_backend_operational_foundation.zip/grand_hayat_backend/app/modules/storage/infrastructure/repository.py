from __future__ import annotations
from kernel.persistence import session_kwargs
from modules.storage.domain.models import StoredFileEntity
from modules.storage.domain.repository import StorageRepository

class MongoStorageRepository(StorageRepository):
    def __init__(self, db) -> None:
        self._col = db["stored_files"]

    @staticmethod
    def _to_entity(doc: dict) -> StoredFileEntity:
        return StoredFileEntity(id=doc["id"], tenant_id=doc.get("tenant_id", "default"), property_id=doc.get("property_id", "main"), owner_type=doc.get("owner_type", ""), owner_id=doc.get("owner_id", ""), filename=doc.get("filename", ""), content_type=doc.get("content_type", "application/octet-stream"), size=int(doc.get("size", 0)), storage_key=doc.get("storage_key", ""), url=doc.get("url", ""), checksum_sha256=doc.get("checksum_sha256", ""), status=doc.get("status", "active"), created_by=doc.get("created_by", ""), created_at=doc.get("created_at", ""))

    @staticmethod
    def _to_doc(e: StoredFileEntity) -> dict:
        return {"id": e.id, "tenant_id": e.tenant_id, "property_id": e.property_id, "owner_type": e.owner_type, "owner_id": e.owner_id, "filename": e.filename, "content_type": e.content_type, "size": e.size, "storage_key": e.storage_key, "url": e.url, "checksum_sha256": e.checksum_sha256, "status": e.status, "created_by": e.created_by, "created_at": e.created_at}

    async def get(self, file_id: str, *, tenant_id: str | None = None, property_id: str | None = None) -> StoredFileEntity | None:
        q = {"id": file_id}
        if tenant_id:
            q["tenant_id"] = tenant_id
        if property_id:
            q["property_id"] = property_id
        doc = await self._col.find_one(q, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def add(self, file: StoredFileEntity, uow=None) -> StoredFileEntity:
        await self._col.insert_one(self._to_doc(file), **session_kwargs(uow))
        return file

    async def list_scoped(self, scoped_filter: dict, *, limit: int = 300) -> list[StoredFileEntity]:
        limit = max(1, min(int(limit), 1000))
        docs = await self._col.find(scoped_filter or {}, {"_id": 0}).sort("created_at", -1).to_list(limit)
        return [self._to_entity(d) for d in docs]
