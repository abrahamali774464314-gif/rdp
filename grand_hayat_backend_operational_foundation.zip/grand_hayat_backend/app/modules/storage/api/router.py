from __future__ import annotations
from fastapi import APIRouter, Depends, Query, status
from pydantic import BaseModel, Field
from kernel.security.query_scoper import Actor
from modules.storage.application.service import RegisterStoredFile
from shared.auth.dependencies import require_permission
from shared.config.container import container

router = APIRouter(prefix="/storage", tags=["storage"])

class StoredFileBody(BaseModel):
    owner_type: str = Field(min_length=1, max_length=80)
    owner_id: str = Field(min_length=1, max_length=120)
    filename: str = Field(min_length=1, max_length=240)
    content_type: str = "application/octet-stream"
    size: int = 0
    storage_key: str = Field(min_length=1, max_length=500)
    url: str = ""
    checksum_sha256: str = ""

def _file_to_dict(f) -> dict:
    return {"id": f.id, "owner_type": f.owner_type, "owner_id": f.owner_id, "filename": f.filename, "content_type": f.content_type, "size": f.size, "storage_key": f.storage_key, "url": f.url, "checksum_sha256": f.checksum_sha256, "status": f.status, "created_by": f.created_by, "created_at": f.created_at, "tenant_id": f.tenant_id, "property_id": f.property_id}

@router.get("")
async def list_files(owner_type: str | None = Query(default=None), owner_id: str | None = Query(default=None), actor: Actor = Depends(require_permission("view_storage_files"))):
    base = ({"owner_type": owner_type} if owner_type else {}) | ({"owner_id": owner_id} if owner_id else {})
    return [_file_to_dict(f) for f in await container.storage.list_for(actor, base_query=base)]

@router.post("", status_code=status.HTTP_201_CREATED)
async def register_file(body: StoredFileBody, actor: Actor = Depends(require_permission("manage_storage_files"))):
    result = await container.storage.register(RegisterStoredFile(tenant_id=actor.tenant_id or "default", property_id=actor.active_property_id or "main", actor_id=actor.id, **body.model_dump()))
    return _file_to_dict(result.data)
