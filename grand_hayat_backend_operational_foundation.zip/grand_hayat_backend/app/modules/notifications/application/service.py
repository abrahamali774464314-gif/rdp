"""
modules.notifications.application.service — منظّم الإشعارات
═══════════════════════════════════════════════════════════════════

جانبان:

① منظّم الإرسال (dispatch):
   - يحفظ محاولة، يستدعي الـ Port المناسب، يحدّث الحالة، ينشر الأحداث.
   - idempotency عبر cause_event_id (لا إرسال مزدوج لنفس الحدث/القناة).
   - retry: يعيد إرسال المحاولات الفاشلة القابلة لإعادة المحاولة.

② Subscribers (الجوهر):
   يستهلك أحداث كل المجالات ويترجمها لرسائل ملموسة. هنا — لا في المجال —
   يُتّخذ قرار «أي حدث يستحق أي رسالة». المجالات المنتجة لا تعرف بوجود
   الإشعارات إطلاقاً (تنشر حقائقها فقط).

ترحيب النزيل (المتطلب 6): عند CheckinRegistered يُرسَل ترحيب + قائمة
خدمات عبر القناة المفضّلة (WhatsApp إن توفّر، وإلا SMS). القوالب تُحقَن
من الـ container — لا تُكتب في المجال ولا الـ application.

لا side effects مباشرة — كل I/O عبر الـ Ports المجرّدة.
"""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from typing import Awaitable, Callable

from kernel.bus import EventBus
from kernel.clock import now_iso

from modules.notifications.domain.models import (
    CHANNEL_REALTIME, CHANNEL_SMS, CHANNEL_WHATSAPP,
    NotificationEntity, NotificationMessage,
    REASON_DUPLICATE, REASON_NO_RECIPIENT,
    RealtimePort, SendResult, SmsPort, WhatsAppPort,
)
from modules.notifications.domain.repository import NotificationRepository

logger = logging.getLogger("grandhayat.notifications")

# قوالب تُحقَن من الـ container (تقرأ الإعدادات — لا يلمسها المجال).
#   welcome(guest_name, room_number) -> نص الترحيب + قائمة الخدمات
WelcomeTemplateProvider = Callable[[str, int], Awaitable[str]]


# ══════════════════════════════════════════════════════════════
# Application Service
# ══════════════════════════════════════════════════════════════
class NotificationApplicationService:
    def __init__(self, *, notifications: NotificationRepository, uow_factory,
                 bus: EventBus, sms: SmsPort, whatsapp: WhatsAppPort,
                 realtime: RealtimePort) -> None:
        self._notifications = notifications
        self._uow_factory = uow_factory
        self._bus = bus
        self._sms = sms
        self._whatsapp = whatsapp
        self._realtime = realtime


    async def list_for(self, actor, *, base_query: dict | None = None, limit: int = 200):
        q = dict(base_query or {})
        if getattr(actor, "role", "") != "super_admin":
            # Legacy notification records may not have tenant/property yet; new ones should.
            q.setdefault("tenant_id", actor.tenant_id or "default")
            q.setdefault("property_id", actor.active_property_id or "main")
        return await self._notifications.list_scoped(q, limit=limit)

    async def dispatch(self, *, message: NotificationMessage, cause_event: str,
                       cause_event_id: str = "") -> NotificationEntity:
        """نقطة الدخول الوحيدة لإرسال أي إشعار (idempotent)."""
        # idempotency: مفتاح مستقرّ (topic + channel + recipient + event_id)
        if cause_event_id:
            from modules.notifications.domain.models import derive_idempotency_key
            key = derive_idempotency_key(
                cause_event=cause_event, channel=message.channel,
                recipient=message.recipient, cause_event_id=cause_event_id,
            )
            existing = await self._notifications.find_by_idempotency_key(key)
            if existing:
                logger.debug("notification skipped (duplicate key=%s)", key)
                return existing

        entity = NotificationEntity(
            id=str(uuid.uuid4()), message=message,
            cause_event=cause_event, cause_event_id=cause_event_id,
            created_at=now_iso(),
        )

        # تحقّق مبكّر: قناة تتطلّب مستلِماً بلا رقم → suppression بلا اتصال
        from modules.notifications.domain.models import RECIPIENT_REQUIRED_CHANNELS
        if (message.channel in RECIPIENT_REQUIRED_CHANNELS
                and not message.recipient.strip()):
            entity.suppress(REASON_NO_RECIPIENT)
            await self._persist_and_publish(entity)
            return entity

        await self._attempt_send(entity)
        await self._persist_and_publish(entity)
        return entity

    async def retry(self, notification_id: str) -> NotificationEntity | None:
        """إعادة محاولة إرسال (يُستدعى من event_queue worker)."""
        entity = await self._notifications.get(notification_id)
        if not entity or not entity.can_retry:
            return entity
        entity.begin_retry()
        await self._attempt_send(entity)
        await self._persist_and_publish(entity)
        return entity

    async def list_retryable(self, *, limit: int = 100) -> list[NotificationEntity]:
        return await self._notifications.list_retryable(limit=limit)

    # ── الإرسال الفعلي عبر الـ Port المناسب ───────────────────
    async def _attempt_send(self, entity: NotificationEntity) -> None:
        msg = entity.message
        try:
            if msg.channel == CHANNEL_SMS:
                result = await self._sms.send(msg.recipient, msg.body)
            elif msg.channel == CHANNEL_WHATSAPP:
                result = await self._whatsapp.send_text(msg.recipient, msg.body)
            elif msg.channel == CHANNEL_REALTIME:
                payload = dict(msg.payload) if msg.payload else {}
                result = await self._realtime.broadcast(
                    msg.recipient, payload, sound_event=msg.sound_event)
            else:
                result = SendResult(ok=False, error=f"channel غير مدعوم: {msg.channel}")
        except Exception as exc:  # noqa: BLE001 — حماية نهائية لا تُفشل المسار الأصلي
            result = SendResult(ok=False, error=str(exc))

        if result.ok:
            entity.mark_sent(at=now_iso(), external_reference=result.external_reference)
        else:
            entity.mark_failed(at=now_iso(), error=result.error)

    async def _persist_and_publish(self, entity: NotificationEntity) -> None:
        # المستودع يضمن upsert (add أو save) عبر save — لا منطق شرطي هنا
        async with self._uow_factory() as uow:
            await self._notifications.save(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())


# ══════════════════════════════════════════════════════════════
# Subscribers — ترجمة أحداث المنبع إلى رسائل
# ══════════════════════════════════════════════════════════════
class NotificationSubscribers:
    """يستهلك أحداث المجالات الأخرى ويُصدر رسائل عبر الـ ports.

    قاعدة: كل معالج يبني NotificationMessage ويستدعي svc.dispatch —
    لا يستدعي الـ Ports مباشرة (يبقى السجلّ والـ idempotency موحّدين).
    """

    def __init__(self, *, svc: NotificationApplicationService,
                 welcome_template_provider: WelcomeTemplateProvider,
                 prefer_whatsapp: bool = True) -> None:
        self._svc = svc
        self._welcome = welcome_template_provider
        self._guest_channel = CHANNEL_WHATSAPP if prefer_whatsapp else CHANNEL_SMS

    def register(self, bus: EventBus) -> None:
        # Notifications are side effects. They must never break core invariants,
        # so subscribers are explicitly lenient under the fail-fast EventBus.
        def sub(topic: str, handler):
            try:
                bus.subscribe(topic, handler, fail_fast=False)
            except TypeError:  # compatibility with any older bus implementation
                bus.subscribe(topic, handler)

        sub("checkins.registered", self._welcome_guest)
        sub("rooms.state_changed", self._room_state)
        sub("requests.created", self._request_created)
        sub("requests.completed", self._request_completed)
        sub("checkouts.created", self._checkout_created)
        sub("checkouts.completed", self._checkout_completed)
        sub("inspections.completed", self._inspection_completed)
        sub("billing.charge_posted", self._charge_posted)

    # ── رسالة النزيل: ترحيب + قائمة خدمات ─────────────────────
    async def _welcome_guest(self, event) -> None:
        phone = (getattr(event, "guest_phone", "") or "").strip()
        if not phone:
            return
        body = await self._welcome(event.guest_name, event.room_number)
        await self._svc.dispatch(
            message=NotificationMessage(
                channel=self._guest_channel, recipient=phone, body=body),
            cause_event=event.topic, cause_event_id=event.event_id,
        )

    # ── بثّ لحظي موحّد ─────────────────────────────────────────
    async def _broadcast(self, *, name: str, data: dict, cause,
                         sound: str | None = None) -> None:
        await self._svc.dispatch(
            message=NotificationMessage(
                channel=CHANNEL_REALTIME, recipient=name, body="",
                payload=tuple(data.items()), sound_event=sound),
            cause_event=cause.topic, cause_event_id=cause.event_id,
        )

    async def _room_state(self, e) -> None:
        await self._broadcast(name="room:update",
            data={"room_number": e.room_number, "status": e.new_status, "floor": e.floor},
            cause=e)

    async def _request_created(self, e) -> None:
        await self._broadcast(name="request:new",
            data={"request_id": e.request_id, "room_number": e.room_number,
                  "floor": e.floor, "type": e.request_type},
            cause=e, sound="request_new")

    async def _request_completed(self, e) -> None:
        await self._broadcast(name="request:update",
            data={"request_id": e.request_id, "room_number": e.room_number,
                  "status": "completed"},
            cause=e, sound="request_completed")

    async def _checkout_created(self, e) -> None:
        await self._broadcast(name="checkout:new",
            data={"checkout_id": e.checkout_id, "room_number": e.room_number,
                  "floor": e.floor},
            cause=e, sound="checkout_new")

    async def _checkout_completed(self, e) -> None:
        await self._broadcast(name="checkout:update",
            data={"checkout_id": e.checkout_id, "room_number": e.room_number,
                  "status": "completed", "decision": e.decision},
            cause=e, sound="checkout_completed")

    async def _inspection_completed(self, e) -> None:
        await self._broadcast(name="inspection:new",
            data={"inspection_id": e.inspection_id, "room_number": e.room_number,
                  "report_type": e.report_type, "decision": e.decision},
            cause=e)

    async def _charge_posted(self, e) -> None:
        await self._broadcast(name="folio:update",
            data={"folio_id": e.folio_id, "txn_id": e.txn_id, "amount": e.amount},
            cause=e)
