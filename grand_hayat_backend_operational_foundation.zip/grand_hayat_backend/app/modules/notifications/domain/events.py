"""
modules.notifications.domain.events — أحداث مجال الإشعارات
═══════════════════════════════════════════════════════════════════

مجال الإشعارات في طرف الاستقبال: يستهلك أحداث مجالات أخرى وينفّذ
التأثيرات الجانبية. يُصدر أحداثاً للتدقيق وإعادة المحاولة فقط:

  NotificationDispatched  — نجحت/فشلت محاولة إرسال (audit + retry trigger)
  NotificationSuppressed  — تُجووِزت محاولة (مكرر/لا مستلم/معطّل)
  NotificationExhausted   — استُنفدت كل محاولات إعادة الإرسال (تنبيه تشغيلي)

لا نُصدر أحداث «إشعار جديد» — مجالات أخرى تستجيب لأحداث المنبع مباشرة،
لا لإشعار وسيط. هذا يبقي المجال غبياً (orchestration فقط).
"""
from __future__ import annotations

from dataclasses import dataclass

from kernel.contracts import DomainEvent


@dataclass(frozen=True)
class NotificationDispatched(DomainEvent):
    """نجحت/فشلت محاولة إرسال. للتدقيق وكمُحفّز لإعادة المحاولة عند الفشل."""
    topic = "notifications.dispatched"
    notification_id: str = ""
    channel: str = ""
    recipient: str = ""
    cause_event: str = ""
    ok: bool = False
    attempt: int = 0
    error: str = ""
    external_reference: str = ""


@dataclass(frozen=True)
class NotificationSuppressed(DomainEvent):
    """تُجووِزت المحاولة قبل أي اتصال خارجي. للتدقيق فقط."""
    topic = "notifications.suppressed"
    notification_id: str = ""
    channel: str = ""
    cause_event: str = ""
    reason: str = ""          # duplicate | no_recipient | disabled


@dataclass(frozen=True)
class NotificationExhausted(DomainEvent):
    """استُنفدت كل محاولات إعادة الإرسال — يحتاج تدخّلاً تشغيلياً."""
    topic = "notifications.exhausted"
    notification_id: str = ""
    channel: str = ""
    recipient: str = ""
    cause_event: str = ""
    attempts: int = 0
    last_error: str = ""
