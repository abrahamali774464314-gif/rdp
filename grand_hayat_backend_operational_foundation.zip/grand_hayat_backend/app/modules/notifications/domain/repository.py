"""
modules.notifications.domain.repository — واجهة مستودع الإشعارات
═══════════════════════════════════════════════════════════════════

Repository Law (البند 4): الـ application يعتمد على هذا Protocol فقط.

idempotency على مستوى التخزين (find_by_idempotency_key) تحمي من إرسال
الإشعار مرّتين عند إعادة بثّ الحدث من event_queue أو إعادة محاولة.
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable

from modules.notifications.domain.models import NotificationEntity


@runtime_checkable
class NotificationRepository(Protocol):
    """عقد تخزين محاولات الإشعار (audit trail كامل)."""

    async def get(self, notification_id: str) -> NotificationEntity | None:
        """يجلب محاولة بمعرّفها."""
        ...

    async def add(self, notification: NotificationEntity, uow=None) -> NotificationEntity:
        """يُدرج محاولة جديدة (audit)."""
        ...

    async def save(self, notification: NotificationEntity, uow=None) -> NotificationEntity:
        """يحدّث محاولة قائمة (بعد الإرسال/الفشل/إعادة المحاولة)."""
        ...

    async def find_by_idempotency_key(
        self, idempotency_key: str,
    ) -> NotificationEntity | None:
        """يبحث عن محاولة سابقة بنفس المفتاح المستقرّ (topic+channel+recipient+event_id).

        يحمي من الإرسال المزدوج عند إعادة بثّ الحدث أو إعادة محاولة من event_queue.
        """
        ...

    async def list_retryable(self, *, limit: int = 100) -> list[NotificationEntity]:
        """المحاولات الفاشلة القابلة لإعادة الإرسال (للـ event_queue worker)."""
        ...

    async def list_scoped(self, scoped_filter: dict, *, limit: int = 200) -> list[NotificationEntity]:
        """قائمة محاولات الإشعار."""
        ...
