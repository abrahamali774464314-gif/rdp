"""
modules.notifications.domain.models — كيان الإشعار وبواباته
═══════════════════════════════════════════════════════════════════

Domain Ownership: يملك سجلّ محاولة الإشعار (audit trail) ودورة حياتها.

المجال هنا "غبيّ" عمداً (كما طلب الدستور): لا يقرّر «أي حدث يستحق أي
رسالة» (هذا قرار في الـ application subscribers). يحرس فقط:
  - صحّة الرسالة (channel/recipient)
  - دورة حياة المحاولة (FSM)
  - منطق إعادة المحاولة (max_attempts, can_retry)

نقطة معمارية: الـ Ports تُعرَّف هنا — في الـ domain — لا في infrastructure.
كل قناة لها Port مستقل (Dependency Inversion):
    SmsPort · WhatsAppPort · RealtimePort
infrastructure يُنفّذها، application يستهلكها، المجال يملك العقد.

النص (NotificationMessage) frozen — ما يُحفظ هو ما يُرسَل بالضبط.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from kernel.contracts import DomainEvent, Entity
from kernel.errors import InvariantViolationError
from kernel.state_machine import StateMachine

from modules.notifications.domain.events import (
    NotificationDispatched,
    NotificationExhausted,
    NotificationSuppressed,
)

# ══════════════════════════════════════════════════════════════
# Constants
# ══════════════════════════════════════════════════════════════
CHANNEL_SMS = "sms"
CHANNEL_WHATSAPP = "whatsapp"
CHANNEL_REALTIME = "realtime"   # WebSocket
VALID_CHANNELS = frozenset({CHANNEL_SMS, CHANNEL_WHATSAPP, CHANNEL_REALTIME})

# القنوات التي تتطلّب مستلِماً (رقم هاتف). الـ realtime يبثّ بلا مستلِم محدّد.
RECIPIENT_REQUIRED_CHANNELS = frozenset({CHANNEL_SMS, CHANNEL_WHATSAPP})

DEFAULT_MAX_ATTEMPTS = 3

REASON_DUPLICATE = "duplicate"
REASON_NO_RECIPIENT = "no_recipient"
REASON_DISABLED = "disabled"


# ══════════════════════════════════════════════════════════════
# Idempotency Key — مفتاح اشتقاق مستقرّ
# ══════════════════════════════════════════════════════════════
def derive_idempotency_key(*, cause_event: str, channel: str,
                            recipient: str, cause_event_id: str) -> str:
    """يُولّد مفتاحاً مستقرّاً يميّز محاولة إشعار فريدة منطقياً.

    الصيغة: "{topic}|{channel}|{recipient}|{event_id}"
    دالة نقية بلا حالة — يمكن استدعاؤها قبل بناء الـ Entity (للبحث عن
    تكرار سابق في المستودع). نُطبّع الأجزاء لإزالة الفراغات.
    """
    return "|".join((
        (cause_event or "").strip(),
        (channel or "").strip(),
        (recipient or "").strip(),
        (cause_event_id or "").strip(),
    ))


# ══════════════════════════════════════════════════════════════
# State Machine — دورة حياة محاولة الإشعار
# ══════════════════════════════════════════════════════════════
NOTIFICATION_FSM = StateMachine(
    name="notification",
    transitions={
        "pending":    {"sent", "failed", "suppressed"},
        "failed":     {"pending", "exhausted"},   # retry أو استنفاد
        "sent":       set(),    # نهائية
        "suppressed": set(),    # نهائية
        "exhausted":  set(),    # نهائية
    },
    terminal=frozenset({"sent", "suppressed", "exhausted"}),
)


# ══════════════════════════════════════════════════════════════
# Value Object — رسالة الإشعار (ثابتة)
# ══════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class NotificationMessage:
    """محتوى الإشعار. ثابت بعد البناء — ما يُحفظ هو ما يُرسَل بالضبط.

    - SMS/WhatsApp : recipient = رقم الهاتف، body = النص
    - realtime     : recipient = اسم حدث الـ WS (مثل "room:update")،
                     payload = الحمولة، body فارغ
    """
    channel: str
    recipient: str
    body: str = ""
    payload: tuple = ()              # ((key, value), ...) ثابتة لـ realtime
    sound_event: str | None = None   # صوت تنبيه لـ realtime

    def __post_init__(self) -> None:
        if self.channel not in VALID_CHANNELS:
            raise InvariantViolationError(f"قناة إشعار غير معروفة: {self.channel}")


# ══════════════════════════════════════════════════════════════
# Ports — تعريفات مجرّدة لكل قناة (Dependency Inversion)
# ══════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class SendResult:
    """نتيجة موحّدة لأي إرسال — تحمي المجال من تفاصيل البوابة."""
    ok: bool
    external_reference: str = ""
    error: str = ""


@runtime_checkable
class SmsPort(Protocol):
    """منفذ إرسال SMS. التنفيذ في infrastructure (ACL adapter)."""
    async def send(self, phone: str, body: str) -> SendResult: ...


@runtime_checkable
class WhatsAppPort(Protocol):
    """منفذ إرسال WhatsApp. مستقل عن SMS لاختلاف البوّابة والقوالب."""
    async def send_text(self, phone: str, body: str) -> SendResult: ...


@runtime_checkable
class RealtimePort(Protocol):
    """منفذ البث اللحظي (WebSocket)."""
    async def broadcast(
        self, event: str, data: dict,
        *, floor: int | None = None, sound_event: str | None = None,
    ) -> SendResult: ...


# ══════════════════════════════════════════════════════════════
# Entity — محاولة إشعار واحدة (Aggregate Root)
# ══════════════════════════════════════════════════════════════
@dataclass
class NotificationEntity(Entity):
    """سجلّ محاولة إشعار. يحرس دورة الحياة وإعادة المحاولة.

    Invariants:
      - channel ضمن VALID_CHANNELS
      - قنوات RECIPIENT_REQUIRED تتطلّب recipient غير فارغ
      - attempts ≥ 0 و ≤ max_attempts
    """
    id: str
    message: NotificationMessage
    cause_event: str = ""
    cause_event_id: str = ""        # للـ idempotency
    status: str = "pending"
    attempts: int = 0
    max_attempts: int = DEFAULT_MAX_ATTEMPTS
    last_error: str = ""
    external_reference: str = ""
    created_at: str = ""
    last_attempt_at: str = ""

    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    def pull_events(self) -> list[DomainEvent]:
        ev, self._events = self._events, []
        return ev

    # ── Invariants ────────────────────────────────────────────
    def _check_invariants(self) -> None:
        if self.message.channel not in VALID_CHANNELS:
            raise InvariantViolationError(f"قناة إشعار غير معروفة: {self.message.channel}")
        if (self.message.channel in RECIPIENT_REQUIRED_CHANNELS
                and not self.message.recipient.strip()):
            raise InvariantViolationError(
                f"قناة {self.message.channel} تتطلّب مستلِماً")

    # ── منطق إعادة المحاولة (داخل الـ Entity) ──────────────────
    @property
    def can_retry(self) -> bool:
        return self.status == "failed" and self.attempts < self.max_attempts

    @property
    def is_terminal(self) -> bool:
        return self.status in NOTIFICATION_FSM.terminal

    @property
    def idempotency_key(self) -> str:
        """مفتاح idempotency مستقرّ: مشتقّ من (topic + channel + recipient + event_id).

        المفتاح هذا يُحدِّد محاولة فريدة منطقياً: نفس الحدث + نفس القناة +
        نفس المستلِم = نفس الإشعار، حتى لو أُعيد بثّ الحدث.
        """
        return derive_idempotency_key(
            cause_event=self.cause_event, channel=self.message.channel,
            recipient=self.message.recipient, cause_event_id=self.cause_event_id,
        )

    # ── Behaviours ────────────────────────────────────────────
    def mark_sent(self, *, at: str, external_reference: str = "") -> None:
        self.status = NOTIFICATION_FSM.transition(self.status, "sent")
        self.attempts += 1
        self.last_attempt_at = at
        self.external_reference = external_reference
        self._events.append(NotificationDispatched(
            notification_id=self.id, channel=self.message.channel,
            recipient=self.message.recipient, cause_event=self.cause_event,
            ok=True, attempt=self.attempts, external_reference=external_reference,
        ))

    def mark_failed(self, *, at: str, error: str) -> None:
        self.status = NOTIFICATION_FSM.transition(self.status, "failed")
        self.attempts += 1
        self.last_attempt_at = at
        self.last_error = error
        self._events.append(NotificationDispatched(
            notification_id=self.id, channel=self.message.channel,
            recipient=self.message.recipient, cause_event=self.cause_event,
            ok=False, attempt=self.attempts, error=error,
        ))
        # إن استُنفدت المحاولات → استنفاد نهائي + تنبيه تشغيلي
        if self.attempts >= self.max_attempts:
            self.status = NOTIFICATION_FSM.transition(self.status, "exhausted")
            self._events.append(NotificationExhausted(
                notification_id=self.id, channel=self.message.channel,
                recipient=self.message.recipient, cause_event=self.cause_event,
                attempts=self.attempts, last_error=error,
            ))

    def begin_retry(self) -> None:
        """يعيد المحاولة إلى pending (يُستدعى من event_queue قبل إعادة الإرسال)."""
        if not self.can_retry:
            raise InvariantViolationError("لا يمكن إعادة المحاولة في هذه الحالة")
        self.status = NOTIFICATION_FSM.transition(self.status, "pending")

    def suppress(self, reason: str) -> None:
        self.status = NOTIFICATION_FSM.transition(self.status, "suppressed")
        self.last_error = reason
        self._events.append(NotificationSuppressed(
            notification_id=self.id, channel=self.message.channel,
            cause_event=self.cause_event, reason=reason,
        ))
