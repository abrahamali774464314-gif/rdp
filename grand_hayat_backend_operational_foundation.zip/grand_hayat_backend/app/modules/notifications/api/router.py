from __future__ import annotations

from fastapi import APIRouter, Depends, Query

from kernel.security.query_scoper import Actor
from shared.api.responses import collection, success
from shared.auth.dependencies import require_permission
from shared.config.container import container
from shared.foundation.permissions import DEFAULT_SOUND_RULES, SOUND_EVENT_LABELS

router = APIRouter(prefix="/notifications", tags=["notifications"])


def _notification_to_dict(n) -> dict:
    return {
        "id": n.id,
        "channel": n.message.channel,
        "recipient": n.message.recipient,
        "body": n.message.body,
        "status": n.status,
        "attempts": n.attempts,
        "max_attempts": n.max_attempts,
        "last_error": n.last_error,
        "external_reference": n.external_reference,
        "cause_event": n.cause_event,
        "cause_event_id": n.cause_event_id,
        "created_at": n.created_at,
        "last_attempt_at": n.last_attempt_at,
        "sound_event": n.message.sound_event,
    }


@router.get("/sound-policy")
async def sound_policy(actor: Actor = Depends(require_permission("view_notifications"))):
    return success({"events": SOUND_EVENT_LABELS, "default_rules": DEFAULT_SOUND_RULES})


@router.get("/retryable")
async def list_retryable(limit: int = Query(default=100), actor: Actor = Depends(require_permission("manage_notifications"))):
    return collection([_notification_to_dict(n) for n in await container.notifications.list_retryable(limit=limit)])


@router.post("/{notification_id}/retry")
async def retry_notification(notification_id: str, actor: Actor = Depends(require_permission("manage_notifications"))):
    item = await container.notifications.retry(notification_id)
    return success(_notification_to_dict(item) if item else {"retryable": False, "notification_id": notification_id})
