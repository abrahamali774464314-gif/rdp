"""
modules.notifications.infrastructure.repository — التخزين + بوّابات الإرسال
═══════════════════════════════════════════════════════════════════

المكان **الوحيد** في النظام المسموح فيه بـ:
  - httpx (بوّابات SMS/WhatsApp الخارجية)
  - الوصول إلى ConnectionManager (WebSocket)
  - motor (حفظ سجلّ المحاولات)

أربع مسؤوليات (مجمّعة للحفاظ على نمط الـ 5 ملفات):
  ① MongoNotificationRepository  : audit trail (upsert عبر save)
  ② HttpSmsAdapter               : ينفّذ SmsPort
  ③ WhatsAppApiAdapter           : ينفّذ WhatsAppPort (بوّابة الأوائل)
  ④ WebSocketRealtimeAdapter     : ينفّذ RealtimePort

كل ما يتسرّب من العالم الخارجي يتحوّل إلى SendResult قبل أن يصل المجال.
httpx مستورد كسولاً (داخل الميثود) — يبقي بقية النظام قابلاً للاختبار بلا الحزمة.
"""
from __future__ import annotations

import base64
import logging
from typing import Awaitable, Callable

from kernel.persistence import session_kwargs
from modules.notifications.domain.models import (
    NotificationEntity, NotificationMessage,
    RealtimePort, SendResult, SmsPort, WhatsAppPort,
)
from modules.notifications.domain.repository import NotificationRepository

logger = logging.getLogger("grandhayat.notifications.infra")

COLLECTION = "notifications_log"
RETRYABLE_STATUSES = ["failed"]

SettingsProvider = Callable[[str], Awaitable[dict | None]]
UrlValidator = Callable[..., str]


# ══════════════════════════════════════════════════════════════
# ① Mongo Repository (save = upsert)
# ══════════════════════════════════════════════════════════════
class MongoNotificationRepository(NotificationRepository):
    def __init__(self, db) -> None:
        self._col = db[COLLECTION]

    @staticmethod
    def _to_entity(doc: dict) -> NotificationEntity:
        msg = NotificationMessage(
            channel=doc["channel"], recipient=doc.get("recipient", ""),
            body=doc.get("body", ""),
            payload=tuple(tuple(p) for p in (doc.get("payload") or [])),
            sound_event=doc.get("sound_event"),
        )
        return NotificationEntity(
            id=doc["id"], message=msg,
            cause_event=doc.get("cause_event", ""),
            cause_event_id=doc.get("cause_event_id", ""),
            status=doc.get("status", "pending"),
            attempts=int(doc.get("attempts", 0)),
            max_attempts=int(doc.get("max_attempts", 3)),
            last_error=doc.get("last_error", ""),
            external_reference=doc.get("external_reference", ""),
            created_at=doc.get("created_at", ""),
            last_attempt_at=doc.get("last_attempt_at", ""),
        )

    @staticmethod
    def _to_document(e: NotificationEntity) -> dict:
        return {
            "id": e.id, "channel": e.message.channel,
            "recipient": e.message.recipient, "body": e.message.body,
            "payload": [list(p) for p in e.message.payload],
            "sound_event": e.message.sound_event,
            "cause_event": e.cause_event, "cause_event_id": e.cause_event_id,
            "idempotency_key": e.idempotency_key,  # مشتقّ من الـ Entity (مستقرّ)
            "status": e.status, "attempts": e.attempts,
            "max_attempts": e.max_attempts, "last_error": e.last_error,
            "external_reference": e.external_reference,
            "created_at": e.created_at, "last_attempt_at": e.last_attempt_at,
        }

    async def get(self, notification_id: str) -> NotificationEntity | None:
        doc = await self._col.find_one({"id": notification_id}, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def add(self, notification: NotificationEntity, uow=None) -> NotificationEntity:
        await self._col.insert_one(self._to_document(notification), **session_kwargs(uow))
        return notification

    async def save(self, notification: NotificationEntity, uow=None) -> NotificationEntity:
        # upsert — يدعم الإدراج الأول وإعادة المحاولة بسطر واحد
        await self._col.update_one(
            {"id": notification.id},
            {"$set": self._to_document(notification)},
            upsert=True, **session_kwargs(uow),
        )
        return notification

    async def find_by_idempotency_key(
        self, idempotency_key: str,
    ) -> NotificationEntity | None:
        if not idempotency_key:
            return None
        doc = await self._col.find_one(
            {"idempotency_key": idempotency_key}, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def list_retryable(self, *, limit: int = 100) -> list[NotificationEntity]:
        docs = await self._col.find(
            {"status": {"$in": RETRYABLE_STATUSES}}, {"_id": 0}
        ).to_list(limit)
        return [self._to_entity(d) for d in docs]

    async def list_scoped(self, scoped_filter: dict, *, limit: int = 200) -> list[NotificationEntity]:
        limit = max(1, min(int(limit), 1000))
        docs = await self._col.find(scoped_filter or {}, {"_id": 0}).sort("created_at", -1).to_list(limit)
        return [self._to_entity(d) for d in docs]


# ══════════════════════════════════════════════════════════════
# مساعدات بوّابات HTTP المشتركة
# ══════════════════════════════════════════════════════════════
def _auth_headers(gw: dict) -> dict[str, str]:
    headers: dict[str, str] = {}
    if gw.get("auth_header_name") and gw.get("api_key"):
        prefix = (gw.get("auth_header_prefix") or "").strip()
        value = gw["api_key"].strip()
        headers[gw["auth_header_name"]] = f"{prefix} {value}".strip() if prefix else value
    provider = (gw.get("provider_name") or "").lower()
    if "twilio" in provider or "basic" in (gw.get("auth_header_prefix") or "").lower():
        key = (gw.get("api_key") or "").strip()
        if not key and gw.get("account_sid") and gw.get("auth_token"):
            key = f"{gw['account_sid']}:{gw['auth_token']}"
        if key:
            headers["Authorization"] = "Basic " + base64.b64encode(key.encode()).decode()
    return headers


# ══════════════════════════════════════════════════════════════
# ② HttpSmsAdapter — ينفّذ SmsPort
# ══════════════════════════════════════════════════════════════
class HttpSmsAdapter(SmsPort):
    def __init__(self, *, settings_provider: SettingsProvider,
                 url_validator: UrlValidator) -> None:
        self._settings = settings_provider
        self._validate_url = url_validator

    async def send(self, phone: str, body: str) -> SendResult:
        import httpx
        gw = await self._settings("sms_gateway")
        if not gw or not gw.get("enabled") or not gw.get("api_url"):
            return SendResult(ok=False, error="sms_gateway_disabled")
        try:
            url = self._validate_url(gw["api_url"], allow_http=bool(gw.get("allow_http")))
            params = {(gw.get("phone_field") or "to"): phone,
                      (gw.get("message_field") or "message"): body}
            sender = (gw.get("sender_id") or "").strip()
            if sender:
                params["From"] = sender
            method = (gw.get("api_method") or "POST").upper()
            async with httpx.AsyncClient(timeout=12.0, follow_redirects=False) as cli:
                resp = await (cli.get(url, params=params, headers=_auth_headers(gw))
                              if method == "GET"
                              else cli.post(url, data=params, headers=_auth_headers(gw)))
            if resp.status_code >= 400:
                return SendResult(ok=False, error=f"http_{resp.status_code}")
            return SendResult(ok=True, external_reference=resp.headers.get("X-Message-Id", ""))
        except Exception as exc:  # noqa: BLE001
            logger.warning("SMS send failed: %s", exc)
            return SendResult(ok=False, error=str(exc))


# ══════════════════════════════════════════════════════════════
# ③ WhatsAppApiAdapter — ينفّذ WhatsAppPort (بوّابة الأوائل)
# ══════════════════════════════════════════════════════════════
class WhatsAppApiAdapter(WhatsAppPort):
    """ACL لبوّابة WhatsApp (الأوائل). مستقل عن SMS لاختلاف الحقول/المصادقة."""

    def __init__(self, *, settings_provider: SettingsProvider,
                 url_validator: UrlValidator) -> None:
        self._settings = settings_provider
        self._validate_url = url_validator

    async def send_text(self, phone: str, body: str) -> SendResult:
        import httpx
        gw = await self._settings("whatsapp_gateway")
        # fallback: قد تشترك مع بوّابة SMS في بعض النشرات
        if not gw or not gw.get("enabled") or not gw.get("api_url"):
            gw = await self._settings("sms_gateway")
        if not gw or not gw.get("enabled") or not gw.get("api_url"):
            return SendResult(ok=False, error="whatsapp_gateway_disabled")
        try:
            url = self._validate_url(gw["api_url"], allow_http=bool(gw.get("allow_http")))
            params = {
                (gw.get("phone_field") or "to"): phone,
                (gw.get("message_field") or "message"): body,
                "type": "text",
            }
            method = (gw.get("api_method") or "POST").upper()
            async with httpx.AsyncClient(timeout=12.0, follow_redirects=False) as cli:
                resp = await (cli.get(url, params=params, headers=_auth_headers(gw))
                              if method == "GET"
                              else cli.post(url, data=params, headers=_auth_headers(gw)))
            if resp.status_code >= 400:
                return SendResult(ok=False, error=f"http_{resp.status_code}")
            return SendResult(ok=True, external_reference=resp.headers.get("X-Message-Id", ""))
        except Exception as exc:  # noqa: BLE001
            logger.warning("WhatsApp send failed: %s", exc)
            return SendResult(ok=False, error=str(exc))


# ══════════════════════════════════════════════════════════════
# ④ WebSocketRealtimeAdapter — ينفّذ RealtimePort
# ══════════════════════════════════════════════════════════════
class WebSocketRealtimeAdapter(RealtimePort):
    def __init__(self, *, connection_manager) -> None:
        self._manager = connection_manager

    async def broadcast(self, event: str, data: dict, *,
                        floor: int | None = None,
                        sound_event: str | None = None) -> SendResult:
        try:
            if sound_event and hasattr(self._manager, "broadcast_with_sound"):
                await self._manager.broadcast_with_sound(
                    event, data, floor=floor, sound_event=sound_event)
            else:
                await self._manager.broadcast(event, data, floor=floor)
            return SendResult(ok=True)
        except Exception as exc:  # noqa: BLE001
            logger.warning("WS broadcast failed: %s", exc)
            return SendResult(ok=False, error=str(exc))
