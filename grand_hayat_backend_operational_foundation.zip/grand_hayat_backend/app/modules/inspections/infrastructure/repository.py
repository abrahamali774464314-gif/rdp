"""
modules.inspections.infrastructure.repository — تنفيذ مستودع التقارير
═══════════════════════════════════════════════════════════════════

الطبقة الوحيدة المسموح فيها لمس motor/db لمجال الفحص (البند 3).
تنفّذ InspectionRepository وتترجم InspectionEntity ⇄ مستند MongoDB،
بما في ذلك تحويل البنود (InspectionItem) والمرفقات (InspectionAttachment).
"""
from __future__ import annotations

from kernel.persistence import session_kwargs
from shared.security.base_scoped_repository import ScopedRepositoryMixin
from modules.inspections.domain.models import (
    InspectionAttachment,
    InspectionEntity,
    InspectionItem,
)
from modules.inspections.domain.repository import InspectionRepository

COLLECTION = "room_inspections"


class MongoInspectionRepository(ScopedRepositoryMixin, InspectionRepository):
    _scope_sort_field = "created_at"
    _scope_sort_dir = -1
    _scope_default_limit = 300
    def __init__(self, db) -> None:
        self._col = db[COLLECTION]

    # ── Mappers ───────────────────────────────────────────────
    @staticmethod
    def _to_entity(doc: dict) -> InspectionEntity:
        entity = InspectionEntity(
            id=doc["id"],
            report_type=doc["report_type"],
            room_number=doc["room_number"],
            floor=doc["floor"],
            decision=doc.get("decision", "ready_for_cleaning"),
            decision_label=doc.get("decision_label", ""),
            notes=doc.get("notes", ""),
            status=doc.get("status", "completed"),
            checkout_id=doc.get("checkout_id"),
            request_id=doc.get("request_id"),
            created_by=doc.get("created_by", ""),
            created_by_name=doc.get("created_by_name", ""),
            created_at=doc.get("created_at", ""),
            tenant_id=doc.get("tenant_id", "default"),
            property_id=doc.get("property_id", "main"),
        )
        entity._items = [
            InspectionItem(
                category=i.get("category", "عام"),
                label=i.get("label", ""),
                done=bool(i.get("done")),
                note=i.get("note", ""),
            )
            for i in (doc.get("items") or [])
        ]
        entity._attachments = [
            InspectionAttachment(
                filename=a.get("filename", ""),
                original_name=a.get("original_name", ""),
                url=a.get("url", ""),
                uploaded_by=a.get("uploaded_by", ""),
                uploaded_by_name=a.get("uploaded_by_name", ""),
                created_at=a.get("created_at", ""),
            )
            for a in (doc.get("attachments") or [])
        ]
        return entity

    @staticmethod
    def _to_document(e: InspectionEntity) -> dict:
        return {
            "id": e.id,
            "report_type": e.report_type,
            "room_number": e.room_number,
            "floor": e.floor,
            "decision": e.decision,
            "decision_label": e.decision_label,
            "notes": e.notes,
            "status": e.status,
            "checkout_id": e.checkout_id,
            "request_id": e.request_id,
            "items": [
                {"category": i.category, "label": i.label, "done": i.done, "note": i.note}
                for i in e.items
            ],
            "attachments": [
                {
                    "filename": a.filename,
                    "original_name": a.original_name,
                    "url": a.url,
                    "uploaded_by": a.uploaded_by,
                    "uploaded_by_name": a.uploaded_by_name,
                    "created_at": a.created_at,
                }
                for a in e.attachments
            ],
            "created_by": e.created_by,
            "created_by_name": e.created_by_name,
            "created_at": e.created_at,
            "tenant_id": e.tenant_id,
            "property_id": e.property_id,
        }

    # ── Operations ────────────────────────────────────────────
    async def get(self, inspection_id: str) -> InspectionEntity | None:
        doc = await self._col.find_one({"id": inspection_id}, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def add(self, inspection: InspectionEntity, uow=None) -> InspectionEntity:
        await self._col.insert_one(self._to_document(inspection), **session_kwargs(uow))
        return inspection

    async def latest_for_checkout(self, checkout_id: str) -> InspectionEntity | None:
        doc = await self._col.find_one(
            {"checkout_id": checkout_id, "report_type": "checkout"},
            {"_id": 0},
            sort=[("created_at", -1)],
        )
        return self._to_entity(doc) if doc else None

    async def latest_for_request(self, request_id: str) -> InspectionEntity | None:
        doc = await self._col.find_one(
            {"request_id": request_id, "report_type": "housekeeping"},
            {"_id": 0},
            sort=[("created_at", -1)],
        )
        return self._to_entity(doc) if doc else None
