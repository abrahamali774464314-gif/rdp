"""Application service for room inspections."""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field

from kernel.bus import EventBus
from kernel.contracts import Command, Result
from kernel.clock import now_iso
from kernel.text import sanitize

from modules.inspections.domain.models import (
    InspectionAttachment,
    InspectionEntity,
    InspectionItem,
)
from modules.inspections.domain.repository import InspectionRepository

logger = logging.getLogger("grandhayat.inspections")

@dataclass(frozen=True)
class ItemInput:
    category: str
    label: str
    done: bool = False
    note: str = ""

@dataclass(frozen=True)
class AttachmentInput:
    filename: str
    original_name: str
    url: str

@dataclass(frozen=True)
class SubmitCheckoutInspection(Command):
    checkout_id: str
    room_number: int
    floor: int
    decision: str
    decision_label: str
    notes: str
    items: tuple[ItemInput, ...] = field(default_factory=tuple)
    attachments: tuple[AttachmentInput, ...] = field(default_factory=tuple)
    actor_id: str = ""
    actor_name: str = ""
    tenant_id: str = "default"
    property_id: str = "main"

@dataclass(frozen=True)
class SubmitHousekeepingInspection(Command):
    request_id: str
    room_number: int
    floor: int
    decision: str
    decision_label: str
    notes: str
    items: tuple[ItemInput, ...] = field(default_factory=tuple)
    attachments: tuple[AttachmentInput, ...] = field(default_factory=tuple)
    actor_id: str = ""
    actor_name: str = ""
    tenant_id: str = "default"
    property_id: str = "main"

class InspectionApplicationService:
    def __init__(self, *, inspections: InspectionRepository, uow_factory, bus: EventBus) -> None:
        self._inspections = inspections
        self._uow_factory = uow_factory
        self._bus = bus

    async def list_for(self, actor, *, own_only: bool = False, base_query: dict | None = None, limit: int | None = None):
        from shared.security.scoped_listing import scoped_list
        rules = getattr(self, "_scoping_rules", None)
        if rules is None:
            from kernel.security.scoping_rules import ScopingRules
            rules = ScopingRules()
        scoper = getattr(self, "_scoper", None)
        return await scoped_list(
            self._inspections, lambda a: rules.for_inspections(a, own_only=own_only), actor,
            scoper=scoper, base_query=base_query, limit=limit,
        )

    async def submit_checkout(self, cmd: SubmitCheckoutInspection) -> Result:
        entity = self._build(
            report_type="checkout", checkout_id=cmd.checkout_id, request_id=None,
            room_number=cmd.room_number, floor=cmd.floor, decision=cmd.decision,
            decision_label=cmd.decision_label, notes=cmd.notes, items=cmd.items,
            attachments=cmd.attachments, actor_id=cmd.actor_id, actor_name=cmd.actor_name,
            tenant_id=cmd.tenant_id, property_id=cmd.property_id,
        )
        return await self._finalise(entity)

    async def submit_housekeeping(self, cmd: SubmitHousekeepingInspection) -> Result:
        entity = self._build(
            report_type="housekeeping", checkout_id=None, request_id=cmd.request_id,
            room_number=cmd.room_number, floor=cmd.floor, decision=cmd.decision,
            decision_label=cmd.decision_label, notes=cmd.notes, items=cmd.items,
            attachments=cmd.attachments, actor_id=cmd.actor_id, actor_name=cmd.actor_name,
            tenant_id=cmd.tenant_id, property_id=cmd.property_id,
        )
        return await self._finalise(entity)

    def _build(self, *, report_type, checkout_id, request_id, room_number, floor,
               decision, decision_label, notes, items, attachments, actor_id,
               actor_name, tenant_id="default", property_id="main") -> InspectionEntity:
        created_at = now_iso()
        entity = InspectionEntity(
            id=str(uuid.uuid4()), report_type=report_type, room_number=room_number,
            floor=floor, decision=decision, decision_label=sanitize(decision_label, 200) or "",
            notes=sanitize(notes, 2000) or "", checkout_id=checkout_id,
            request_id=request_id, created_by=actor_id, created_by_name=actor_name,
            created_at=created_at, tenant_id=tenant_id, property_id=property_id,
        )
        entity.set_items([
            InspectionItem(
                category=sanitize(it.category, 120) or "عام",
                label=sanitize(it.label, 200) or "",
                done=bool(it.done),
                note=sanitize(it.note, 500) or "",
            ) for it in items if (it.label or "").strip()
        ])
        for att in attachments:
            entity.attach(InspectionAttachment(
                filename=att.filename, original_name=sanitize(att.original_name, 200) or att.filename,
                url=att.url, uploaded_by=actor_id, uploaded_by_name=actor_name,
                created_at=created_at,
            ))
        return entity

    async def _finalise(self, entity: InspectionEntity) -> Result:
        entity.complete()
        async with self._uow_factory() as uow:
            await self._inspections.add(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)
