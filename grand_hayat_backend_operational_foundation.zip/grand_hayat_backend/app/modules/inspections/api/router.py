from __future__ import annotations
from fastapi import APIRouter, Depends, Query, status
from pydantic import BaseModel, Field
from kernel.security.query_scoper import Actor
from modules.inspections.application.service import AttachmentInput, ItemInput, SubmitCheckoutInspection, SubmitHousekeepingInspection
from shared.auth.dependencies import require_permission
from shared.config.container import container

router = APIRouter(prefix="/inspections", tags=["inspections"])

class InspectionItemBody(BaseModel):
    category: str = "عام"
    label: str = Field(min_length=1, max_length=200)
    done: bool = False
    note: str = ""

class AttachmentBody(BaseModel):
    filename: str
    original_name: str = ""
    url: str

class CheckoutInspectionBody(BaseModel):
    checkout_id: str = Field(min_length=1)
    room_number: int = Field(ge=1)
    floor: int = Field(ge=1)
    decision: str = "ready_for_cleaning"
    decision_label: str = ""
    notes: str = ""
    items: list[InspectionItemBody] = Field(default_factory=list)
    attachments: list[AttachmentBody] = Field(default_factory=list)

class HousekeepingInspectionBody(BaseModel):
    request_id: str = Field(min_length=1)
    room_number: int = Field(ge=1)
    floor: int = Field(ge=1)
    decision: str = "ready_for_guest"
    decision_label: str = ""
    notes: str = ""
    items: list[InspectionItemBody] = Field(default_factory=list)
    attachments: list[AttachmentBody] = Field(default_factory=list)

def _inspection_to_dict(i) -> dict:
    return {"id": i.id, "report_type": i.report_type, "room_number": i.room_number, "floor": i.floor, "decision": i.decision, "decision_label": i.decision_label, "notes": i.notes, "status": i.status, "checkout_id": i.checkout_id, "request_id": i.request_id, "items": [{"category": x.category, "label": x.label, "done": x.done, "note": x.note} for x in i.items], "attachments": [{"filename": a.filename, "original_name": a.original_name, "url": a.url} for a in i.attachments], "created_by": i.created_by, "created_at": i.created_at, "tenant_id": i.tenant_id, "property_id": i.property_id}

@router.get("")
async def list_inspections(report_type: str | None = Query(default=None), actor: Actor = Depends(require_permission("view_room_inspections"))):
    base = {"report_type": report_type} if report_type else None
    return [_inspection_to_dict(i) for i in await container.inspections.list_for(actor, base_query=base)]

@router.post("/checkout", status_code=status.HTTP_201_CREATED)
async def submit_checkout_inspection(body: CheckoutInspectionBody, actor: Actor = Depends(require_permission("create_room_inspection"))):
    result = await container.inspections.submit_checkout(SubmitCheckoutInspection(tenant_id=actor.tenant_id or "default", property_id=actor.active_property_id or "main", actor_id=actor.id, actor_name=actor.name, items=tuple(ItemInput(**x.model_dump()) for x in body.items), attachments=tuple(AttachmentInput(**x.model_dump()) for x in body.attachments), checkout_id=body.checkout_id, room_number=body.room_number, floor=body.floor, decision=body.decision, decision_label=body.decision_label, notes=body.notes))
    return _inspection_to_dict(result.data)

@router.post("/housekeeping", status_code=status.HTTP_201_CREATED)
async def submit_housekeeping_inspection(body: HousekeepingInspectionBody, actor: Actor = Depends(require_permission("create_room_inspection"))):
    result = await container.inspections.submit_housekeeping(SubmitHousekeepingInspection(tenant_id=actor.tenant_id or "default", property_id=actor.active_property_id or "main", actor_id=actor.id, actor_name=actor.name, items=tuple(ItemInput(**x.model_dump()) for x in body.items), attachments=tuple(AttachmentInput(**x.model_dump()) for x in body.attachments), request_id=body.request_id, room_number=body.room_number, floor=body.floor, decision=body.decision, decision_label=body.decision_label, notes=body.notes))
    return _inspection_to_dict(result.data)
