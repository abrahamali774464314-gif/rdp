"""
modules.inspections.domain.models — كيان تقرير الفحص وسلوكه
═══════════════════════════════════════════════════════════════════

Domain Ownership: يملك التقرير وبنوده ومرفقاته وقراره فقط.
لا يلمس rooms ولا requests — ينشر أحداثاً، وتستجيب.

نقطة معمارية: «أي قرار يُصدر أي أحداث؟» منطق مجالي يعيش في الـ Entity
داخل _emit_decision_events. هذا يضمن أن أي تغيير في خريطة القرارات
يحدث في مكان واحد فقط (لا يتسرّب إلى الـ application أو الـ subscribers).

دورة الحياة:
  draft → completed  (لا تُعدَّل بعد الاكتمال — تقارير الفحص محفوظات
                       تشغيلية قريبة من المالية في حساسيتها)
"""
from __future__ import annotations

from dataclasses import dataclass, field

from kernel.contracts import DomainEvent, Entity
from kernel.errors import ConflictError, InvariantViolationError
from kernel.state_machine import StateMachine

from modules.inspections.domain.events import (
    InspectionCompleted,
    InspectionMaintenanceRequired,
    InspectionNetworkRequired,
    InspectionReadyForCleaning,
    InspectionRoomProblem,
    InspectionRoomReadyForGuest,
)

# ══════════════════════════════════════════════════════════════
# Constants
# ══════════════════════════════════════════════════════════════
REPORT_TYPES = frozenset({"checkout", "housekeeping"})

DECISION_READY_FOR_CLEANING   = "ready_for_cleaning"
DECISION_READY_FOR_GUEST      = "ready_for_guest"
DECISION_MAINTENANCE_REQUIRED = "maintenance_required"
DECISION_NETWORK_REQUIRED     = "network_required"
DECISION_ROOM_PROBLEM         = "room_problem"

VALID_DECISIONS = frozenset({
    DECISION_READY_FOR_CLEANING, DECISION_READY_FOR_GUEST,
    DECISION_MAINTENANCE_REQUIRED, DECISION_NETWORK_REQUIRED,
    DECISION_ROOM_PROBLEM,
})

# قرارات تستلزم متابعة من مجالات أخرى
FOLLOWUP_DECISIONS = frozenset({
    DECISION_MAINTENANCE_REQUIRED, DECISION_NETWORK_REQUIRED, DECISION_ROOM_PROBLEM,
})


# ══════════════════════════════════════════════════════════════
# Value Objects — بند فحص + مرفق (كلاهما frozen، لا تعديل)
# ══════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class InspectionItem:
    """بند فحص واحد: مصنّف بفئة، إمّا تامّ ✓ أو لا، مع ملاحظة اختيارية."""
    category: str
    label: str
    done: bool = False
    note: str = ""


@dataclass(frozen=True)
class InspectionAttachment:
    """مرفق صورة (مرجع التخزين فقط — الملف نفسه في filesystem/S3)."""
    filename: str
    original_name: str
    url: str
    uploaded_by: str
    uploaded_by_name: str
    created_at: str


# ══════════════════════════════════════════════════════════════
# State Machine — دورة حياة التقرير
# ══════════════════════════════════════════════════════════════
INSPECTION_FSM = StateMachine(
    name="inspection",
    transitions={
        "draft":     {"completed"},
        "completed": set(),   # نهائية — تقرير فحص لا يُعدَّل بعد الإصدار
    },
    terminal=frozenset({"completed"}),
)


# ══════════════════════════════════════════════════════════════
# Entity — تقرير الفحص (Aggregate Root)
# ══════════════════════════════════════════════════════════════
@dataclass
class InspectionEntity(Entity):
    """تقرير فحص غرفة. يملك بنوده ومرفقاته وقراره.

    Invariants:
      - report_type ضمن REPORT_TYPES
      - decision ضمن VALID_DECISIONS
      - room_number و floor موجبان
      - تقرير checkout مرتبط بـ checkout_id
      - تقرير housekeeping مرتبط بـ request_id
      - بعد الاكتمال: لا تعديل (FSM terminal)
    """
    id: str
    report_type: str
    room_number: int
    floor: int
    decision: str = DECISION_READY_FOR_CLEANING
    decision_label: str = ""
    notes: str = ""
    status: str = "draft"
    # ربط بالمجال المُنشئ (واحد منهما فقط)
    checkout_id: str | None = None
    request_id: str | None = None
    # محتوى التقرير
    _items: list[InspectionItem] = field(default_factory=list)
    _attachments: list[InspectionAttachment] = field(default_factory=list)
    # تدقيق
    created_by: str = ""
    created_by_name: str = ""
    created_at: str = ""
    tenant_id: str = "default"
    property_id: str = "main"

    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    def pull_events(self) -> list[DomainEvent]:
        ev, self._events = self._events, []
        return ev

    @property
    def items(self) -> tuple[InspectionItem, ...]:
        return tuple(self._items)

    @property
    def attachments(self) -> tuple[InspectionAttachment, ...]:
        return tuple(self._attachments)

    @property
    def requires_followup(self) -> bool:
        """منطق مجالي: هل هذا القرار يستلزم طلب متابعة من مجال آخر؟"""
        return self.decision in FOLLOWUP_DECISIONS

    # ── Invariants ────────────────────────────────────────────
    def _check_invariants(self) -> None:
        if self.report_type not in REPORT_TYPES:
            raise InvariantViolationError(f"نوع تقرير غير معروف: {self.report_type}")
        if self.decision not in VALID_DECISIONS:
            raise InvariantViolationError(f"قرار فحص غير معروف: {self.decision}")
        if self.room_number <= 0 or self.floor <= 0:
            raise InvariantViolationError("رقم الغرفة/الدور غير صالح")
        if self.report_type == "checkout" and not self.checkout_id:
            raise InvariantViolationError("تقرير الـ checkout يجب أن يرتبط بـ checkout_id")
        if self.report_type == "housekeeping" and not self.request_id:
            raise InvariantViolationError("تقرير النظافة يجب أن يرتبط بـ request_id")

    def _assert_mutable(self) -> None:
        if self.status in INSPECTION_FSM.terminal:
            raise ConflictError("تقرير الفحص مكتمل ولا يُعدَّل")

    # ── البناء التدريجي للتقرير (قبل الاكتمال) ──────────────────
    def set_items(self, items: list[InspectionItem]) -> None:
        self._assert_mutable()
        self._items = list(items)

    def attach(self, attachment: InspectionAttachment) -> None:
        self._assert_mutable()
        self._attachments.append(attachment)

    def set_decision(self, decision: str, label: str = "", notes: str = "") -> None:
        self._assert_mutable()
        if decision not in VALID_DECISIONS:
            raise InvariantViolationError(f"قرار فحص غير معروف: {decision}")
        self.decision = decision
        if label:
            self.decision_label = label
        if notes:
            self.notes = notes

    # ── Behaviour الرئيسي: إصدار التقرير ──────────────────────
    def complete(self) -> None:
        """يُصدر التقرير ويُترجم القرار إلى أحداث متخصّصة.

        بعد هذا الـ method: التقرير غير قابل للتعديل (FSM terminal).
        """
        self._check_invariants()
        self.status = INSPECTION_FSM.transition(self.status, "completed")

        # حدث عام للتدقيق والإشعارات
        self._events.append(InspectionCompleted(
            inspection_id=self.id, report_type=self.report_type,
            room_number=self.room_number, floor=self.floor,
            decision=self.decision, checkout_id=self.checkout_id,
            request_id=self.request_id, notes=self.notes,
            tenant_id=self.tenant_id, property_id=self.property_id,
        ))
        # أحداث متخصّصة بحسب القرار
        self._emit_decision_events()

    def _emit_decision_events(self) -> None:
        """خريطة القرار → الأحداث المتخصّصة (منطق مجالي مركزي).

        تغيير سلوك أي قرار يحدث هنا فقط — لا في الـ application ولا في
        أي subscriber. هذا يحمي العقد بين الفحص وبقيّة المجالات.
        """
        d = self.decision
        reason = self._followup_reason()

        if d == DECISION_READY_FOR_CLEANING:
            self._events.append(InspectionReadyForCleaning(
                inspection_id=self.id, room_number=self.room_number, floor=self.floor,
                tenant_id=self.tenant_id, property_id=self.property_id))

        elif d == DECISION_READY_FOR_GUEST:
            self._events.append(InspectionRoomReadyForGuest(
                inspection_id=self.id, room_number=self.room_number, floor=self.floor,
                tenant_id=self.tenant_id, property_id=self.property_id))

        elif d == DECISION_MAINTENANCE_REQUIRED:
            self._events.append(InspectionMaintenanceRequired(
                inspection_id=self.id, report_id=self.id,
                room_number=self.room_number, floor=self.floor, reason=reason,
                tenant_id=self.tenant_id, property_id=self.property_id))

        elif d == DECISION_NETWORK_REQUIRED:
            self._events.append(InspectionNetworkRequired(
                inspection_id=self.id, report_id=self.id,
                room_number=self.room_number, floor=self.floor, reason=reason,
                tenant_id=self.tenant_id, property_id=self.property_id))

        elif d == DECISION_ROOM_PROBLEM:
            self._events.append(InspectionRoomProblem(
                inspection_id=self.id, report_id=self.id,
                room_number=self.room_number, floor=self.floor, reason=reason,
                tenant_id=self.tenant_id, property_id=self.property_id))

    def _followup_reason(self) -> str:
        """يُلخّص سبب طلب المتابعة: notes أو ملاحظات البنود."""
        text = (self.notes or "").strip()
        if text:
            return text
        item_notes = [
            f"{it.label}: {it.note.strip()}"
            for it in self._items if (it.note or "").strip()
        ]
        if item_notes:
            return "؛ ".join(item_notes[:5])
        return "تم تسجيل ملاحظة من تقرير فحص الغرفة بدون تفاصيل إضافية."
