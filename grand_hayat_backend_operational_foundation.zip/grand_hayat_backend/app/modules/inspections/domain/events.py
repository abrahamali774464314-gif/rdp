"""Domain events for room inspections."""
from __future__ import annotations
from dataclasses import dataclass
from kernel.contracts import DomainEvent

@dataclass(frozen=True)
class InspectionCompleted(DomainEvent):
    topic = "inspections.completed"
    inspection_id: str = ""
    report_type: str = ""
    room_number: int = 0
    floor: int = 0
    decision: str = ""
    checkout_id: str | None = None
    request_id: str | None = None
    notes: str = ""
    tenant_id: str = "default"
    property_id: str = "main"

@dataclass(frozen=True)
class InspectionReadyForCleaning(DomainEvent):
    topic = "inspections.ready_for_cleaning"
    inspection_id: str = ""
    room_number: int = 0
    floor: int = 0
    tenant_id: str = "default"
    property_id: str = "main"

@dataclass(frozen=True)
class InspectionRoomReadyForGuest(DomainEvent):
    topic = "inspections.room_ready_for_guest"
    inspection_id: str = ""
    room_number: int = 0
    floor: int = 0
    tenant_id: str = "default"
    property_id: str = "main"

@dataclass(frozen=True)
class InspectionMaintenanceRequired(DomainEvent):
    topic = "inspections.maintenance_required"
    inspection_id: str = ""
    report_id: str = ""
    room_number: int = 0
    floor: int = 0
    reason: str = ""
    tenant_id: str = "default"
    property_id: str = "main"

@dataclass(frozen=True)
class InspectionNetworkRequired(DomainEvent):
    topic = "inspections.network_required"
    inspection_id: str = ""
    report_id: str = ""
    room_number: int = 0
    floor: int = 0
    reason: str = ""
    tenant_id: str = "default"
    property_id: str = "main"

@dataclass(frozen=True)
class InspectionRoomProblem(DomainEvent):
    topic = "inspections.room_problem"
    inspection_id: str = ""
    report_id: str = ""
    room_number: int = 0
    floor: int = 0
    reason: str = ""
    tenant_id: str = "default"
    property_id: str = "main"
