"""
modules.inspections.domain.repository — واجهة مستودع تقارير الفحص
═══════════════════════════════════════════════════════════════════

Repository Law (البند 4): الـ application يعتمد على هذا Protocol فقط.
التنفيذ في infrastructure ويترجم InspectionEntity ⇄ مستند MongoDB.
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable

from modules.inspections.domain.models import InspectionEntity


@runtime_checkable
class InspectionRepository(Protocol):
    """عقد تخزين تقارير الفحص."""

    async def get(self, inspection_id: str) -> InspectionEntity | None:
        """يجلب تقريراً بمعرّفه."""
        ...

    async def add(self, inspection: InspectionEntity, uow=None) -> InspectionEntity:
        """يُدرج تقريراً جديداً (يُستدعى عند الاكتمال — التقارير لا تُحفظ كمسوّدات
        في النظام الحالي، لكن البنية تسمح بذلك مستقبلاً)."""
        ...

    async def latest_for_checkout(self, checkout_id: str) -> InspectionEntity | None:
        """آخر تقرير checkout لمعرّف مغادرة معيّن (يستخدمه checkout لقراءة القرار)."""
        ...

    async def latest_for_request(self, request_id: str) -> InspectionEntity | None:
        """آخر تقرير housekeeping لطلب نظافة معيّن."""
        ...
