from __future__ import annotations
from fastapi import APIRouter, Depends, Query
from kernel.security.query_scoper import Actor
from shared.auth.dependencies import require_permission
from shared.config.container import container

router = APIRouter(prefix="/audit", tags=["audit"])

def _audit_to_dict(a) -> dict:
    return {"id": a.id, "action": a.action, "actor_id": a.actor_id, "resource_type": a.resource_type, "resource_id": a.resource_id, "before": a.before, "after": a.after, "metadata": a.metadata, "ip": a.ip, "user_agent": a.user_agent, "created_at": a.created_at, "tenant_id": a.tenant_id, "property_id": a.property_id}

@router.get("")
async def list_audit(action: str | None = Query(default=None), actor: Actor = Depends(require_permission("view_audit_logs"))):
    base = {"action": action} if action else None
    return [_audit_to_dict(a) for a in await container.audit.list_for(actor, base_query=base)]
