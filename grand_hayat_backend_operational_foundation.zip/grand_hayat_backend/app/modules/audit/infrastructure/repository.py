from __future__ import annotations
from kernel.persistence import session_kwargs
from modules.audit.domain.models import AuditEntryEntity
from modules.audit.domain.repository import AuditRepository

class MongoAuditRepository(AuditRepository):
    def __init__(self, db) -> None:
        self._col = db["audit_logs"]

    @staticmethod
    def _to_entity(doc: dict) -> AuditEntryEntity:
        return AuditEntryEntity(id=doc["id"], action=doc.get("action", ""), actor_id=doc.get("actor_id"), tenant_id=doc.get("tenant_id", "default"), property_id=doc.get("property_id", "main"), resource_type=doc.get("resource_type", ""), resource_id=doc.get("resource_id", ""), before=doc.get("before") or {}, after=doc.get("after") or {}, metadata=doc.get("metadata") or {}, ip=doc.get("ip", ""), user_agent=doc.get("user_agent", ""), created_at=doc.get("created_at", ""))

    @staticmethod
    def _to_doc(e: AuditEntryEntity) -> dict:
        return {"id": e.id, "action": e.action, "actor_id": e.actor_id, "tenant_id": e.tenant_id, "property_id": e.property_id, "resource_type": e.resource_type, "resource_id": e.resource_id, "before": dict(e.before or {}), "after": dict(e.after or {}), "metadata": dict(e.metadata or {}), "ip": e.ip, "user_agent": e.user_agent, "created_at": e.created_at}

    async def add(self, entry: AuditEntryEntity, uow=None) -> AuditEntryEntity:
        await self._col.insert_one(self._to_doc(entry), **session_kwargs(uow))
        return entry

    async def list_scoped(self, scoped_filter: dict, *, limit: int = 300) -> list[AuditEntryEntity]:
        limit = max(1, min(int(limit), 1000))
        docs = await self._col.find(scoped_filter or {}, {"_id": 0}).sort("created_at", -1).to_list(limit)
        return [self._to_entity(d) for d in docs]
