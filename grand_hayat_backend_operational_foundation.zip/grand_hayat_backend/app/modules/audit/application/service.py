from __future__ import annotations
import uuid
from dataclasses import dataclass, field
from kernel.bus import EventBus
from kernel.clock import now_iso
from kernel.contracts import Command, Result
from kernel.text import sanitize
from modules.audit.domain.models import AuditEntryEntity
from modules.audit.domain.repository import AuditRepository

@dataclass(frozen=True)
class RecordAudit(Command):
    action: str
    actor_id: str | None
    tenant_id: str
    property_id: str
    resource_type: str = ""
    resource_id: str = ""
    before: dict = field(default_factory=dict)
    after: dict = field(default_factory=dict)
    metadata: dict = field(default_factory=dict)
    ip: str = ""
    user_agent: str = ""

class AuditApplicationService:
    def __init__(self, *, audit: AuditRepository, uow_factory, bus: EventBus) -> None:
        self._audit = audit
        self._uow_factory = uow_factory
        self._bus = bus

    def _scope(self, actor, base: dict | None = None) -> dict:
        q = dict(base or {})
        if getattr(actor, "role", "") != "super_admin":
            q["tenant_id"] = actor.tenant_id or "default"
            q["property_id"] = actor.active_property_id or "main"
        return q

    async def list_for(self, actor, *, base_query: dict | None = None, limit: int = 300):
        return await self._audit.list_scoped(self._scope(actor, base_query), limit=limit)

    async def record(self, cmd: RecordAudit) -> Result:
        entry = AuditEntryEntity(
            id=str(uuid.uuid4()), action=sanitize(cmd.action, 120) or "unknown",
            actor_id=cmd.actor_id, tenant_id=cmd.tenant_id, property_id=cmd.property_id,
            resource_type=sanitize(cmd.resource_type, 80) or "", resource_id=sanitize(cmd.resource_id, 120) or "",
            before=dict(cmd.before or {}), after=dict(cmd.after or {}), metadata=dict(cmd.metadata or {}),
            ip=sanitize(cmd.ip, 80) or "", user_agent=sanitize(cmd.user_agent, 300) or "", created_at=now_iso(),
        )
        entry.record()
        async with self._uow_factory() as uow:
            await self._audit.add(entry, uow=uow)
        await self._bus.publish_all(entry.pull_events())
        return Result(data=entry)
