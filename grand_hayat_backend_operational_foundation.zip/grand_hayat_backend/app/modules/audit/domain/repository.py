from __future__ import annotations
from typing import Protocol, runtime_checkable
from modules.audit.domain.models import AuditEntryEntity

@runtime_checkable
class AuditRepository(Protocol):
    async def add(self, entry: AuditEntryEntity, uow=None) -> AuditEntryEntity: ...
    async def list_scoped(self, scoped_filter: dict, *, limit: int = 300) -> list[AuditEntryEntity]: ...
