from __future__ import annotations
from dataclasses import dataclass
from kernel.contracts import DomainEvent

@dataclass(frozen=True)
class AuditEntryRecorded(DomainEvent):
    audit_id: str
    action: str
    tenant_id: str
    property_id: str
    topic = "audit.recorded"
