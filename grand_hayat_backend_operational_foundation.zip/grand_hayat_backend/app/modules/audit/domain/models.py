from __future__ import annotations
from dataclasses import dataclass, field
from kernel.contracts import DomainEvent, Entity
from kernel.errors import InvariantViolationError
from modules.audit.domain.events import AuditEntryRecorded

@dataclass
class AuditEntryEntity(Entity):
    id: str
    action: str
    actor_id: str | None
    tenant_id: str
    property_id: str
    resource_type: str = ""
    resource_id: str = ""
    before: dict = field(default_factory=dict)
    after: dict = field(default_factory=dict)
    metadata: dict = field(default_factory=dict)
    ip: str = ""
    user_agent: str = ""
    created_at: str = ""
    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    def pull_events(self) -> list[DomainEvent]:
        ev, self._events = self._events, []
        return ev

    def record(self) -> None:
        if not self.action:
            raise InvariantViolationError("audit action مطلوب")
        if not self.tenant_id or not self.property_id:
            raise InvariantViolationError("tenant_id/property_id مطلوبان")
        self._events.append(AuditEntryRecorded(audit_id=self.id, action=self.action, tenant_id=self.tenant_id, property_id=self.property_id))
