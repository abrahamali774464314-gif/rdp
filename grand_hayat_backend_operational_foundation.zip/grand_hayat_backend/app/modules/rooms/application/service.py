"""Application service for the rooms module."""
from __future__ import annotations

import logging
from dataclasses import dataclass

from kernel.bus import EventBus
from kernel.clock import now_iso
from kernel.contracts import Command, Result
from kernel.errors import ConflictError, NotFoundError, PermissionDeniedError, ValidationError
from kernel.security.query_scoper import Actor
from kernel.security.scoping_rules import is_floor_allowed
from kernel.text import sanitize

from modules.rooms.domain.models import FloorEntity, RoomEntity, RoomTypeEntity, create_room_entity
from modules.rooms.domain.repository import RoomRepository
from shared.foundation.constants import ROOM_STATUSES

logger = logging.getLogger("grandhayat.rooms")


@dataclass(frozen=True)
class SetRoomRate(Command):
    room_number: int
    daily_rate: float
    actor: Actor | None = None
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class CreateFloor(Command):
    number: int
    name: str = ""
    rooms_per_floor: int = 0
    tenant_id: str = "default"
    property_id: str = "main"
    actor: Actor | None = None


@dataclass(frozen=True)
class CreateRoomType(Command):
    code: str
    name: str
    base_rate: float = 0.0
    capacity: int = 1
    max_occupancy: int = 1
    description: str = ""
    tenant_id: str = "default"
    property_id: str = "main"
    actor: Actor | None = None


@dataclass(frozen=True)
class CreateRoom(Command):
    number: int
    floor: int
    room_type_code: str = "standard"
    daily_rate: float | None = None
    tenant_id: str = "default"
    property_id: str = "main"
    actor: Actor | None = None


@dataclass(frozen=True)
class SetRoomStatus(Command):
    room_number: int
    status: str
    tenant_id: str = "default"
    property_id: str = "main"
    actor: Actor | None = None


class RoomApplicationService:
    """Coordinates room commands without knowing HTTP, Mongo, SMS, or WhatsApp."""

    def __init__(self, *, rooms: RoomRepository, uow_factory, bus: EventBus,
                 scoper=None, scoping_rules=None) -> None:
        self._rooms = rooms
        self._uow_factory = uow_factory
        self._bus = bus
        self._scoper = scoper
        self._scoping_rules = scoping_rules

    def _ensure_scoping(self):
        if self._scoper is None:
            from shared.security.mongo_query_scoper import MongoQueryScoper
            self._scoper = MongoQueryScoper()
        if self._scoping_rules is None:
            from kernel.security.scoping_rules import ScopingRules
            self._scoping_rules = ScopingRules()

    async def list_rooms_for(self, actor, *, base_query: dict | None = None):
        self._ensure_scoping()
        scope = self._scoping_rules.for_rooms(actor)
        scoped_filter = self._scoper.apply(base_query or {}, scope)
        return await self._rooms.list_scoped(scoped_filter)

    async def list_floors_for(self, actor, *, limit: int = 200):
        tenant_id, property_id = self._tenant_property(actor)
        floors = await self._rooms.list_floors(tenant_id=tenant_id, property_id=property_id, limit=limit)
        if getattr(actor, "role", "") in {"super_admin", "admin"}:
            return floors
        allowed = set(getattr(actor, "floors", frozenset()) or frozenset())
        return [f for f in floors if f.number in allowed]

    async def list_room_types_for(self, actor, *, limit: int = 200):
        tenant_id, property_id = self._tenant_property(actor)
        return await self._rooms.list_room_types(tenant_id=tenant_id, property_id=property_id, limit=limit)

    async def _get_room(self, number: int, *, tenant_id: str | None = None,
                        property_id: str | None = None):
        try:
            return await self._rooms.get_by_number(
                number, tenant_id=tenant_id, property_id=property_id,
            )
        except TypeError:
            return await self._rooms.get_by_number(number)

    @staticmethod
    def _tenant_property(actor: Actor | None) -> tuple[str, str]:
        return (getattr(actor, "tenant_id", None) or "default", getattr(actor, "active_property_id", None) or "main")

    @staticmethod
    def _ensure_actor_can_access(room, actor: Actor | None) -> None:
        if actor is None:
            return
        if actor.tenant_id and room.tenant_id != actor.tenant_id:
            raise PermissionDeniedError("لا يمكنك الوصول إلى بيانات Tenant آخر")
        if actor.active_property_id and room.property_id != actor.active_property_id:
            raise PermissionDeniedError("لا يمكنك الوصول إلى بيانات فندق/عقار آخر")
        if not is_floor_allowed(actor, room.floor):
            raise PermissionDeniedError("ليست لديك صلاحية لهذا الدور")

    async def _save_and_publish(self, room) -> None:
        async with self._uow_factory() as uow:
            await self._rooms.save(room, uow=uow)
        await self._bus.publish_all(room.pull_events())

    async def create_floor(self, cmd: CreateFloor) -> Result:
        existing = await self._rooms.get_floor(cmd.number, tenant_id=cmd.tenant_id, property_id=cmd.property_id)
        if existing:
            raise ConflictError("الدور موجود مسبقاً")
        floor = FloorEntity(
            number=cmd.number,
            name=sanitize(cmd.name, 80) or f"الدور {cmd.number}",
            rooms_per_floor=max(0, int(cmd.rooms_per_floor or 0)),
            tenant_id=cmd.tenant_id,
            property_id=cmd.property_id,
            created_at=now_iso(),
        )
        floor.create()
        async with self._uow_factory() as uow:
            await self._rooms.add_floor(floor, uow=uow)
        await self._bus.publish_all(floor.pull_events())
        return Result(data=floor)

    async def create_room_type(self, cmd: CreateRoomType) -> Result:
        code = sanitize(cmd.code, 80) or "standard"
        existing = await self._rooms.get_room_type(code, tenant_id=cmd.tenant_id, property_id=cmd.property_id)
        if existing:
            raise ConflictError("نوع الغرفة موجود مسبقاً")
        room_type = RoomTypeEntity(
            code=code,
            name=sanitize(cmd.name, 120) or code,
            base_rate=float(cmd.base_rate or 0),
            capacity=int(cmd.capacity or 1),
            max_occupancy=int(cmd.max_occupancy or cmd.capacity or 1),
            description=sanitize(cmd.description, 1000) or "",
            tenant_id=cmd.tenant_id,
            property_id=cmd.property_id,
            created_at=now_iso(),
        )
        room_type.create()
        async with self._uow_factory() as uow:
            await self._rooms.add_room_type(room_type, uow=uow)
        await self._bus.publish_all(room_type.pull_events())
        return Result(data=room_type)

    async def create_room(self, cmd: CreateRoom) -> Result:
        existing = await self._rooms.get_by_number(cmd.number, tenant_id=cmd.tenant_id, property_id=cmd.property_id)
        if existing:
            raise ConflictError("رقم الغرفة موجود مسبقاً")
        floor = await self._rooms.get_floor(cmd.floor, tenant_id=cmd.tenant_id, property_id=cmd.property_id)
        if not floor:
            raise NotFoundError("الدور غير موجود")
        room_type = await self._rooms.get_room_type(cmd.room_type_code, tenant_id=cmd.tenant_id, property_id=cmd.property_id)
        if not room_type:
            raise NotFoundError("نوع الغرفة غير موجود")
        if cmd.actor is not None and not is_floor_allowed(cmd.actor, cmd.floor):
            raise PermissionDeniedError("ليست لديك صلاحية لهذا الدور")
        room = RoomEntity(
            number=cmd.number,
            floor=cmd.floor,
            status="available",
            daily_rate=float(cmd.daily_rate if cmd.daily_rate is not None else room_type.base_rate),
            room_type_code=room_type.code,
            capacity=room_type.capacity,
            max_occupancy=room_type.max_occupancy,
            tenant_id=cmd.tenant_id,
            property_id=cmd.property_id,
        )
        create_room_entity(room)
        async with self._uow_factory() as uow:
            await self._rooms.add(room, uow=uow)
        await self._bus.publish_all(room.pull_events())
        return Result(data=room)

    async def set_rate(self, cmd: SetRoomRate) -> Result:
        room = await self._get_room(cmd.room_number, tenant_id=cmd.tenant_id, property_id=cmd.property_id)
        if not room:
            raise NotFoundError("الغرفة غير موجودة")
        self._ensure_actor_can_access(room, cmd.actor)
        room.set_daily_rate(cmd.daily_rate)
        await self._save_and_publish(room)
        return Result(data=room)

    async def set_status(self, cmd: SetRoomStatus) -> Result:
        if cmd.status not in ROOM_STATUSES:
            raise ValidationError("حالة الغرفة غير معتمدة")
        room = await self._get_room(cmd.room_number, tenant_id=cmd.tenant_id, property_id=cmd.property_id)
        if not room:
            raise NotFoundError("الغرفة غير موجودة")
        self._ensure_actor_can_access(room, cmd.actor)
        if cmd.status == room.status:
            return Result(data=room)
        if cmd.status == "cleaning":
            room.send_to_cleaning()
        elif cmd.status == "maintenance":
            room.send_to_maintenance()
        elif cmd.status == "dirty":
            room.mark_dirty()
        elif cmd.status == "inspected":
            room.mark_inspected()
        elif cmd.status == "out_of_order":
            room.send_out_of_order()
        elif cmd.status == "available":
            room.release()
        else:
            raise ValidationError("هذه الحالة لا يمكن ضبطها يدوياً")
        await self._save_and_publish(room)
        return Result(data=room)

    async def occupy_room(self, *, room_number: int, checkin_id: str, guest_name: str,
                          guest_phone: str, check_in_at: str,
                          expected_checkout_at: str | None,
                          tenant_id: str = "default", property_id: str = "main",
                          actor: Actor | None = None) -> None:
        room = await self._get_room(room_number, tenant_id=tenant_id, property_id=property_id)
        if not room:
            raise NotFoundError("الغرفة غير موجودة")
        self._ensure_actor_can_access(room, actor)
        if room.status == "occupied" and room.active_checkin_id == checkin_id:
            return
        room.occupy(
            checkin_id=checkin_id, guest_name=guest_name, guest_phone=guest_phone,
            check_in_at=check_in_at, expected_checkout_at=expected_checkout_at,
        )
        await self._save_and_publish(room)

    async def release_room(self, room_number: int, *, tenant_id: str = "default",
                           property_id: str = "main", actor: Actor | None = None) -> None:
        room = await self._get_room(room_number, tenant_id=tenant_id, property_id=property_id)
        if not room:
            return
        self._ensure_actor_can_access(room, actor)
        if room.status == "available" and not room.active_checkin_id:
            return
        room.release()
        await self._save_and_publish(room)

    async def cancel_room_occupancy(self, room_number: int, *, checkin_id: str | None = None,
                                    tenant_id: str = "default", property_id: str = "main",
                                    actor: Actor | None = None) -> None:
        room = await self._get_room(room_number, tenant_id=tenant_id, property_id=property_id)
        if not room:
            return
        self._ensure_actor_can_access(room, actor)
        if checkin_id and room.active_checkin_id and room.active_checkin_id != checkin_id:
            return
        room.cancel_occupancy()
        await self._save_and_publish(room)

    async def send_room_to_cleaning(self, room_number: int, *, tenant_id: str = "default",
                                    property_id: str = "main", actor: Actor | None = None) -> None:
        room = await self._get_room(room_number, tenant_id=tenant_id, property_id=property_id)
        if not room:
            return
        self._ensure_actor_can_access(room, actor)
        if room.status == "cleaning":
            return
        room.send_to_cleaning()
        await self._save_and_publish(room)

    async def send_room_to_maintenance(self, room_number: int, *, tenant_id: str = "default",
                                       property_id: str = "main", actor: Actor | None = None) -> None:
        room = await self._get_room(room_number, tenant_id=tenant_id, property_id=property_id)
        if not room:
            return
        self._ensure_actor_can_access(room, actor)
        if room.status == "maintenance":
            return
        room.send_to_maintenance()
        await self._save_and_publish(room)


class RoomEventSubscribers:
    def __init__(self, app: RoomApplicationService) -> None:
        self._app = app

    def register(self, bus: EventBus) -> None:
        bus.subscribe("checkins.registered", self._on_checkin_registered)
        bus.subscribe("checkins.deleted", self._on_checkin_deleted)
        bus.subscribe("checkouts.completed_ready_for_cleaning", self._to_cleaning)
        bus.subscribe("checkouts.completed_needs_maintenance", self._to_maintenance)
        bus.subscribe("inspections.room_ready_for_guest", self._to_available)
        bus.subscribe("inspections.maintenance_required", self._to_maintenance)
        bus.subscribe("inspections.network_required", self._to_maintenance)
        bus.subscribe("inspections.room_problem", self._to_maintenance)
        bus.subscribe("requests.completed_releases_room", self._to_available)

    async def _on_checkin_registered(self, event) -> None:
        await self._app.occupy_room(
            room_number=event.room_number, checkin_id=event.checkin_id,
            guest_name=event.guest_name, guest_phone=event.guest_phone,
            check_in_at=event.check_in_at, expected_checkout_at=event.expected_checkout_at,
            tenant_id=getattr(event, "tenant_id", "default"),
            property_id=getattr(event, "property_id", "main"),
        )

    async def _on_checkin_deleted(self, event) -> None:
        await self._app.cancel_room_occupancy(
            event.room_number,
            checkin_id=getattr(event, "checkin_id", None),
            tenant_id=getattr(event, "tenant_id", "default"),
            property_id=getattr(event, "property_id", "main"),
        )

    async def _to_cleaning(self, event) -> None:
        await self._app.send_room_to_cleaning(
            event.room_number,
            tenant_id=getattr(event, "tenant_id", "default"),
            property_id=getattr(event, "property_id", "main"),
        )

    async def _to_maintenance(self, event) -> None:
        await self._app.send_room_to_maintenance(
            event.room_number,
            tenant_id=getattr(event, "tenant_id", "default"),
            property_id=getattr(event, "property_id", "main"),
        )

    async def _to_available(self, event) -> None:
        await self._app.release_room(
            event.room_number,
            tenant_id=getattr(event, "tenant_id", "default"),
            property_id=getattr(event, "property_id", "main"),
        )
