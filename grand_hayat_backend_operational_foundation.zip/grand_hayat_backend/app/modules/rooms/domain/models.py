"""
modules.rooms.domain.models — كيان الغرفة وسلوكها
═══════════════════════════════════════════════════════════════════

قلب المجال (Domain Layer). قيوده الدستورية:
  ✗ لا motor / لا db          (Repository Law — البند 3)
  ✗ لا FastAPI / لا Pydantic  (الـ DTO يعيش في طبقة الـ API)
  ✗ لا side effects           (SMS/WS/HTTP — البند 2)
  ✓ منطق نقي + invariants + انتقالات حالة عبر FSM فقط

كل تغيير حالة يمرّ عبر ROOM_FSM.transition (البند 4: State Machine Authority).
لا يُسنَد حقل status بإسناد مباشر أبداً.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from kernel.contracts import DomainEvent, Entity
from kernel.errors import ConflictError, InvariantViolationError
from kernel.state_machine import StateMachine

from modules.rooms.domain.events import (
    RoomEnteredCleaning,
    RoomEnteredMaintenance,
    RoomOccupied,
    RoomReleased,
    RoomStateChanged,
    FloorCreated,
    RoomTypeCreated,
    RoomCreated,
)

# ══════════════════════════════════════════════════════════════
# State Machine — السلطة الوحيدة لتغيير حالة الغرفة
# ══════════════════════════════════════════════════════════════
ROOM_FSM = StateMachine(
    name="room",
    transitions={
        # ملاحظة: الخروج الطبيعي يمرّ بالتنظيف (occupied → cleaning → available).
        # العودة المباشرة occupied → available مسموحة فقط كمسار إلغاء إداري
        # (التسكين أُلغي ولم يحدث فعلياً)، عبر RoomEntity.cancel_occupancy().
        "available":    {"occupied", "reserved", "dirty", "cleaning", "maintenance", "out_of_order"},
        "reserved":     {"occupied", "available", "maintenance", "out_of_order"},
        "occupied":     {"dirty", "cleaning", "maintenance", "available", "out_of_order"},
        "dirty":        {"cleaning", "maintenance", "out_of_order"},
        "cleaning":     {"inspected", "available", "maintenance", "out_of_order"},
        "inspected":    {"available", "maintenance", "out_of_order"},
        "maintenance":  {"available", "cleaning", "out_of_order"},
        "out_of_order": {"maintenance", "available"},
    },
)


# ══════════════════════════════════════════════════════════════
# Entity — الغرفة (Aggregate Root لمجال الغرف)
# ══════════════════════════════════════════════════════════════
@dataclass
class RoomEntity(Entity):
    """كيان الغرفة. يملك حالته وبياناته التشغيلية بالكامل (Domain Ownership).

    Invariants:
      - occupied ⇒ يجب وجود active_checkin_id
      - daily_rate ≥ 0
      - الخروج من occupied يمسح بيانات النزيل
    """
    number: int
    floor: int
    status: str = "available"
    daily_rate: float = 0.0
    room_type_code: str = "standard"
    capacity: int = 1
    max_occupancy: int = 1
    guest_name: str | None = None
    guest_phone: str | None = None
    check_in_at: str | None = None
    expected_checkout_at: str | None = None
    active_checkin_id: str | None = None
    welcome_sms_sent_at: str | None = None
    welcome_sms_phone: str | None = None
    is_deleted: bool = False
    tenant_id: str = "default"
    property_id: str = "main"

    # أحداث متراكمة تُنشر بعد نجاح الحفظ (collect-then-publish)
    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    @property
    def id(self) -> str:  # type: ignore[override]
        return str(self.number)

    def pull_events(self) -> list[DomainEvent]:
        events, self._events = self._events, []
        return events

    # ── Invariants ────────────────────────────────────────────
    def _check_invariants(self) -> None:
        if self.status == "occupied" and not self.active_checkin_id:
            raise InvariantViolationError("غرفة مشغولة بلا تسكين نشط")
        if self.daily_rate < 0:
            raise InvariantViolationError("سعر الغرفة لا يمكن أن يكون سالباً")
        if self.capacity < 1 or self.max_occupancy < 1:
            raise InvariantViolationError("سعة الغرفة يجب أن تكون أكبر من صفر")
        if self.max_occupancy < self.capacity:
            raise InvariantViolationError("الحد الأعلى للنزلاء لا يجب أن يكون أقل من السعة الأساسية")
        if not (self.room_type_code or "").strip():
            raise InvariantViolationError("نوع الغرفة مطلوب")

    def _transition_to(self, target: str) -> str:
        """البوابة الوحيدة لتغيير الحالة. تمرّ عبر FSM وتسجّل حدث التغيير."""
        old = self.status
        new = ROOM_FSM.transition(self.status, target)
        self.status = new
        if old != new:
            self._events.append(RoomStateChanged(
                room_number=self.number, floor=self.floor,
                old_status=old, new_status=new,
                tenant_id=self.tenant_id, property_id=self.property_id,
            ))
        return new

    def _clear_guest(self) -> None:
        self.active_checkin_id = None
        self.guest_name = None
        self.guest_phone = None
        self.check_in_at = None
        self.expected_checkout_at = None
        self.welcome_sms_sent_at = None
        self.welcome_sms_phone = None

    # ── Behaviours ────────────────────────────────────────────
    def occupy(self, *, checkin_id: str, guest_name: str, guest_phone: str,
               check_in_at: str, expected_checkout_at: str | None) -> None:
        if self.status == "occupied" or self.active_checkin_id:
            raise ConflictError("الغرفة مشغولة بالفعل")
        self._transition_to("occupied")
        self.active_checkin_id = checkin_id
        self.guest_name = guest_name
        self.guest_phone = guest_phone
        self.check_in_at = check_in_at
        self.expected_checkout_at = expected_checkout_at
        self.welcome_sms_sent_at = None
        self.welcome_sms_phone = None
        self._check_invariants()
        self._events.append(RoomOccupied(
            room_number=self.number, floor=self.floor, checkin_id=checkin_id,
            guest_name=guest_name, guest_phone=guest_phone,
            tenant_id=self.tenant_id, property_id=self.property_id,
        ))

    def release(self) -> None:
        """خروج طبيعي: الغرفة جاهزة للبيع بعد التنظيف/الفحص (cleaning → available)."""
        self._transition_to("available")
        self._clear_guest()
        self._check_invariants()
        self._events.append(RoomReleased(room_number=self.number, floor=self.floor, tenant_id=self.tenant_id, property_id=self.property_id))

    def cancel_occupancy(self) -> None:
        """إلغاء إداري للإشغال (التسكين أُلغي). يعيد الغرفة متاحة مباشرة."""
        if self.status != "occupied":
            return
        self._transition_to("available")
        self._clear_guest()
        self._check_invariants()
        self._events.append(RoomReleased(room_number=self.number, floor=self.floor, tenant_id=self.tenant_id, property_id=self.property_id))

    def send_to_cleaning(self) -> None:
        self._transition_to("cleaning")
        self._clear_guest()
        self._check_invariants()
        self._events.append(RoomEnteredCleaning(room_number=self.number, floor=self.floor, tenant_id=self.tenant_id, property_id=self.property_id))

    def send_to_maintenance(self) -> None:
        self._transition_to("maintenance")
        self._clear_guest()
        self._check_invariants()
        self._events.append(RoomEnteredMaintenance(room_number=self.number, floor=self.floor, tenant_id=self.tenant_id, property_id=self.property_id))

    def mark_dirty(self) -> None:
        self._transition_to("dirty")
        self._clear_guest()
        self._check_invariants()

    def mark_inspected(self) -> None:
        self._transition_to("inspected")
        self._check_invariants()

    def send_out_of_order(self) -> None:
        self._transition_to("out_of_order")
        self._clear_guest()
        self._check_invariants()

    def set_daily_rate(self, rate: float) -> None:
        if rate < 0:
            raise InvariantViolationError("سعر الغرفة لا يمكن أن يكون سالباً")
        self.daily_rate = rate
        self._check_invariants()


@dataclass
class FloorEntity(Entity):
    number: int
    name: str
    tenant_id: str = "default"
    property_id: str = "main"
    rooms_per_floor: int = 0
    is_deleted: bool = False
    created_at: str = ""
    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    @property
    def id(self) -> str:  # type: ignore[override]
        return f"{self.tenant_id}:{self.property_id}:floor:{self.number}"

    def pull_events(self) -> list[DomainEvent]:
        events, self._events = self._events, []
        return events

    def create(self) -> None:
        if self.number < 1:
            raise InvariantViolationError("رقم الدور غير صحيح")
        if not (self.name or "").strip():
            raise InvariantViolationError("اسم الدور مطلوب")
        self._events.append(FloorCreated(tenant_id=self.tenant_id, property_id=self.property_id, number=self.number, name=self.name))


@dataclass
class RoomTypeEntity(Entity):
    code: str
    name: str
    tenant_id: str = "default"
    property_id: str = "main"
    base_rate: float = 0.0
    capacity: int = 1
    max_occupancy: int = 1
    description: str = ""
    is_active: bool = True
    created_at: str = ""
    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    @property
    def id(self) -> str:  # type: ignore[override]
        return f"{self.tenant_id}:{self.property_id}:room_type:{self.code}"

    def pull_events(self) -> list[DomainEvent]:
        events, self._events = self._events, []
        return events

    def create(self) -> None:
        if not (self.code or "").strip():
            raise InvariantViolationError("كود نوع الغرفة مطلوب")
        if not (self.name or "").strip():
            raise InvariantViolationError("اسم نوع الغرفة مطلوب")
        if self.base_rate < 0:
            raise InvariantViolationError("السعر الأساسي لا يمكن أن يكون سالباً")
        if self.capacity < 1 or self.max_occupancy < 1:
            raise InvariantViolationError("السعة غير صحيحة")
        if self.max_occupancy < self.capacity:
            raise InvariantViolationError("الحد الأعلى للنزلاء لا يجب أن يكون أقل من السعة الأساسية")
        self._events.append(RoomTypeCreated(tenant_id=self.tenant_id, property_id=self.property_id, code=self.code, name=self.name))


def create_room_entity(room: RoomEntity) -> RoomEntity:
    room._check_invariants()
    room._events.append(RoomCreated(tenant_id=room.tenant_id, property_id=room.property_id, number=room.number, floor=room.floor, room_type_code=room.room_type_code))
    return room
