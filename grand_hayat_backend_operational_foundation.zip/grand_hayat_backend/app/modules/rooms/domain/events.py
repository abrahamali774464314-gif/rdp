"""modules.rooms.domain.events — أحداث مجال الغرف."""
from __future__ import annotations

from dataclasses import dataclass
from kernel.contracts import DomainEvent


@dataclass(frozen=True)
class RoomStateChanged(DomainEvent):
    topic = "rooms.state_changed"
    room_number: int = 0
    floor: int = 0
    old_status: str = ""
    new_status: str = ""
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class RoomOccupied(DomainEvent):
    topic = "rooms.occupied"
    room_number: int = 0
    floor: int = 0
    checkin_id: str = ""
    guest_name: str = ""
    guest_phone: str = ""
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class RoomReleased(DomainEvent):
    topic = "rooms.released"
    room_number: int = 0
    floor: int = 0
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class RoomEnteredCleaning(DomainEvent):
    topic = "rooms.entered_cleaning"
    room_number: int = 0
    floor: int = 0
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class RoomEnteredMaintenance(DomainEvent):
    topic = "rooms.entered_maintenance"
    room_number: int = 0
    floor: int = 0
    tenant_id: str = "default"
    property_id: str = "main"


@dataclass(frozen=True)
class FloorCreated(DomainEvent):
    topic = "rooms.floor_created"
    tenant_id: str = "default"
    property_id: str = "main"
    number: int = 0
    name: str = ""


@dataclass(frozen=True)
class RoomTypeCreated(DomainEvent):
    topic = "rooms.room_type_created"
    tenant_id: str = "default"
    property_id: str = "main"
    code: str = ""
    name: str = ""


@dataclass(frozen=True)
class RoomCreated(DomainEvent):
    topic = "rooms.room_created"
    tenant_id: str = "default"
    property_id: str = "main"
    number: int = 0
    floor: int = 0
    room_type_code: str = "standard"
