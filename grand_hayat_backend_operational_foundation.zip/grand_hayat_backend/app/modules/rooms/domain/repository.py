"""modules.rooms.domain.repository — واجهة مستودع الغرف."""
from __future__ import annotations

from typing import Protocol, runtime_checkable
from modules.rooms.domain.models import FloorEntity, RoomEntity, RoomTypeEntity


@runtime_checkable
class RoomRepository(Protocol):
    async def get_by_number(
        self, number: int, *, tenant_id: str | None = None, property_id: str | None = None
    ) -> RoomEntity | None:
        ...

    async def add(self, room: RoomEntity, uow=None) -> RoomEntity:
        ...

    async def save(self, room: RoomEntity, uow=None) -> RoomEntity:
        ...

    async def list_occupied(self) -> list[RoomEntity]:
        ...

    async def find_by_guest_phone(
        self, phone: str, *, tenant_id: str | None = None, property_id: str | None = None
    ) -> RoomEntity | None:
        ...

    async def list_scoped(self, scoped_filter: dict, *, limit: int = 5000) -> list[RoomEntity]:
        ...

    async def get_floor(self, number: int, *, tenant_id: str, property_id: str) -> FloorEntity | None:
        ...

    async def add_floor(self, floor: FloorEntity, uow=None) -> FloorEntity:
        ...

    async def list_floors(self, *, tenant_id: str, property_id: str, limit: int = 200) -> list[FloorEntity]:
        ...

    async def get_room_type(self, code: str, *, tenant_id: str, property_id: str) -> RoomTypeEntity | None:
        ...

    async def add_room_type(self, room_type: RoomTypeEntity, uow=None) -> RoomTypeEntity:
        ...

    async def list_room_types(self, *, tenant_id: str, property_id: str, limit: int = 200) -> list[RoomTypeEntity]:
        ...
