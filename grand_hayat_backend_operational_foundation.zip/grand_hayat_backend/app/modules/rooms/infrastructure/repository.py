"""modules.rooms.infrastructure.repository — Mongo implementation for rooms/floors/types."""
from __future__ import annotations

from kernel.persistence import session_kwargs
from modules.rooms.domain.models import FloorEntity, RoomEntity, RoomTypeEntity
from modules.rooms.domain.repository import RoomRepository

ROOMS = "rooms"
FLOORS = "floors"
ROOM_TYPES = "room_types"


class MongoRoomRepository(RoomRepository):
    def __init__(self, db) -> None:
        self._rooms = db[ROOMS]
        self._floors = db[FLOORS]
        self._room_types = db[ROOM_TYPES]

    @staticmethod
    def _to_entity(doc: dict) -> RoomEntity:
        return RoomEntity(
            number=doc["number"],
            floor=doc["floor"],
            status=doc.get("status", "available"),
            daily_rate=float(doc.get("daily_rate") or doc.get("base_rate") or 0),
            room_type_code=doc.get("room_type_code") or doc.get("room_type") or "standard",
            capacity=int(doc.get("capacity") or 1),
            max_occupancy=int(doc.get("max_occupancy") or doc.get("capacity") or 1),
            guest_name=doc.get("guest_name"),
            guest_phone=doc.get("guest_phone"),
            check_in_at=doc.get("check_in_at"),
            expected_checkout_at=doc.get("expected_checkout_at"),
            active_checkin_id=doc.get("active_checkin_id"),
            welcome_sms_sent_at=doc.get("welcome_sms_sent_at"),
            welcome_sms_phone=doc.get("welcome_sms_phone"),
            is_deleted=bool(doc.get("is_deleted")),
            tenant_id=doc.get("tenant_id", "default"),
            property_id=doc.get("property_id", "main"),
        )

    @staticmethod
    def _to_document(room: RoomEntity) -> dict:
        return {
            "number": room.number,
            "floor": room.floor,
            "status": room.status,
            "daily_rate": room.daily_rate,
            "room_type_code": room.room_type_code,
            "capacity": room.capacity,
            "max_occupancy": room.max_occupancy,
            "guest_name": room.guest_name,
            "guest_phone": room.guest_phone,
            "check_in_at": room.check_in_at,
            "expected_checkout_at": room.expected_checkout_at,
            "active_checkin_id": room.active_checkin_id,
            "welcome_sms_sent_at": room.welcome_sms_sent_at,
            "welcome_sms_phone": room.welcome_sms_phone,
            "is_deleted": room.is_deleted,
            "tenant_id": room.tenant_id,
            "property_id": room.property_id,
        }

    @staticmethod
    def _floor_to_entity(doc: dict) -> FloorEntity:
        return FloorEntity(
            number=int(doc["number"]),
            name=doc.get("name") or f"الدور {doc['number']}",
            tenant_id=doc.get("tenant_id", "default"),
            property_id=doc.get("property_id", "main"),
            rooms_per_floor=int(doc.get("rooms_per_floor") or 0),
            is_deleted=bool(doc.get("is_deleted")),
            created_at=doc.get("created_at", ""),
        )

    @staticmethod
    def _floor_to_document(floor: FloorEntity) -> dict:
        return {
            "number": floor.number,
            "name": floor.name,
            "tenant_id": floor.tenant_id,
            "property_id": floor.property_id,
            "rooms_per_floor": floor.rooms_per_floor,
            "is_deleted": floor.is_deleted,
            "created_at": floor.created_at,
        }

    @staticmethod
    def _type_to_entity(doc: dict) -> RoomTypeEntity:
        return RoomTypeEntity(
            code=doc["code"],
            name=doc.get("name", ""),
            tenant_id=doc.get("tenant_id", "default"),
            property_id=doc.get("property_id", "main"),
            base_rate=float(doc.get("base_rate") or 0),
            capacity=int(doc.get("capacity") or 1),
            max_occupancy=int(doc.get("max_occupancy") or doc.get("capacity") or 1),
            description=doc.get("description", ""),
            is_active=bool(doc.get("is_active", True)),
            created_at=doc.get("created_at", ""),
        )

    @staticmethod
    def _type_to_document(room_type: RoomTypeEntity) -> dict:
        return {
            "code": room_type.code,
            "name": room_type.name,
            "tenant_id": room_type.tenant_id,
            "property_id": room_type.property_id,
            "base_rate": room_type.base_rate,
            "capacity": room_type.capacity,
            "max_occupancy": room_type.max_occupancy,
            "description": room_type.description,
            "is_active": room_type.is_active,
            "created_at": room_type.created_at,
        }

    async def get_by_number(
        self, number: int, *, tenant_id: str | None = None, property_id: str | None = None
    ) -> RoomEntity | None:
        query = {"number": number, "is_deleted": {"$ne": True}}
        if tenant_id:
            query["tenant_id"] = tenant_id
        if property_id:
            query["property_id"] = property_id
        doc = await self._rooms.find_one(query, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def add(self, room: RoomEntity, uow=None) -> RoomEntity:
        await self._rooms.insert_one(self._to_document(room), **session_kwargs(uow))
        return room

    async def save(self, room: RoomEntity, uow=None) -> RoomEntity:
        await self._rooms.update_one(
            {"number": room.number, "tenant_id": room.tenant_id, "property_id": room.property_id, "is_deleted": {"$ne": True}},
            {"$set": self._to_document(room)},
            upsert=True,
            **session_kwargs(uow),
        )
        return room

    async def list_occupied(self) -> list[RoomEntity]:
        docs = await self._rooms.find({"status": "occupied", "is_deleted": {"$ne": True}}, {"_id": 0}).to_list(2000)
        return [self._to_entity(d) for d in docs]

    async def find_by_guest_phone(
        self, phone: str, *, tenant_id: str | None = None, property_id: str | None = None
    ) -> RoomEntity | None:
        query = {"guest_phone": phone, "is_deleted": {"$ne": True}}
        if tenant_id:
            query["tenant_id"] = tenant_id
        if property_id:
            query["property_id"] = property_id
        doc = await self._rooms.find_one(query, {"_id": 0})
        return self._to_entity(doc) if doc else None

    async def list_scoped(self, scoped_filter: dict, *, limit: int = 5000) -> list[RoomEntity]:
        query = {"is_deleted": {"$ne": True}}
        if scoped_filter:
            query = {"$and": [query, scoped_filter]}
        docs = await self._rooms.find(query, {"_id": 0}).sort("number", 1).to_list(limit)
        return [self._to_entity(d) for d in docs]

    async def get_floor(self, number: int, *, tenant_id: str, property_id: str) -> FloorEntity | None:
        doc = await self._floors.find_one({"number": number, "tenant_id": tenant_id, "property_id": property_id, "is_deleted": {"$ne": True}}, {"_id": 0})
        return self._floor_to_entity(doc) if doc else None

    async def add_floor(self, floor: FloorEntity, uow=None) -> FloorEntity:
        await self._floors.insert_one(self._floor_to_document(floor), **session_kwargs(uow))
        return floor

    async def list_floors(self, *, tenant_id: str, property_id: str, limit: int = 200) -> list[FloorEntity]:
        docs = await self._floors.find({"tenant_id": tenant_id, "property_id": property_id, "is_deleted": {"$ne": True}}, {"_id": 0}).sort("number", 1).to_list(limit)
        return [self._floor_to_entity(d) for d in docs]

    async def get_room_type(self, code: str, *, tenant_id: str, property_id: str) -> RoomTypeEntity | None:
        doc = await self._room_types.find_one({"code": code, "tenant_id": tenant_id, "property_id": property_id, "is_active": {"$ne": False}}, {"_id": 0})
        return self._type_to_entity(doc) if doc else None

    async def add_room_type(self, room_type: RoomTypeEntity, uow=None) -> RoomTypeEntity:
        await self._room_types.insert_one(self._type_to_document(room_type), **session_kwargs(uow))
        return room_type

    async def list_room_types(self, *, tenant_id: str, property_id: str, limit: int = 200) -> list[RoomTypeEntity]:
        docs = await self._room_types.find({"tenant_id": tenant_id, "property_id": property_id, "is_active": {"$ne": False}}, {"_id": 0}).sort("name", 1).to_list(limit)
        return [self._type_to_entity(d) for d in docs]
