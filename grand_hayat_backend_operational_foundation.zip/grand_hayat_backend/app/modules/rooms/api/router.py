"""Thin FastAPI router for rooms/floors/room types."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from kernel.security.query_scoper import Actor
from modules.rooms.application.service import CreateFloor, CreateRoom, CreateRoomType, SetRoomRate, SetRoomStatus
from shared.api.responses import collection, success
from shared.auth.dependencies import require_permission
from shared.config.container import container
from shared.foundation.constants import ROOM_STATUSES

router = APIRouter(prefix="/rooms", tags=["rooms"])


class FloorBody(BaseModel):
    number: int = Field(ge=1, le=99)
    name: str | None = Field(default=None, max_length=80)
    rooms_per_floor: int = Field(default=0, ge=0, le=500)


class RoomTypeBody(BaseModel):
    code: str = Field(min_length=1, max_length=80)
    name: str = Field(min_length=1, max_length=120)
    base_rate: float = Field(default=0, ge=0)
    capacity: int = Field(default=1, ge=1, le=50)
    max_occupancy: int = Field(default=1, ge=1, le=100)
    description: str = Field(default="", max_length=1000)


class RoomBody(BaseModel):
    number: int = Field(ge=1)
    floor: int = Field(ge=1, le=99)
    room_type_code: str = Field(default="standard", min_length=1, max_length=80)
    daily_rate: float | None = Field(default=None, ge=0)


class SetRateBody(BaseModel):
    daily_rate: float = Field(ge=0)


class SetStatusBody(BaseModel):
    status: str


def _room_to_dict(room) -> dict:
    return {
        "number": room.number,
        "floor": room.floor,
        "status": room.status,
        "room_type_code": room.room_type_code,
        "capacity": room.capacity,
        "max_occupancy": room.max_occupancy,
        "guest_name": room.guest_name,
        "guest_phone": room.guest_phone,
        "check_in_at": room.check_in_at,
        "expected_checkout_at": room.expected_checkout_at,
        "active_checkin_id": room.active_checkin_id,
        "daily_rate": room.daily_rate,
        "tenant_id": getattr(room, "tenant_id", None),
        "property_id": getattr(room, "property_id", None),
    }


def _floor_to_dict(floor) -> dict:
    return {
        "number": floor.number,
        "name": floor.name,
        "rooms_per_floor": floor.rooms_per_floor,
        "tenant_id": floor.tenant_id,
        "property_id": floor.property_id,
        "is_deleted": floor.is_deleted,
        "created_at": floor.created_at,
    }


def _type_to_dict(room_type) -> dict:
    return {
        "code": room_type.code,
        "name": room_type.name,
        "base_rate": room_type.base_rate,
        "capacity": room_type.capacity,
        "max_occupancy": room_type.max_occupancy,
        "description": room_type.description,
        "is_active": room_type.is_active,
        "tenant_id": room_type.tenant_id,
        "property_id": room_type.property_id,
        "created_at": room_type.created_at,
    }


@router.get("/statuses")
async def room_statuses(actor: Actor = Depends(require_permission("view_rooms"))):
    return success(sorted(ROOM_STATUSES))


@router.get("/floors")
async def list_floors(actor: Actor = Depends(require_permission("view_rooms"))):
    return collection([_floor_to_dict(f) for f in await container.rooms.list_floors_for(actor)])


@router.post("/floors", status_code=status.HTTP_201_CREATED)
async def create_floor(body: FloorBody, actor: Actor = Depends(require_permission("manage_floors"))):
    result = await container.rooms.create_floor(CreateFloor(
        number=body.number,
        name=body.name or f"الدور {body.number}",
        rooms_per_floor=body.rooms_per_floor,
        tenant_id=actor.tenant_id or "default",
        property_id=actor.active_property_id or "main",
        actor=actor,
    ))
    return success(_floor_to_dict(result.data))


@router.get("/types")
async def list_room_types(actor: Actor = Depends(require_permission("view_rooms"))):
    return collection([_type_to_dict(t) for t in await container.rooms.list_room_types_for(actor)])


@router.post("/types", status_code=status.HTTP_201_CREATED)
async def create_room_type(body: RoomTypeBody, actor: Actor = Depends(require_permission("manage_room_types"))):
    result = await container.rooms.create_room_type(CreateRoomType(
        code=body.code,
        name=body.name,
        base_rate=body.base_rate,
        capacity=body.capacity,
        max_occupancy=body.max_occupancy,
        description=body.description,
        tenant_id=actor.tenant_id or "default",
        property_id=actor.active_property_id or "main",
        actor=actor,
    ))
    return success(_type_to_dict(result.data))


@router.get("")
async def list_rooms(
    status: str | None = Query(default=None),
    actor: Actor = Depends(require_permission("view_rooms")),
):
    base = {"status": status} if status else None
    rooms = await container.rooms.list_rooms_for(actor, base_query=base)
    return collection([_room_to_dict(r) for r in rooms])


@router.post("", status_code=status.HTTP_201_CREATED)
async def create_room(body: RoomBody, actor: Actor = Depends(require_permission("manage_rooms"))):
    result = await container.rooms.create_room(CreateRoom(
        number=body.number,
        floor=body.floor,
        room_type_code=body.room_type_code,
        daily_rate=body.daily_rate,
        tenant_id=actor.tenant_id or "default",
        property_id=actor.active_property_id or "main",
        actor=actor,
    ))
    return success(_room_to_dict(result.data))


@router.get("/{number}")
async def get_room(
    number: int,
    actor: Actor = Depends(require_permission("view_rooms")),
):
    rooms = await container.rooms.list_rooms_for(actor, base_query={"number": number})
    if not rooms:
        raise HTTPException(status_code=404, detail="الغرفة غير موجودة")
    return success(_room_to_dict(rooms[0]))


@router.patch("/{number}/rate")
async def set_room_rate(
    number: int,
    body: SetRateBody,
    actor: Actor = Depends(require_permission("manage_rooms")),
):
    result = await container.rooms.set_rate(SetRoomRate(
        room_number=number,
        daily_rate=body.daily_rate,
        actor=actor,
        tenant_id=actor.tenant_id or "default",
        property_id=actor.active_property_id or "main",
    ))
    return success({"room_number": number, "daily_rate": result.data.daily_rate})


@router.patch("/{number}/status")
async def set_room_status(
    number: int,
    body: SetStatusBody,
    actor: Actor = Depends(require_permission("manage_rooms")),
):
    result = await container.rooms.set_status(SetRoomStatus(
        room_number=number,
        status=body.status,
        tenant_id=actor.tenant_id or "default",
        property_id=actor.active_property_id or "main",
        actor=actor,
    ))
    return success(_room_to_dict(result.data))


@router.post("/{number}/send-to-cleaning", status_code=status.HTTP_204_NO_CONTENT)
async def send_to_cleaning(
    number: int,
    actor: Actor = Depends(require_permission("manage_rooms")),
):
    await container.rooms.send_room_to_cleaning(
        number,
        tenant_id=actor.tenant_id or "default",
        property_id=actor.active_property_id or "main",
        actor=actor,
    )


@router.post("/{number}/send-to-maintenance", status_code=status.HTTP_204_NO_CONTENT)
async def send_to_maintenance(
    number: int,
    actor: Actor = Depends(require_permission("manage_rooms")),
):
    await container.rooms.send_room_to_maintenance(
        number,
        tenant_id=actor.tenant_id or "default",
        property_id=actor.active_property_id or "main",
        actor=actor,
    )
