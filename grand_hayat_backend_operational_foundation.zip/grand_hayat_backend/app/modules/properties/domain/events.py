from __future__ import annotations
from dataclasses import dataclass
from kernel.contracts import DomainEvent

@dataclass(frozen=True)
class PropertyRegistered(DomainEvent):
    tenant_id: str
    property_id: str
    code: str
    name: str
    topic = "properties.registered"

@dataclass(frozen=True)
class PropertyUpdated(DomainEvent):
    tenant_id: str
    property_id: str
    topic = "properties.updated"
