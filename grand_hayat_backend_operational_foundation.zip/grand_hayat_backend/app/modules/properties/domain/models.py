from __future__ import annotations
from dataclasses import dataclass, field
from kernel.contracts import DomainEvent, Entity
from kernel.errors import InvariantViolationError
from modules.properties.domain.events import PropertyRegistered, PropertyUpdated

@dataclass
class TenantEntity(Entity):
    id: str
    name: str
    status: str = "active"
    created_at: str = ""
    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    def pull_events(self) -> list[DomainEvent]:
        events, self._events = self._events, []
        return events

    def validate(self) -> None:
        if not (self.id or "").strip():
            raise InvariantViolationError("tenant_id مطلوب")
        if not (self.name or "").strip():
            raise InvariantViolationError("اسم المستأجر/المالك مطلوب")
        if self.status not in {"active", "inactive"}:
            raise InvariantViolationError("حالة المستأجر غير صحيحة")

@dataclass
class PropertyEntity(Entity):
    id: str
    tenant_id: str
    code: str
    name: str
    city: str = ""
    country: str = "YE"
    timezone: str = "Asia/Aden"
    currency: str = "YER"
    status: str = "active"
    settings: dict = field(default_factory=dict)
    created_at: str = ""
    updated_at: str = ""
    _events: list[DomainEvent] = field(default_factory=list, repr=False, compare=False)

    def pull_events(self) -> list[DomainEvent]:
        events, self._events = self._events, []
        return events

    def _check(self) -> None:
        if not (self.tenant_id or "").strip():
            raise InvariantViolationError("tenant_id مطلوب")
        if not (self.id or "").strip():
            raise InvariantViolationError("property_id مطلوب")
        if not (self.code or "").strip():
            raise InvariantViolationError("كود العقار مطلوب")
        if not (self.name or "").strip():
            raise InvariantViolationError("اسم العقار مطلوب")
        if self.status not in {"active", "inactive", "maintenance"}:
            raise InvariantViolationError("حالة العقار غير صحيحة")

    def register(self) -> None:
        self._check()
        self._events.append(PropertyRegistered(
            tenant_id=self.tenant_id, property_id=self.id,
            code=self.code, name=self.name,
        ))

    def update_profile(self, *, name: str | None = None, city: str | None = None,
                       country: str | None = None, timezone: str | None = None,
                       currency: str | None = None, status: str | None = None,
                       updated_at: str = "") -> None:
        if name is not None:
            self.name = name
        if city is not None:
            self.city = city
        if country is not None:
            self.country = country
        if timezone is not None:
            self.timezone = timezone
        if currency is not None:
            self.currency = currency
        if status is not None:
            self.status = status
        self.updated_at = updated_at or self.updated_at
        self._check()
        self._events.append(PropertyUpdated(tenant_id=self.tenant_id, property_id=self.id))
