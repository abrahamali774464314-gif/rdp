from __future__ import annotations

from fastapi import APIRouter, Depends, status
from pydantic import BaseModel, Field

from kernel.security.query_scoper import Actor
from modules.properties.application.service import CreateProperty, UpdateProperty
from shared.api.responses import collection, success
from shared.auth.dependencies import require_permission
from shared.config.container import container

router = APIRouter(prefix="/properties", tags=["properties"])


class PropertyCreateBody(BaseModel):
    code: str = Field(min_length=1, max_length=80)
    name: str = Field(min_length=1, max_length=160)
    city: str = ""
    country: str = "YE"
    timezone: str = "Asia/Aden"
    currency: str = "YER"


class PropertyUpdateBody(BaseModel):
    name: str | None = None
    city: str | None = None
    country: str | None = None
    timezone: str | None = None
    currency: str | None = None
    status: str | None = None


def _property_to_dict(p) -> dict:
    return {"id": p.id, "tenant_id": p.tenant_id, "code": p.code, "name": p.name, "city": p.city, "country": p.country, "timezone": p.timezone, "currency": p.currency, "status": p.status}


@router.get("")
async def list_properties(actor: Actor = Depends(require_permission("view_properties"))):
    return collection([_property_to_dict(p) for p in await container.properties.list_for(actor)])


@router.post("", status_code=status.HTTP_201_CREATED)
async def create_property(body: PropertyCreateBody, actor: Actor = Depends(require_permission("manage_properties"))):
    result = await container.properties.create(CreateProperty(tenant_id=actor.tenant_id or "default", **body.model_dump()))
    return success(_property_to_dict(result.data))


@router.patch("/{property_id}")
async def update_property(property_id: str, body: PropertyUpdateBody, actor: Actor = Depends(require_permission("manage_properties"))):
    result = await container.properties.update(UpdateProperty(property_id=property_id, tenant_id=actor.tenant_id or "default", **body.model_dump()))
    return success(_property_to_dict(result.data))
