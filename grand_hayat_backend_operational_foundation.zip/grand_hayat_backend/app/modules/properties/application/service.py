from __future__ import annotations
import uuid
from dataclasses import dataclass
from kernel.bus import EventBus
from kernel.clock import now_iso
from kernel.contracts import Command, Result
from kernel.errors import ConflictError, NotFoundError
from kernel.text import sanitize
from modules.properties.domain.models import PropertyEntity, TenantEntity
from modules.properties.domain.repository import PropertyRepository

@dataclass(frozen=True)
class EnsureDefaultProperty(Command):
    tenant_id: str
    property_id: str
    property_name: str

@dataclass(frozen=True)
class CreateProperty(Command):
    tenant_id: str
    code: str
    name: str
    city: str = ""
    country: str = "YE"
    timezone: str = "Asia/Aden"
    currency: str = "YER"

@dataclass(frozen=True)
class UpdateProperty(Command):
    property_id: str
    tenant_id: str
    name: str | None = None
    city: str | None = None
    country: str | None = None
    timezone: str | None = None
    currency: str | None = None
    status: str | None = None

class PropertyApplicationService:
    def __init__(self, *, properties: PropertyRepository, uow_factory, bus: EventBus) -> None:
        self._properties = properties
        self._uow_factory = uow_factory
        self._bus = bus

    async def list_for(self, actor, *, limit: int = 200):
        if getattr(actor, "role", "") == "super_admin":
            q = {}
        else:
            q = {"tenant_id": actor.tenant_id or "default"}
            if getattr(actor, "active_property_id", None):
                q["id"] = actor.active_property_id
        return await self._properties.list_scoped(q, limit=limit)

    async def get(self, property_id: str, *, tenant_id: str | None = None) -> PropertyEntity | None:
        return await self._properties.get(property_id, tenant_id=tenant_id)

    async def create(self, cmd: CreateProperty) -> Result:
        existing = await self._properties.get(cmd.code, tenant_id=cmd.tenant_id)
        if existing:
            raise ConflictError("العقار موجود مسبقاً")
        entity = PropertyEntity(
            id=str(uuid.uuid4()), tenant_id=cmd.tenant_id,
            code=sanitize(cmd.code, 80) or "property",
            name=sanitize(cmd.name, 160) or "Property",
            city=sanitize(cmd.city, 120) or "", country=sanitize(cmd.country, 8) or "YE",
            timezone=sanitize(cmd.timezone, 80) or "Asia/Aden",
            currency=sanitize(cmd.currency, 8) or "YER",
            created_at=now_iso(), updated_at=now_iso(),
        )
        entity.register()
        async with self._uow_factory() as uow:
            await self._properties.add(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)

    async def update(self, cmd: UpdateProperty) -> Result:
        entity = await self._properties.get(cmd.property_id, tenant_id=cmd.tenant_id)
        if not entity:
            raise NotFoundError("العقار غير موجود")
        entity.update_profile(
            name=sanitize(cmd.name, 160) if cmd.name is not None else None,
            city=sanitize(cmd.city, 120) if cmd.city is not None else None,
            country=sanitize(cmd.country, 8) if cmd.country is not None else None,
            timezone=sanitize(cmd.timezone, 80) if cmd.timezone is not None else None,
            currency=sanitize(cmd.currency, 8) if cmd.currency is not None else None,
            status=cmd.status, updated_at=now_iso(),
        )
        async with self._uow_factory() as uow:
            await self._properties.save(entity, uow=uow)
        await self._bus.publish_all(entity.pull_events())
        return Result(data=entity)

    async def ensure_default(self, cmd: EnsureDefaultProperty) -> Result:
        tenant = await self._properties.get_tenant(cmd.tenant_id)
        now = now_iso()
        async with self._uow_factory() as uow:
            if tenant is None:
                tenant = TenantEntity(id=cmd.tenant_id, name=cmd.property_name, created_at=now)
                tenant.validate()
                await self._properties.save_tenant(tenant, uow=uow)
            prop = await self._properties.get(cmd.property_id, tenant_id=cmd.tenant_id)
            if prop is None:
                prop = PropertyEntity(
                    id=cmd.property_id, tenant_id=cmd.tenant_id, code=cmd.property_id,
                    name=cmd.property_name, created_at=now, updated_at=now,
                )
                prop.register()
                await self._properties.add(prop, uow=uow)
        if prop:
            await self._bus.publish_all(prop.pull_events())
        return Result(data=prop)
