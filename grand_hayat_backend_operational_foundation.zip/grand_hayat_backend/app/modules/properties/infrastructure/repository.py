from __future__ import annotations
from kernel.persistence import session_kwargs
from modules.properties.domain.models import PropertyEntity, TenantEntity
from modules.properties.domain.repository import PropertyRepository

class MongoPropertyRepository(PropertyRepository):
    def __init__(self, db) -> None:
        self._tenants = db["tenants"]
        self._properties = db["properties"]

    @staticmethod
    def _tenant_to_entity(doc: dict) -> TenantEntity:
        return TenantEntity(id=doc["id"], name=doc.get("name", ""), status=doc.get("status", "active"), created_at=doc.get("created_at", ""))

    @staticmethod
    def _tenant_to_doc(e: TenantEntity) -> dict:
        return {"id": e.id, "name": e.name, "status": e.status, "created_at": e.created_at}

    @staticmethod
    def _property_to_entity(doc: dict) -> PropertyEntity:
        return PropertyEntity(
            id=doc["id"], tenant_id=doc.get("tenant_id", "default"), code=doc.get("code", doc["id"]),
            name=doc.get("name", ""), city=doc.get("city", ""), country=doc.get("country", "YE"),
            timezone=doc.get("timezone", "Asia/Aden"), currency=doc.get("currency", "YER"),
            status=doc.get("status", "active"), settings=doc.get("settings") or {},
            created_at=doc.get("created_at", ""), updated_at=doc.get("updated_at", ""),
        )

    @staticmethod
    def _property_to_doc(e: PropertyEntity) -> dict:
        return {
            "id": e.id, "tenant_id": e.tenant_id, "code": e.code, "name": e.name,
            "city": e.city, "country": e.country, "timezone": e.timezone,
            "currency": e.currency, "status": e.status, "settings": dict(e.settings or {}),
            "created_at": e.created_at, "updated_at": e.updated_at,
        }

    async def get_tenant(self, tenant_id: str) -> TenantEntity | None:
        doc = await self._tenants.find_one({"id": tenant_id}, {"_id": 0})
        return self._tenant_to_entity(doc) if doc else None

    async def save_tenant(self, tenant: TenantEntity, uow=None) -> TenantEntity:
        await self._tenants.update_one({"id": tenant.id}, {"$set": self._tenant_to_doc(tenant)}, upsert=True, **session_kwargs(uow))
        return tenant

    async def get(self, property_id: str, *, tenant_id: str | None = None) -> PropertyEntity | None:
        q = {"id": property_id}
        if tenant_id:
            q["tenant_id"] = tenant_id
        doc = await self._properties.find_one(q, {"_id": 0})
        if not doc and tenant_id:
            doc = await self._properties.find_one({"tenant_id": tenant_id, "code": property_id}, {"_id": 0})
        return self._property_to_entity(doc) if doc else None

    async def add(self, property: PropertyEntity, uow=None) -> PropertyEntity:
        await self._properties.insert_one(self._property_to_doc(property), **session_kwargs(uow))
        return property

    async def save(self, property: PropertyEntity, uow=None) -> PropertyEntity:
        await self._properties.update_one({"id": property.id, "tenant_id": property.tenant_id}, {"$set": self._property_to_doc(property)}, upsert=True, **session_kwargs(uow))
        return property

    async def list_scoped(self, scoped_filter: dict, *, limit: int = 200) -> list[PropertyEntity]:
        limit = max(1, min(int(limit), 1000))
        docs = await self._properties.find(scoped_filter or {}, {"_id": 0}).sort("name", 1).to_list(limit)
        return [self._property_to_entity(d) for d in docs]
