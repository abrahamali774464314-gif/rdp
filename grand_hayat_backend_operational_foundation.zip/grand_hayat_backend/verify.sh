#!/usr/bin/env bash
set -euo pipefail

MANIFEST="MANIFEST.md"
if [[ ! -f "$MANIFEST" ]]; then
  echo "ERROR: MANIFEST.md not found" >&2
  exit 2
fi

bad=0
missing=0
checked=0
while IFS='|' read -r _ path_cell sha_cell _rest; do
  path=$(printf '%s' "$path_cell" | sed -n 's/.*`\(.*\)`.*/\1/p')
  sha=$(printf '%s' "$sha_cell" | sed -n 's/.*`\([0-9a-f]\{64\}\)`.*/\1/p')
  [[ -z "$path" || -z "$sha" ]] && continue
  [[ "$path" == "MANIFEST.md" ]] && continue
  if [[ ! -f "$path" ]]; then
    echo "MISSING  $path"
    missing=$((missing+1))
    continue
  fi
  actual=$(sha256sum "$path" | awk '{print $1}')
  if [[ "$actual" != "$sha" ]]; then
    echo "BAD      $path"
    echo " expected: $sha"
    echo " actual:   $actual"
    bad=$((bad+1))
  else
    echo "OK       $path"
  fi
  checked=$((checked+1))
done < "$MANIFEST"

echo "checked=$checked missing=$missing bad=$bad"
if [[ $missing -ne 0 || $bad -ne 0 ]]; then
  exit 1
fi
