# CHANGELOG — Operational PMS Foundation Batch

## Added

- `docs/MIGRATION_MAP.md` — lightweight map from legacy features to new modules.
- `docs/GAP_REGISTER.md` — open/closed operational gaps with next actions.
- `docs/API_CONTRACTS.md` — success/error envelope specification.
- `shared/api/responses.py` — standard API response helpers.
- `shared/foundation/permissions.py` — central roles, permissions, departments, request types, sound events, and role presets.
- `shared/auth/tokens.py` — JWT access/refresh helpers.
- `shared/auth/session_store.py` — Mongo-backed sessions and token blacklist helpers.
- Identity operational endpoints:
  - `POST /api/v1/identity/login`
  - `POST /api/v1/identity/refresh`
  - `POST /api/v1/identity/logout`
  - `GET /api/v1/identity/me`
  - `GET /api/v1/identity/sessions`
  - `POST /api/v1/identity/sessions/{session_id}/revoke`
  - `GET /api/v1/identity/permissions/catalog`
- Settings/sounds endpoints:
  - `GET /api/v1/settings/catalog`
  - `GET /api/v1/settings/sounds/events`
  - `GET /api/v1/settings/sounds/rules`
  - `PUT /api/v1/settings/sounds/rules`
- Rooms operational endpoints:
  - `GET /api/v1/rooms/statuses`
  - `GET/POST /api/v1/rooms/floors`
  - `GET/POST /api/v1/rooms/types`
  - `POST /api/v1/rooms`
  - `PATCH /api/v1/rooms/{number}/status`

## Changed

- Error handlers now return the standard API error envelope.
- Identity login now creates a persistent session and returns access/refresh tokens.
- Refresh tokens rotate and old refresh JTIs are blacklisted.
- Logout revokes the session and clears cookies.
- Password reset/deactivation revoke active user sessions.
- Development header auth is now disabled by default through `ALLOW_DEV_AUTH=false`.
- Realtime manager now applies server-side sound rules per actor role/floor.
- Rooms domain now includes floor and room-type entities inside the rooms bounded context.
- Mongo indexes now include sessions, token blacklist, floors, and room types.
- Container bootstrap seeds default property, default room type, optional default floor, super admin, property admin, and default sound rules.

## Verified

- `python -m compileall -q app tools tests` — passed.
- `python tools/check_architecture.py app` — passed.
- `pytest -q tests/architecture` — 215 passed, 12 existing pytest warnings.
