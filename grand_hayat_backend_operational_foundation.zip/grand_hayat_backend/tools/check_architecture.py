#!/usr/bin/env python3
"""
tools/check_architecture.py — فاحص المعمارية المستقل (Static Analysis)
═══════════════════════════════════════════════════════════════════

بديل خفيف عن import-linter بلا أي تبعية خارجية (يعتمد على ast فقط).
يفحص كل ملفات app/ ويرفع الانتهاكات الدستورية. يُرجع exit code 1 عند أي
انتهاك → يُفشل الـ CI (البند 5 و 6: المنع الآلي).

التشغيل:
    python tools/check_architecture.py app

القواعد المفروضة (مطابقة لـ .importlinter):
  R1  domain لا يستورد motor/pymongo/core.db            (Repository Law)
  R2  domain لا يستورد httpx/requests/fastapi/services.notify (No Side Effects)
  R3  domain لا يستورد domain آخر                        (Domain Isolation)
  R4  application لا يستورد application مجال آخر          (Event Bus only)
  R5  المجالات التشغيلية لا تستورد modules.billing        (Financial Separation)
  R6  api لا يستورد motor/pymongo/core.db/infrastructure  (Controller purity)
  R7  kernel لا يستورد modules/shared_platform            (Kernel purity)
"""
from __future__ import annotations

import ast
import os
import sys
from dataclasses import dataclass

OPERATIONAL_DOMAINS = {"rooms", "checkins", "checkouts", "requests", "inspections", "guests", "reservations", "properties", "messaging", "storage"}
ALL_DOMAINS = OPERATIONAL_DOMAINS | {"billing", "identity", "notifications", "settings", "audit"}

DB_MODULES = ("motor", "pymongo", "core.db")
SIDE_EFFECT_MODULES = ("httpx", "requests", "fastapi", "services.notify", "websockets")


@dataclass
class Violation:
    rule: str
    file: str
    line: int
    detail: str


def _imports(path: str) -> list[tuple[str, int]]:
    try:
        tree = ast.parse(open(path, encoding="utf-8").read(), filename=path)
    except SyntaxError as e:
        return [("<syntax-error>", e.lineno or 0)]
    out: list[tuple[str, int]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                out.append((a.name, node.lineno))
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                out.append((node.module, node.lineno))
    return out


def _module_path(file: str, root: str) -> str:
    rel = os.path.relpath(file, root).replace(os.sep, ".")
    return rel[:-3] if rel.endswith(".py") else rel


def _layer_of(modpath: str) -> tuple[str | None, str | None]:
    """يُرجع (domain, layer) إن كان داخل modules.*."""
    parts = modpath.split(".")
    if len(parts) >= 3 and parts[0] == "modules":
        return parts[1], parts[2]
    return None, None


def _starts_with_any(imp: str, prefixes: tuple[str, ...]) -> bool:
    return any(imp == p or imp.startswith(p + ".") for p in prefixes)


def check_file(file: str, root: str) -> list[Violation]:
    modpath = _module_path(file, root)
    domain, layer = _layer_of(modpath)
    violations: list[Violation] = []

    for imp, line in _imports(file):
        # R7 — kernel purity
        if modpath.startswith("kernel"):
            if _starts_with_any(imp, ("modules", "shared_platform")):
                violations.append(Violation("R7 kernel-purity", file, line, f"kernel يستورد «{imp}»"))
            continue

        if domain is None:
            continue

        # R1 — no DB in domain/application
        if layer in ("domain", "application") and _starts_with_any(imp, DB_MODULES):
            violations.append(Violation("R1 repository-law", file, line,
                                        f"{domain}.{layer} يستورد قاعدة بيانات «{imp}»"))

        # R2 — no side effects in domain
        if layer == "domain" and _starts_with_any(imp, SIDE_EFFECT_MODULES):
            violations.append(Violation("R2 no-side-effects", file, line,
                                        f"{domain}.domain يستورد side effect «{imp}»"))

        # R3 — domain isolation (domain ↛ domain آخر)
        if layer == "domain":
            other_d, other_l = _layer_of(imp if imp.startswith("modules") else "modules." + imp)
            if other_d and other_d != domain and other_d in ALL_DOMAINS:
                violations.append(Violation("R3 domain-isolation", file, line,
                                            f"{domain}.domain يستورد مجال آخر «{other_d}»"))

        # R4 — application isolation
        if layer == "application" and imp.startswith("modules."):
            other_d, other_l = _layer_of(imp)
            if other_d and other_d != domain and other_l == "application":
                violations.append(Violation("R4 application-isolation", file, line,
                                            f"{domain}.application يستدعي «{other_d}.application» مباشرة (استخدم الـ bus)"))

        # R5 — financial separation
        if domain in OPERATIONAL_DOMAINS and _starts_with_any(imp, ("modules.billing",)):
            violations.append(Violation("R5 financial-separation", file, line,
                                        f"المجال التشغيلي «{domain}» يستورد النواة المالية «{imp}»"))

        # R6 — controller purity
        if layer == "api":
            if _starts_with_any(imp, DB_MODULES):
                violations.append(Violation("R6 controller-purity", file, line,
                                            f"{domain}.api يلمس قاعدة البيانات «{imp}»"))
            other_d, other_l = _layer_of(imp if imp.startswith("modules") else "modules." + imp)
            if other_l == "infrastructure":
                violations.append(Violation("R6 controller-purity", file, line,
                                            f"{domain}.api يستورد infrastructure «{imp}»"))

    return violations


def main(root: str) -> int:
    all_violations: list[Violation] = []
    for dirpath, _dirs, files in os.walk(root):
        if "__pycache__" in dirpath:
            continue
        for f in files:
            if f.endswith(".py"):
                all_violations.extend(check_file(os.path.join(dirpath, f), root))

    if not all_violations:
        print("✅ لا انتهاكات معمارية. الدستور مُحترَم بالكامل.")
        return 0

    print(f"❌ {len(all_violations)} انتهاك معماري:\n")
    for v in sorted(all_violations, key=lambda x: (x.rule, x.file)):
        rel = os.path.relpath(v.file, root)
        print(f"  [{v.rule}] {rel}:{v.line}")
        print(f"      {v.detail}")
    print("\nراجع دستور المعمارية. الـ CI سيُرفض هذا الـ commit.")
    return 1


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "app"
    sys.exit(main(target))
