"""One-time migration for moving a single-hotel DB toward tenant/property scoping.

Usage:
    MONGO_URL='mongodb://...' DB_NAME='grand_hayat' \
    DEFAULT_TENANT_ID='default' DEFAULT_PROPERTY_ID='main' \
    python tools/migrate_tenant_property.py

What it does:
- Adds tenant_id/property_id defaults to operational collections.
- Adds active_property_id/property_ids to users where missing.
- Drops old global unique room/floor indexes when their names are known, because
  SaaS must use compound unique indexes instead.
- Recreates the tenant/property compound indexes through shared.config.indexes.
"""
from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parents[1] / "app"
if str(APP_ROOT) not in sys.path:
    sys.path.insert(0, str(APP_ROOT))

from motor.motor_asyncio import AsyncIOMotorClient
from pymongo.errors import OperationFailure

from shared.config.indexes import ensure_indexes

COLLECTIONS_WITH_TENANT_PROPERTY = (
    "rooms", "floors", "checkins", "checkouts", "requests", "room_inspections",
    "folios", "folio_transactions", "notifications_log", "settings",
    "guests", "reservations", "conversations", "messages", "audit_logs", "stored_files",
)


async def _drop_index_if_exists(collection, name: str) -> None:
    try:
        await collection.drop_index(name)
        print(f"dropped index {collection.name}.{name}")
    except OperationFailure:
        return


async def main() -> None:
    mongo_url = os.environ.get("MONGO_URL")
    if not mongo_url:
        raise RuntimeError("MONGO_URL is required")
    db_name = os.environ.get("DB_NAME", "grand_hayat")
    tenant_id = os.environ.get("DEFAULT_TENANT_ID", "default")
    property_id = os.environ.get("DEFAULT_PROPERTY_ID", "main")

    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    try:
        for name in COLLECTIONS_WITH_TENANT_PROPERTY:
            res = await db[name].update_many(
                {"tenant_id": {"$exists": False}},
                {"$set": {"tenant_id": tenant_id, "property_id": property_id}},
            )
            print(f"{name}: set tenant/property on {res.modified_count} docs")

        await db.users.update_many(
            {"tenant_id": {"$exists": False}},
            {"$set": {
                "tenant_id": tenant_id,
                "active_property_id": property_id,
                "property_ids": [property_id],
            }},
        )

        # Old settings were global by {key}. The new foundation scopes them by
        # tenant/property/module/key. Keep their key and place them in module pms
        # unless a module already exists.
        await db.settings.update_many(
            {"module": {"$exists": False}},
            {"$set": {"module": "pms"}},
        )

        # Known old single-hotel unique indexes that block scoped use.
        for coll, index_name in (
            (db.rooms, "number_1"),
            (db.floors, "number_1"),
            (db.users, "email_1"),
            (db.settings, "key_1"),
            (db.sms_conversations, "phone_1"),
        ):
            await _drop_index_if_exists(coll, index_name)

        await ensure_indexes(db)
        print("tenant/property migration complete")
    finally:
        client.close()


if __name__ == "__main__":
    asyncio.run(main())
