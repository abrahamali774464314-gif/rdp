# CHANGELOG — PMS Foundation Upgrade

## 2026-05-30

### Added

- Added PMS Foundation domains:
  - properties
  - guests
  - reservations
  - settings
  - messaging
  - audit
  - storage
- Added API routers for all completed domains, including previously missing operational routers:
  - requests
  - checkouts
  - inspections
  - billing
  - identity
  - notifications
- Added central PMS constants in `shared/foundation/constants.py`.
- Added scoped settings model: `tenant_id + property_id + module + key`.
- Added unified messaging model for SMS/WhatsApp/email/internal channels.
- Added independent guest profile model.
- Added reservation foundation model.
- Added property/tenant foundation model and automatic default property seeding.
- Added audit log model and API.
- Added storage metadata model and API.
- Added Mongo indexes for all foundation collections.
- Added `super_admin` role as platform-level role distinct from property-level `admin`.
- Added expanded room statuses: `dirty`, `inspected`, `out_of_order`.

### Changed

- Server now registers 15 module routers under `/api/v1`.
- README updated to reflect PMS Foundation status and current tests.
- Container bootstrap now wires the full foundation set instead of only the first operational modules.
- Query scoping distinguishes SaaS/platform super admin from property admin.
- Identity registration now carries tenant/property assignment fields.
- Billing, notifications, identity, inspections repositories/services gained scoped list APIs.

### Verified

- `python -m compileall -q app` passed.
- `python tools/check_architecture.py app` passed.
- `pytest -q tests/architecture` passed with 215 tests.

### Notes

This is a PMS Foundation package, not a full commercial PMS launch package. It is ready to be used as the clean base for migrating legacy features, but still needs real database migration, live Mongo/Uvicorn testing, frontend adaptation, and external provider integration testing.
