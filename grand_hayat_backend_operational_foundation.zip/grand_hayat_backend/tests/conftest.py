"""
tests/conftest.py — إعدادات pytest على مستوى الجذر
═══════════════════════════════════════════════════════════════════

  - يضع app/ على sys.path (لتمكين «from modules.* / from kernel.*»)
  - يضبط asyncio_mode للاختبارات السلوكية
  - يضمن أن الاختبارات deterministic (لا تعتمد على network/clock)
"""
from __future__ import annotations

import os
import sys

# المتطلب 9: deterministic — جذر الـ app على sys.path قبل أي استيراد
_HERE = os.path.dirname(__file__)
APP_PATH = os.path.abspath(os.path.join(_HERE, "..", "app"))
if APP_PATH not in sys.path:
    sys.path.insert(0, APP_PATH)


# pytest-asyncio يحتاج auto mode للاختبارات السلوكية المُعلَّمة بـ pytestmark
def pytest_collection_modifyitems(config, items):
    """تمييز الاختبارات السلوكية لتعمل deterministic."""
    # لا حاجة لتعديل items حالياً — تركها كما هي ضمن وضع pytest-asyncio
    return
