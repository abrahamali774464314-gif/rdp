"""
tests/architecture/test_constitution.py — اختبارات سلوكية للدستور
═══════════════════════════════════════════════════════════════════

تثبت أن قواعد الدستور مُطبَّقة سلوكياً (لا بنيوياً فقط):
  - State Machine Authority: رفض الانتقالات غير الشرعية
  - Financial Immutability: القيد المالي frozen + reversal فقط
  - التواصل عبر الأحداث: تسكين يحرّك الغرفة دون استدعاء مباشر
  - Domain Invariants: رفض الحالات غير الصالحة

تستورد من المسارات الخماسية الحالية (domain.models / application.service).
"""
from __future__ import annotations

import dataclasses
from decimal import Decimal

import pytest

pytestmark = pytest.mark.asyncio


# ── Fakes مشتركة ──────────────────────────────────────────────
class FakeUoW:
    session = None
    async def __aenter__(self): return self
    async def __aexit__(self, *a): pass


def uow_factory():
    return FakeUoW()


# ══════════════════════════════════════════════════════════════
# State Machine Authority
# ══════════════════════════════════════════════════════════════
def test_room_fsm_rejects_illegal_transition():
    from kernel.state_machine import IllegalTransitionError
    from modules.rooms.domain.models import ROOM_FSM
    with pytest.raises(IllegalTransitionError):
        ROOM_FSM.transition("cleaning", "occupied")
    assert ROOM_FSM.transition("available", "occupied") == "occupied"


def test_terminal_state_rejects_self_loop():
    """الحالات النهائية ترفض حتى الانتقال إلى نفسها (لا اكتمال مزدوج)."""
    from kernel.state_machine import IllegalTransitionError
    from modules.checkins.domain.models import CHECKIN_FSM
    with pytest.raises(IllegalTransitionError):
        CHECKIN_FSM.transition("checked_out", "checked_out")


# ══════════════════════════════════════════════════════════════
# Domain Invariants
# ══════════════════════════════════════════════════════════════
def test_occupied_room_cannot_be_reoccupied():
    from kernel.errors import ConflictError
    from modules.rooms.domain.models import RoomEntity
    room = RoomEntity(number=1, floor=1, status="available")
    room.occupy(checkin_id="c1", guest_name="g", guest_phone="p",
                check_in_at="now", expected_checkout_at=None)
    with pytest.raises(ConflictError):
        room.occupy(checkin_id="c2", guest_name="g2", guest_phone="p2",
                    check_in_at="now", expected_checkout_at=None)


def test_checkin_requires_guest_name():
    from kernel.errors import InvariantViolationError
    from modules.checkins.domain.models import CheckinEntity
    bad = CheckinEntity(id="x", room_number=1, floor=1,
                        guest_name="", guest_phone="123", check_in_at="now")
    with pytest.raises(InvariantViolationError):
        bad.register()


# ══════════════════════════════════════════════════════════════
# Financial Immutability
# ══════════════════════════════════════════════════════════════
def test_financial_transaction_is_frozen():
    from modules.billing.domain.models import FolioTransaction
    t = FolioTransaction(
        id="t1", folio_id="f1", type="charge", subtype="room_rate",
        amount=Decimal("25000"), tax_amount=Decimal("0"), currency="YER",
        description="ليلة", business_date="2026-05-26", posted_by="u1", posted_at="now")
    with pytest.raises(dataclasses.FrozenInstanceError):
        t.amount = Decimal("999")


def test_reversal_does_not_mutate_original():
    from modules.billing.domain.models import FolioEntity, FolioTransaction
    folio = FolioEntity(id="f1", checkin_id="c1", room_number=305, guest_name="g")
    charge = FolioTransaction(
        id="t1", folio_id="f1", type="charge", subtype="minibar",
        amount=Decimal("5000"), tax_amount=Decimal("0"), currency="YER",
        description="ميني بار", business_date="2026-05-26", posted_by="u1", posted_at="now")
    folio.post(charge)
    reversal = FolioTransaction(
        id="t2", folio_id="f1", type="payment", subtype="minibar",
        amount=Decimal("5000"), tax_amount=Decimal("0"), currency="YER",
        description="إلغاء", business_date="2026-05-26", posted_by="u2", posted_at="now",
        linked_txn_id="t1", source="reversal")
    folio.reverse("t1", reversal)
    txns = {t.id: t for t in folio.transactions}
    assert txns["t1"].amount == Decimal("5000")     # الأصلي لم يتغيّر
    assert txns["t1"].is_void is True
    assert txns["t1"].reversal_txn_id == "t2"


# ══════════════════════════════════════════════════════════════
# التواصل عبر الأحداث (Domain → Event Bus → Subscribers)
# ══════════════════════════════════════════════════════════════
async def test_checkin_drives_room_through_events():
    """تسكين يشغّل الغرفة عبر الأحداث — لا استدعاء مباشر بين المجالين."""
    from kernel.bus import EventBus
    from modules.checkins.application.service import (
        CheckinApplicationService, RegisterCheckin)
    from modules.rooms.domain.models import RoomEntity
    from modules.rooms.domain.repository import RoomRepository
    from modules.rooms.application.service import (
        RoomApplicationService, RoomEventSubscribers)
    from modules.checkins.domain.repository import CheckinRepository

    class CheckinRepo(CheckinRepository):
        def __init__(self): self.s = {}
        async def get(self, i): return self.s.get(i)
        async def add(self, c, uow=None): self.s[c.id] = c; return c
        async def save(self, c, uow=None): self.s[c.id] = c; return c
        async def get_active_by_room(self, r): return None

    class RoomRepo(RoomRepository):
        def __init__(self):
            self.r = {305: RoomEntity(number=305, floor=3, status="available")}
        async def get_by_number(self, n): return self.r.get(n)
        async def save(self, room, uow=None): self.r[room.number] = room; return room
        async def list_occupied(self): return []
        async def find_by_guest_phone(self, p): return None

    bus = EventBus()
    croom, cchk = RoomRepo(), CheckinRepo()
    room_app = RoomApplicationService(rooms=croom, uow_factory=uow_factory, bus=bus)
    chk_app = CheckinApplicationService(checkins=cchk, uow_factory=uow_factory, bus=bus)
    RoomEventSubscribers(room_app).register(bus)

    res = await chk_app.register(RegisterCheckin(
        room_number=305, floor=3, guest_name="نزيل", guest_phone="+9677",
        check_in_at=None, expected_checkout_at=None, note="",
        actor_id="u1", actor_name="موظف"))

    assert croom.r[305].status == "occupied"
    assert croom.r[305].active_checkin_id == res.data.id


# ══════════════════════════════════════════════════════════════
# Identity: سياسة الصلاحيات + brute-force
# ══════════════════════════════════════════════════════════════
def test_inactive_user_has_no_permissions():
    from modules.identity.domain.models import (
        UserEntity, EmailAddress, PasswordHash, ROLE_ADMIN)
    u = UserEntity(id="a", email=EmailAddress("a@b.co"), name="x",
                   password_hash=PasswordHash("h"), role=ROLE_ADMIN)
    u.deactivate()
    assert not u.has_permission("view_rooms")  # حتى admin معطّل


def test_brute_force_locks_account():
    from modules.identity.domain.models import (
        UserEntity, EmailAddress, PasswordHash, ROLE_STAFF)
    u = UserEntity(id="bf", email=EmailAddress("a@b.co"), name="x",
                   password_hash=PasswordHash("h"), role=ROLE_STAFF)
    for _ in range(5):
        u.record_failed_login(max_attempts=5)
    assert u.status == "locked"


# ══════════════════════════════════════════════════════════════
# Notifications: retry حتى الاستنفاد
# ══════════════════════════════════════════════════════════════
def test_notification_exhausts_after_max_attempts():
    from modules.notifications.domain.models import (
        NotificationEntity, NotificationMessage, CHANNEL_SMS)
    n = NotificationEntity(
        id="n1", message=NotificationMessage(channel=CHANNEL_SMS, recipient="+9677", body="x"),
        cause_event="t.x", max_attempts=3)
    n.mark_failed(at="t1", error="timeout")
    n.begin_retry(); n.mark_failed(at="t2", error="timeout")
    n.begin_retry(); n.mark_failed(at="t3", error="timeout")
    assert n.status == "exhausted"
    assert not n.can_retry


# ══════════════════════════════════════════════════════════════
# Idempotency Key — مستقرّ وقابل للاشتقاق
# ══════════════════════════════════════════════════════════════
def test_idempotency_key_is_stable_and_pure():
    """المتطلب 5 (notifications): المفتاح pure + deterministic."""
    from modules.notifications.domain.models import derive_idempotency_key
    k1 = derive_idempotency_key(
        cause_event="checkins.registered", channel="whatsapp",
        recipient="+9677", cause_event_id="ev-1")
    k2 = derive_idempotency_key(
        cause_event="checkins.registered", channel="whatsapp",
        recipient="+9677", cause_event_id="ev-1")
    k3 = derive_idempotency_key(
        cause_event="checkins.registered", channel="sms",
        recipient="+9677", cause_event_id="ev-1")
    assert k1 == k2, "نفس المدخلات يجب أن تُنتج نفس المفتاح"
    assert k1 != k3, "اختلاف القناة يجب أن يُنتج مفتاحاً مختلفاً"


# ══════════════════════════════════════════════════════════════
# Domain Ownership — لا cross-domain calls في الـ services
# ══════════════════════════════════════════════════════════════
def test_room_application_does_not_call_other_services():
    """تحقّق سلوكي: RoomApplicationService لا يحوي مراجع لمجالات أخرى."""
    import inspect
    from modules.rooms.application.service import RoomApplicationService
    src = inspect.getsource(RoomApplicationService)
    # لا أسماء قواعد بيانات أو خدمات مجالات أخرى
    forbidden = ["CheckinApplicationService", "BillingApplicationService",
                 "NotificationApplicationService"]
    for token in forbidden:
        assert token not in src, \
            f"RoomApplicationService يشير إلى «{token}» — يجب التواصل عبر Bus"


# ══════════════════════════════════════════════════════════════
# Container — نقطة التركيب الوحيدة التي تعرف عدّة مجالات
# ══════════════════════════════════════════════════════════════
def test_container_is_the_only_cross_domain_wirer():
    """المتطلب 3: container هو المكان الوحيد المسموح له بمعرفة عدّة مجالات."""
    import os, ast
    APP = os.path.join(os.path.dirname(__file__), "..", "..", "app")
    container_path = os.path.join(APP, "shared", "config", "container.py")
    if not os.path.exists(container_path):
        pytest.skip("لا container بعد")
    # يجب أن يستورد container من كل المجالات المكتملة
    with open(container_path, encoding="utf-8") as f:
        tree = ast.parse(f.read())
    imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module \
                and node.module.startswith("modules."):
            imports.add(node.module.split(".")[1])
    assert len(imports) >= 2, \
        f"container لا يبدو composition root (يستورد {imports} فقط)"
