from __future__ import annotations

from decimal import Decimal

import pytest


@pytest.mark.asyncio
async def test_event_bus_fail_fast_and_lenient_modes():
    from kernel.bus import EventBus
    from kernel.contracts import DomainEvent

    class E(DomainEvent):
        topic = "x"

    async def broken(_):
        raise RuntimeError("boom")

    bus = EventBus()
    bus.subscribe("x", broken)
    with pytest.raises(RuntimeError):
        await bus.publish(E())

    bus2 = EventBus()
    bus2.subscribe("x", broken, fail_fast=False)
    await bus2.publish(E())


def test_billing_reversal_restores_balance_to_zero():
    from modules.billing.domain.models import FolioEntity, FolioTransaction

    folio = FolioEntity(id="f1", checkin_id="c1", room_number=101, guest_name="guest")
    charge = FolioTransaction(
        id="t1", folio_id="f1", type="charge", subtype="room_rate",
        amount=Decimal("100.00"), tax_amount=Decimal("0.00"), currency="YER",
        description="night", business_date="2026-05-30", posted_by="u1", posted_at="now",
    )
    folio.post(charge)
    assert folio.balance() == Decimal("100.00")

    reversal = FolioTransaction(
        id="t2", folio_id="f1", type="payment", subtype="reversal",
        amount=Decimal("100.00"), tax_amount=Decimal("0.00"), currency="YER",
        description="reverse", business_date="2026-05-30", posted_by="u2", posted_at="now",
        linked_txn_id="t1", source="reversal",
    )
    folio.reverse("t1", reversal)
    assert folio.balance() == Decimal("0.00")


def test_checkout_service_keeps_balance_port_on_instance():
    from modules.checkouts.application.service import CheckoutApplicationService

    class Repo:
        pass

    class Balance:
        async def current_balance(self, checkin_id: str):
            return Decimal("0.00")

    svc = CheckoutApplicationService(checkouts=Repo(), uow_factory=lambda: None, bus=None, balance_port=Balance())
    assert hasattr(svc, "_balance")
