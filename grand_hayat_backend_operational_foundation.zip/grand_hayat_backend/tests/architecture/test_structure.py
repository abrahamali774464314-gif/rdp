"""
tests/architecture/test_structure.py — Architectural Enforcement (Structure)
═══════════════════════════════════════════════════════════════════

يفرض الدستور المعماري بنيوياً وآلياً على كل المجالات.

المتطلبات الـ 9 المغطّاة:
  ① auto-discovery للمجالات تحت modules/
  ② البنية الخماسية الثابتة (5 ملفات فقط)
  ③ قواعد الاستيراد الصارمة (لا cross-domain، لا inf→app/domain)
  ④ Pure Domain Rule (لا مكتبات خارجية في domain)
  ⑤ Application Purity (لا concrete adapters)
  ⑥ Thin Routers Rule (إن وُجدت routers)
  ⑦ Import Graph Direction (domain ← application ← infrastructure)
  ⑧ Fail-fast مع رسائل خطأ مُفيدة
  ⑨ Deterministic (تعتمد على AST + filesystem فقط، لا network/clock)
"""
from __future__ import annotations

import ast
import os
from typing import Iterable

import pytest

# ══════════════════════════════════════════════════════════════
# Paths + Constants
# ══════════════════════════════════════════════════════════════
APP_ROOT = os.path.join(os.path.dirname(__file__), "..", "..", "app")
MODULES_ROOT = os.path.join(APP_ROOT, "modules")

# البنية الخماسية الإلزامية لكل مجال مكتمل
REQUIRED_FILES = (
    "domain/models.py",
    "domain/events.py",
    "domain/repository.py",
    "application/service.py",
    "infrastructure/repository.py",
)

# ── المكتبات الخارجية الممنوعة في الـ domain (Pure Domain Rule) ──
# domain يُسمح فيه فقط: stdlib + kernel + typing + dataclasses + enum + uuid + datetime
EXTERNAL_LIBS_FORBIDDEN_IN_DOMAIN = (
    "fastapi", "motor", "pymongo", "httpx", "requests",
    "bcrypt", "jwt", "jose", "passlib",
    "sqlalchemy", "pydantic", "redis", "celery",
    "websockets", "aioredis", "aiohttp", "starlette",
)

# الـ stdlib المسموح به دائماً (للتوثيق فقط — لا نفرضه كقائمة بيضاء صارمة
# لأنّه يتطوّر؛ نمنع المكتبات الخارجية صراحةً عوضاً)
STDLIB_ALLOWED = (
    "typing", "dataclasses", "enum", "uuid", "datetime",
    "decimal", "abc", "logging", "html", "base64", "hashlib",
    "json", "os", "sys", "re", "functools", "itertools",
    "collections", "contextlib", "asyncio",
    "__future__",
)

# Application يُسمح فيه ما يُسمح في domain + Ports من نفس المجال
APPLICATION_FORBIDDEN_LIBS = EXTERNAL_LIBS_FORBIDDEN_IN_DOMAIN

# كل المجالات المعروفة (للتحقّق من الاكتشاف)
KNOWN_DOMAINS = {
    "rooms", "checkins", "checkouts", "requests",
    "inspections", "billing", "notifications", "identity",
    "properties", "guests", "reservations", "settings",
    "messaging", "audit", "storage",
}


# ══════════════════════════════════════════════════════════════
# Helpers (AST parsing — deterministic, no I/O beyond file read)
# ══════════════════════════════════════════════════════════════
def _read(path: str) -> str:
    """قراءة آمنة. ترفع FileNotFoundError إن غاب الملف."""
    with open(path, encoding="utf-8") as f:
        return f.read()


def _parse_imports(path: str) -> list[tuple[str, int]]:
    """يُرجع [(module_name, line_no), ...] لكل استيراد في الملف.

    deterministic: يعتمد على ast.parse فقط — لا تنفيذ كود، لا I/O خارجي.
    """
    if not os.path.exists(path):
        return []
    try:
        tree = ast.parse(_read(path), filename=path)
    except SyntaxError as exc:
        pytest.fail(f"خطأ نحوي في {path}: {exc}")
    out: list[tuple[str, int]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                out.append((alias.name, node.lineno))
        elif isinstance(node, ast.ImportFrom) and node.module:
            out.append((node.module, node.lineno))
    return out


def _top_level(module_path: str) -> str:
    """أعلى جزء من اسم الموديول: 'httpx.client' → 'httpx'."""
    return module_path.split(".")[0]


def _starts_with_any(name: str, prefixes: Iterable[str]) -> bool:
    return any(name == p or name.startswith(p + ".") for p in prefixes)


def _all_py_files(root: str) -> list[str]:
    """كل ملفات .py تحت root (تخطّي __pycache__)."""
    out: list[str] = []
    for dp, _dn, files in os.walk(root):
        if "__pycache__" in dp:
            continue
        for fn in files:
            if fn.endswith(".py"):
                out.append(os.path.join(dp, fn))
    return out


def _discover_completed_domains() -> list[str]:
    """المتطلب 1: اكتشاف المجالات المكتملة آلياً (لها الملفات الخمسة)."""
    if not os.path.isdir(MODULES_ROOT):
        return []
    out: list[str] = []
    for name in sorted(os.listdir(MODULES_ROOT)):
        mod_dir = os.path.join(MODULES_ROOT, name)
        if not os.path.isdir(mod_dir) or name.startswith("_"):
            continue
        if all(os.path.exists(os.path.join(mod_dir, f)) for f in REQUIRED_FILES):
            out.append(name)
    return out


COMPLETED_DOMAINS = _discover_completed_domains()
ALL_DOMAIN_NAMES = set(COMPLETED_DOMAINS)


def _fail(domain: str, layer: str, line: int, msg: str) -> str:
    """رسالة خطأ موحّدة، fail-fast (المتطلب 8)."""
    return f"\n  📂 {domain}/{layer}\n  📍 سطر {line}\n  ❌ {msg}"


# ══════════════════════════════════════════════════════════════
# ① Auto-discovery
# ══════════════════════════════════════════════════════════════
def test_modules_root_exists():
    assert os.path.isdir(MODULES_ROOT), \
        f"❌ مجلّد المجالات غير موجود: {MODULES_ROOT}"


def test_at_least_one_domain_discovered():
    assert COMPLETED_DOMAINS, (
        "❌ لم يُكتشف أي مجال مكتمل (يلزم كل مجال أن يحوي الملفات الخمسة).\n"
        f"   الملفات المطلوبة: {REQUIRED_FILES}"
    )


def test_no_unknown_domains():
    """المتطلب 1: كل مجال مكتشَف يجب أن يكون ضمن اللائحة المعروفة."""
    unknown = set(COMPLETED_DOMAINS) - KNOWN_DOMAINS
    assert not unknown, (
        f"❌ مجالات غير معروفة اكتُشفت: {unknown}\n"
        f"   حدّث KNOWN_DOMAINS في test_structure.py لإقرارها رسمياً."
    )


# ══════════════════════════════════════════════════════════════
# ② البنية الخماسية الثابتة
# ══════════════════════════════════════════════════════════════
@pytest.mark.parametrize("domain", COMPLETED_DOMAINS)
def test_five_file_structure(domain):
    """المتطلب 2: كل مجال يحوي بالضبط الملفات الخمسة القياسية."""
    mod_dir = os.path.join(MODULES_ROOT, domain)
    for f in REQUIRED_FILES:
        path = os.path.join(mod_dir, f)
        assert os.path.exists(path), _fail(
            domain, f, 0, f"ملف قياسي مفقود — البنية الخماسية مكسورة"
        )


@pytest.mark.parametrize("domain", COMPLETED_DOMAINS)
def test_init_files_have_no_code(domain):
    """المتطلب 2: __init__.py فارغة (لا كود، فقط توثيق اختياري)."""
    mod_dir = os.path.join(MODULES_ROOT, domain)
    for layer in ("", "domain", "application", "infrastructure"):
        init = os.path.join(mod_dir, layer, "__init__.py")
        if not os.path.exists(init):
            continue
        content = _read(init).strip()
        if not content:
            continue
        # نسمح بـ docstrings/comments — نمنع أي كود تنفيذي
        try:
            tree = ast.parse(content)
        except SyntaxError:
            pytest.fail(_fail(domain, f"{layer}/__init__.py", 0,
                              "كود غير صالح نحوياً"))
        code_nodes = [
            n for n in tree.body
            if not (isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant)
                    and isinstance(n.value.value, str))
        ]
        assert not code_nodes, _fail(
            domain, f"{layer}/__init__.py", code_nodes[0].lineno,
            f"__init__.py يجب أن يكون فارغاً (وُجد {type(code_nodes[0]).__name__})"
        )


# ══════════════════════════════════════════════════════════════
# ④ Pure Domain Rule
# ══════════════════════════════════════════════════════════════
@pytest.mark.parametrize("domain", COMPLETED_DOMAINS)
def test_domain_purity_no_external_libs(domain):
    """المتطلب 4: domain لا يستورد أي مكتبة خارجية (fastapi/motor/httpx/bcrypt/...)."""
    for f in ("domain/models.py", "domain/events.py", "domain/repository.py"):
        path = os.path.join(MODULES_ROOT, domain, f)
        for imp, lineno in _parse_imports(path):
            top = _top_level(imp)
            assert top not in EXTERNAL_LIBS_FORBIDDEN_IN_DOMAIN, _fail(
                domain, f, lineno,
                f"استيراد مكتبة خارجية محظورة في الـ domain: «{imp}» — "
                f"يجب أن يبقى الـ domain pure Python (stdlib + kernel فقط)"
            )


@pytest.mark.parametrize("domain", COMPLETED_DOMAINS)
def test_domain_does_not_import_other_domains(domain):
    """المتطلب 3: domain لا يستورد domain آخر (cross-domain ممنوع تماماً)."""
    for f in ("domain/models.py", "domain/events.py", "domain/repository.py"):
        path = os.path.join(MODULES_ROOT, domain, f)
        for imp, lineno in _parse_imports(path):
            if imp.startswith("modules."):
                other = imp.split(".")[1]
                assert other == domain, _fail(
                    domain, f, lineno,
                    f"الـ domain يستورد مجالاً آخر «{other}» — "
                    f"التواصل بين المجالات عبر Event Bus فقط"
                )


@pytest.mark.parametrize("domain", COMPLETED_DOMAINS)
def test_domain_does_not_import_infrastructure(domain):
    """المتطلب 7: لا عكس في الـ Import Graph (domain لا يعرف infrastructure)."""
    for f in ("domain/models.py", "domain/events.py", "domain/repository.py"):
        path = os.path.join(MODULES_ROOT, domain, f)
        for imp, lineno in _parse_imports(path):
            assert ".infrastructure" not in imp, _fail(
                domain, f, lineno,
                f"عكس Import Graph: domain يستورد infrastructure «{imp}»"
            )


@pytest.mark.parametrize("domain", COMPLETED_DOMAINS)
def test_domain_does_not_import_application(domain):
    """المتطلب 7: domain لا يستورد application (Import Graph: domain ← app)."""
    for f in ("domain/models.py", "domain/events.py", "domain/repository.py"):
        path = os.path.join(MODULES_ROOT, domain, f)
        for imp, lineno in _parse_imports(path):
            assert ".application" not in imp, _fail(
                domain, f, lineno,
                f"عكس Import Graph: domain يستورد application «{imp}»"
            )


# ══════════════════════════════════════════════════════════════
# ⑤ Application Layer Purity
# ══════════════════════════════════════════════════════════════
@pytest.mark.parametrize("domain", COMPLETED_DOMAINS)
def test_application_purity_no_external_libs(domain):
    """المتطلب 5: application لا يستورد مكتبات خارجية (Ports فقط)."""
    path = os.path.join(MODULES_ROOT, domain, "application/service.py")
    for imp, lineno in _parse_imports(path):
        top = _top_level(imp)
        assert top not in APPLICATION_FORBIDDEN_LIBS, _fail(
            domain, "application/service.py", lineno,
            f"application يستورد مكتبة خارجية «{imp}» — يجب الاعتماد على Ports المجرّدة"
        )


@pytest.mark.parametrize("domain", COMPLETED_DOMAINS)
def test_application_does_not_import_infrastructure(domain):
    """المتطلب 5+7: application لا يعرف أي concrete adapter."""
    path = os.path.join(MODULES_ROOT, domain, "application/service.py")
    for imp, lineno in _parse_imports(path):
        assert ".infrastructure" not in imp, _fail(
            domain, "application/service.py", lineno,
            f"application يستورد infrastructure «{imp}» — "
            f"حُقن الـ Ports عبر الـ container، لا تستورد التنفيذ مباشرة"
        )


@pytest.mark.parametrize("domain", COMPLETED_DOMAINS)
def test_application_does_not_import_other_domain_applications(domain):
    """المتطلب 3: application لا يستورد application مجال آخر (استخدم Bus)."""
    path = os.path.join(MODULES_ROOT, domain, "application/service.py")
    for imp, lineno in _parse_imports(path):
        if imp.startswith("modules.") and ".application" in imp:
            other = imp.split(".")[1]
            assert other == domain, _fail(
                domain, "application/service.py", lineno,
                f"application يستورد application مجال «{other}» — "
                f"التواصل بين المجالات عبر Event Bus فقط"
            )


@pytest.mark.parametrize("domain", COMPLETED_DOMAINS)
def test_application_does_not_import_other_domain_domains(domain):
    """المتطلب 3: application لا يستورد domain مجال آخر."""
    path = os.path.join(MODULES_ROOT, domain, "application/service.py")
    for imp, lineno in _parse_imports(path):
        if imp.startswith("modules.") and ".domain" in imp:
            other = imp.split(".")[1]
            assert other == domain, _fail(
                domain, "application/service.py", lineno,
                f"application يستورد domain مجال «{other}» — "
                f"كل مجال مغلق على نفسه"
            )


# ══════════════════════════════════════════════════════════════
# ⑦ Infrastructure: يستطيع استيراد domain (نفس المجال) — Import Graph
# ══════════════════════════════════════════════════════════════
@pytest.mark.parametrize("domain", COMPLETED_DOMAINS)
def test_infrastructure_only_touches_own_domain(domain):
    """المتطلب 3+7: infrastructure لا يلمس domain/application مجال آخر."""
    path = os.path.join(MODULES_ROOT, domain, "infrastructure/repository.py")
    for imp, lineno in _parse_imports(path):
        if imp.startswith("modules."):
            other = imp.split(".")[1]
            assert other == domain, _fail(
                domain, "infrastructure/repository.py", lineno,
                f"infrastructure يلمس مجالاً آخر «{other}» — "
                f"كل مجال يحرس بنيته التحتية"
            )


# ══════════════════════════════════════════════════════════════
# ⑥ Thin Routers Rule (استباقي — يفشل لو وُجد router غير نظيف)
# ══════════════════════════════════════════════════════════════
# المسموح في الـ routers: استدعاءات بسيطة + return فقط
# الممنوع: حلقات، شجر شروط (>1 if في الدالة)، استدعاءات DB، نشر أحداث
ROUTERS_FORBIDDEN_NAMES = (
    # repository / DB calls
    "find_one", "find", "insert_one", "update_one", "delete_one",
    "insert_many", "update_many", "aggregate",
    # transactions
    "start_session", "start_transaction", "uow_factory",
    # event publishing (يجب أن يكون في الـ service)
    "publish", "publish_all", "subscribe",
)


def _routers_in_domain(domain: str) -> list[str]:
    """يُرجع كل ملفات الـ routers/api لمجال (إن وُجدت)."""
    api_dir = os.path.join(MODULES_ROOT, domain, "api")
    if not os.path.isdir(api_dir):
        return []
    return [p for p in _all_py_files(api_dir)
            if not p.endswith("__init__.py")]


@pytest.mark.parametrize("domain", COMPLETED_DOMAINS)
def test_routers_are_thin_if_present(domain):
    """المتطلب 6: routers (إن وُجدت) thin — لا loops/repository/transactions/publish.

    استباقي: المجالات بلا routers (الحالة الراهنة) تمرّ بصمت. عند إضافة
    router غير نظيف لاحقاً، يفشل الـ CI فوراً.
    """
    routers = _routers_in_domain(domain)
    if not routers:
        pytest.skip(f"لا توجد routers في {domain} بعد (الـ API layer لم تُبنَ).")

    for path in routers:
        tree = ast.parse(_read(path), filename=path)
        for node in ast.walk(tree):
            # حلقات داخل router function
            if isinstance(node, (ast.For, ast.While, ast.AsyncFor)):
                pytest.fail(_fail(
                    domain, f"api/{os.path.basename(path)}", node.lineno,
                    f"router يحوي حلقة ({type(node).__name__}) — يجب أن يكون thin"
                ))
            # استدعاءات محظورة
            if isinstance(node, ast.Call):
                func_name = None
                if isinstance(node.func, ast.Attribute):
                    func_name = node.func.attr
                elif isinstance(node.func, ast.Name):
                    func_name = node.func.id
                if func_name in ROUTERS_FORBIDDEN_NAMES:
                    pytest.fail(_fail(
                        domain, f"api/{os.path.basename(path)}", node.lineno,
                        f"router يستدعي «{func_name}» — هذا منطق أعمال "
                        f"يجب أن يكون في application service"
                    ))


@pytest.mark.parametrize("domain", COMPLETED_DOMAINS)
def test_routers_do_not_import_infrastructure_if_present(domain):
    """المتطلب 6: routers لا تستورد infrastructure (تستخدم الـ container)."""
    for path in _routers_in_domain(domain):
        for imp, lineno in _parse_imports(path):
            assert ".infrastructure" not in imp, _fail(
                domain, f"api/{os.path.basename(path)}", lineno,
                f"router يستورد infrastructure «{imp}» — استخدم container/service"
            )


# ══════════════════════════════════════════════════════════════
# ⑧ تحقّق عام شامل (sanity check نهائي)
# ══════════════════════════════════════════════════════════════
def test_no_legacy_paths_remain():
    """المتطلب 7: لا أحد يستورد من المسارات القديمة (routers.*, services.*, core.* خارج kernel)."""
    legacy_prefixes = ("routers.", "services.")
    offenders: list[str] = []
    for path in _all_py_files(MODULES_ROOT):
        for imp, lineno in _parse_imports(path):
            if _starts_with_any(imp, legacy_prefixes):
                rel = os.path.relpath(path, APP_ROOT)
                offenders.append(f"{rel}:{lineno} → {imp}")
    assert not offenders, (
        "❌ بقايا استيراد من البنية القديمة (يجب أن تُهجَر بالكامل):\n  "
        + "\n  ".join(offenders)
    )
